/* 
 * RptContentApprvService.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.txn.service;

import java.util.List;

import com.iisigroup.cap.dao.utils.ISearch;
import com.iisigroup.cap.model.Page;

import tw.com.hncb.rcms.model.RptContentApprv;
import tw.com.hncb.rcms.model.VwRptContentApprvPDData;

/**
 * <pre>
 * Table: RptContentApprv 服務介面
 * </pre>
 * 
 * @since 2017/3/13
 * @author jeanlin
 * @version <ul>
 *          <li>2017/3/13,jeanlin,new
 *          </ul>
 */
public interface RptContentApprvService {
	/**
	 * 根據SQL的搜尋條件查詢VwRptIndexPDData
	 * 
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @param sortColName
	 * 			列數名稱
	 * @param sortOrder
	 * 			排序
	 * @return List<RptContentApprv>
	 */
	List<RptContentApprv> getBySqlCondition(
			List<String> infoGrpRptIds, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd,
			String sortColName, String sortOrder);
	
	/**
	 * 依查詢條件查詢簽核主檔資料
	 * @param infoGrpRptIds 報表代號rptid
	 * @param rptBranch 分行表
	 * @param apprvStatus 簽核狀態
	 * @return List<RptContentApprv>
	 */
	List<RptContentApprv> getBySqlCondition(List<String> infoGrpRptIds, String rptBranch, List<String> apprvStatus);
	
	
	/**
	 * 根據SQL的搜尋條件查詢VwRptIndexPDData
	 * 
	 * @param search
	 * 			ISearch
	 * @param rptId
	 * 			報表代號
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptName
	 * 			報表名稱
	 * @param rptSeqno
	 * 			報表序號
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @return Page<VwRptContentApprvPDData>
	 */
	Page<VwRptContentApprvPDData> getBySqlCondition(ISearch search,
			String rptId, List<String> infoGrpRptIds, String rptName,
			int rptSeqno, String rptCycle, String mustPrint, String pd,
			String rptDateBegin, String rptDateEnd,String convertTimeBegin, String convertTimeEnd,String setUserId,String branch, List<String> apprvStatus);
	
	/**
	 * 依查詢條件查詢報表簽核流程設定資料
	 * @param search
	 * @param rptId
	 * @param infoGrpRptIds
	 * @param rptName
	 * @param rptSeqno
	 * @param rptCycle
	 * @param mustPrint
	 * @param pd
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param convertTimeBegin
	 * @param convertTimeEnd
	 * @param setUserId
	 * @param branch
	 * @param oldBranchIds
	 * @param apprvStatus
	 * @return Page<VwRptContentApprvPDData>
	 */
	Page<VwRptContentApprvPDData> getBySqlConditionSetting(ISearch search,
			String rptId, List<String> infoGrpRptIds, String rptName,
			int rptSeqno, String rptCycle, String mustPrint, String pd,
			String rptDateBegin, String rptDateEnd,String convertTimeBegin, String convertTimeEnd,String setUserId,String branch, List<String> oldBranchIds, List<String> apprvStatus);
	
	/**
	 * 報表改派查詢
	 * @param search
	 * @param rptId
	 * @param infoGrpRptIds
	 * @param rptName
	 * @param rptSeqno
	 * @param rptCycle
	 * @param mustPrint
	 * @param pd
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param convertTimeStart
	 * @param convertTimeEnd
	 * @param setUserId
	 * @param rptBranch
	 * @param apprvStatus
	 * @return Page<VwRptContentApprvPDData> 
	 */
	 Page<VwRptContentApprvPDData> getBySqlCondition2(
			ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch,List<String> apprvStatus);
	
	 /**
	  * 依業管科別等查詢條件查詢簽核主檔資料
	  * @param search
	  * @param rptId
	  * @param infoGrpRptIds
	  * @param rptName
	  * @param rptSeqno
	  * @param rptCycle
	  * @param mustPrint
	  * @param pd
	  * @param rptDateBegin
	  * @param rptDateEnd
	  * @param convertTimeBegin
	  * @param convertTimeEnd
	  * @param setUserId
	  * @param branch
	  * @param apprvStatus
	  * @param governingDept
	  * @return Page<VwRptContentApprvPDData>
	  */
	Page<VwRptContentApprvPDData> getByGoverningDept(ISearch search,
			String rptId, List<String> infoGrpRptIds, String rptName,
			int rptSeqno, String rptCycle, String mustPrint, String pd,
			String rptDateBegin, String rptDateEnd,String convertTimeBegin, String convertTimeEnd,String setUserId,String branch,List<String> apprvStatus,List<String> governingDept);
	
	/**
	 * 依pk查詢單筆報表簽核主檔資料
	 * @param pk
	 * @return RptContentApprv
	 */
	RptContentApprv getByPk(Long pk);
	
	/**
	 * 依查詢條件查詢單筆報表簽核主檔資料
	 * @param rptId
	 * @param rptSeqno
	 * @param rptDate
	 * @param rptVersion
	 * @param rptBranch
	 * @param convertTimeStart
	 * @return RptContentApprv
	 */
	RptContentApprv getOneBySqlCondition(String rptId,int rptSeqno,String rptDate,int rptVersion,String rptBranch,String convertTimeStart);
	
	/**
	 * 修改報表簽核主檔資料
	 * @param o
	 */
	void update(RptContentApprv o);
	
	/**
	 * 依單位代號查詢作廢待簽核status=4的資料筆數
	 * @param unitNo
	 * @return 筆數
	 */
	int countInvalid(String unitNo);
	
	/**
	 * 依單位代號查詢作廢待簽核status=4的資料筆數
	 * @param unitNo
	 * @return 筆數
	 */
	int countInvalidByUser(String empId);
	
	/**
	 * 跨單位簽核 - 找出設定的單位和跨單位的單位代號
	 * @return 單位代號
	 */
	String getSetDivisionIdByCrossDept(String rptId,int rptSeqno,String rptDate,int rptVersion,String crossDept,String convertTimeStart);
	
	/**
	 * 依員工編號查詢待設定(報表簽核流程設定,含非跨單位及跨單位)件數
	 * @param empId
	 * @return 件數
	 */
	int getToSettingCnt(String empId);
	
	/**
	 * 依員編查詢是否有任何簽核相關資料(RPT_CONTENT_APPRV_USER)
	 * @param empId
	 * @return 件數
	 */
	int getExistApprvDataCnt(String empId);
	
	/**
	 * 查詢簽核單狀態
	 * @param search ISearch
	 * @param rptId
	 * @param rptBranch
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param qryType
	 * @return Page<VwRptContentApprvPDData> 
	 */
	Page<VwRptContentApprvPDData> getCaseListBySqlCondition(ISearch search, String rptId, String rptBranch, String rptDateBegin, String rptDateEnd, String qryType);
}
