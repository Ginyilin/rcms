/* 
 * Txn104021Handler.java
 * 
 * Copyright (c) 2009-2017 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.txn.handler;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.iisigroup.cap.annotation.HandlerType;
import com.iisigroup.cap.annotation.HandlerType.HandlerTypeEnum;
import com.iisigroup.cap.component.IRequest;
import com.iisigroup.cap.dao.utils.ISearch;
import com.iisigroup.cap.formatter.ADDateFormatter;
import com.iisigroup.cap.formatter.IBeanFormatter;
import com.iisigroup.cap.handler.MFormHandler;
import com.iisigroup.cap.model.Page;
import com.iisigroup.cap.response.AjaxFormResult;
import com.iisigroup.cap.response.GridResult;
import com.iisigroup.cap.security.CapSecurityContext;
import com.iisigroup.cap.utils.CapString;

import net.sf.json.JSONArray;
import tw.com.hncb.rcms.acl.core.RcmsUserDetails;
import tw.com.hncb.rcms.com.core.RcmsContextAware;
import tw.com.hncb.rcms.com.formatter.CfgCodeTypeFormatter;
import tw.com.hncb.rcms.model.AclUser;
import tw.com.hncb.rcms.model.CfgSysParm;
import tw.com.hncb.rcms.model.InfoGrp;
import tw.com.hncb.rcms.model.InfoGrpRpt;
import tw.com.hncb.rcms.model.InfoGrpUser;
import tw.com.hncb.rcms.model.InfoGrpUserDraft;
import tw.com.hncb.rcms.model.InfoUserDeputy;
import tw.com.hncb.rcms.model.RptContentApprvUser;
import tw.com.hncb.rcms.model.RptDefineMaster;
import tw.com.hncb.rcms.model.VwRptContentApprvUserPDData;
import tw.com.hncb.rcms.model.VwRptDefineMaster;
import tw.com.hncb.rcms.txn.service.AclUserService;
import tw.com.hncb.rcms.txn.service.CfgCodeTypeRcmsService;
import tw.com.hncb.rcms.txn.service.CfgSysParmService;
import tw.com.hncb.rcms.txn.service.InfoGrpRptService;
import tw.com.hncb.rcms.txn.service.InfoGrpService;
import tw.com.hncb.rcms.txn.service.InfoGrpUserDraftService;
import tw.com.hncb.rcms.txn.service.InfoGrpUserService;
import tw.com.hncb.rcms.txn.service.InfoUserDeputyService;
import tw.com.hncb.rcms.txn.service.RptClassService;
import tw.com.hncb.rcms.txn.service.RptContentApprvHisService;
import tw.com.hncb.rcms.txn.service.RptContentApprvService;
import tw.com.hncb.rcms.txn.service.RptContentApprvUserService;
import tw.com.hncb.rcms.txn.service.RptDataService;
import tw.com.hncb.rcms.txn.service.RptDefineMasterService;
import tw.com.hncb.rcms.txn.service.VwRptDefineMasterService;


/**
 * <pre>
 * 簽核作業 :整批改派(依簽核人員)處理器
 * 功能說明:針對尚在簽核中的報表，依簽核人員查詢還有那些待簽報表，並進行改派
 * 使用人員:第一關經辦或總務的人員
 *  
 * 1.報表改派的畫面下方加上 簽核歷程 , 因有可能某層級有多人會簽,但一人有簽,另一人沒簽 , 須有下方的簽核歷程才能看明細
   2.在簽核歷程中的簽核狀態, 若非決行的關卡已按下[確認送出]簽核過狀態會顯示"已簽核",只有決行那關簽核過會顯示"已結案"
   3.若某簽核層級有設定多人, 如 A,B,C  ,若只有A 已簽過, B,C 仍未簽,則該簽核層級仍會開放編輯, 
              但因A已簽過,會卡控不能移除 ,而B和C因未簽,仍可移除或再選取其它人

 * 決行 - 自動帶出單位內的主管人員(判斷人員的職稱代號是否為主管Table : INFO_POSITION)
 * 
 * </pre>
 * 
 * @since 2017-4-8
 * @author jeanlin
 * @version <ul>
 *          <li>2017-4-8,jeanlin,new
 *          </ul>
 */
@Scope("request")
@Controller("txn104021handler")
public class Txn104021Handler extends MFormHandler {
	
	private static Log log = LogFactory.getLog(Txn104021Handler.class);

	/** 存取群組與使用者對映草稿table[INFO_GRP_USER_DRAFT]的Service */
	@Autowired
	private InfoGrpUserDraftService infoGrpUserDraftService;
	
	/**簽核:代理人資料的Service */
	@Autowired
	private InfoUserDeputyService infoUserDeputyService;
	
	/** 存取使用者帳號table[ACL_USER]的Service */
	@Autowired
	private AclUserService aclUserService;
	
	/** 存取群組資料table[INFO_GRP]的Service */
	@Autowired
	private InfoGrpService infoGrpService;
	
	/** 存取群組與使用者對映table[INFO_GRP_USER]的Service */
	@Autowired
	private InfoGrpUserService infoGrpUserService;
	
	/** 存取系統參數代碼table[CFG_CODETYPE]的Service */
	@Autowired
	private CfgCodeTypeRcmsService codeSrv;
	
	/** 存取系統參數table[CFG_SYSPARM]的Service */
	@Autowired
	private CfgSysParmService parmSrv;
	
	@Autowired
	private RptDefineMasterService rptDefineMasterService;
	
	@Autowired
	private CfgCodeTypeRcmsService cfgCodeTypeRcmsService;
	
	/** 存取報表定義view[VW_RPT_DEFINE_MASTER]的Service */
	@Autowired
	private  VwRptDefineMasterService vwRptDefineMasterService;
	
	@Autowired
	RptContentApprvService rptContentApprvService;
	
	@Autowired
	RptContentApprvUserService rptContentApprvUserService;
	
	@Autowired
	RptContentApprvHisService rptContentApprvHisService;
	
	@Autowired
	RptDataService rptDataService;
	
	@Autowired
	RptClassService rptClassService;
	
	@Autowired
	InfoGrpRptService infoGrpRptService;
	
	@Autowired
	private RcmsContextAware rcmsContext;
	
	/**
	 * <pre>
	 * 確認使用者身份並取得常用報表的報表內容和view開啟所需的參數。
	 * </pre>
	 * @param search
	 * 			設定查詢結果
	 * @param request
	 *             用戶端所發出的請求之物件
	 * @return 常用報表查詢結果(RptContentMaster)和view開啟所需的參數(RptDefineMaster)
	 */
	@SuppressWarnings("serial")
	@HandlerType(HandlerTypeEnum.GRID)
	public GridResult query(ISearch search, IRequest request) {
				
		//簽核狀態
		final Map<String,String> apprvStatusMap = cfgCodeTypeRcmsService.findByCodeType("apprvStatus");
						
				
		long timeStart = Calendar.getInstance().getTimeInMillis();

		String rptId = null;
		String rptName = null;
		int rptSeqno = 0;
		String rptCycle =  null;
		String mustPrint = null;
		String rptDateBegin = null;
		String rptDateEnd = null;
		String pd = null;

		// 取得codeType
		final Map<String, String> governmentUnitMap = cfgCodeTypeRcmsService.findByCodeType("governingUnit");
		logger.debug("time spent : governmentUnitMap = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
		timeStart = Calendar.getInstance().getTimeInMillis();

		//依查詢條件:原簽核人員
		String strApprvUserId = request.get("q_selUserId");
		log.debug("strApprvUserId:"+strApprvUserId);
		
		//依查詢條件:原簽核人員的群組
		String[] selRptGrpIds = request.getParamsAsStringArray("q_selRptGrpIds");
		log.debug("selRptGrpIds="+selRptGrpIds.length);		
		
		logger.debug("time spent : infoGrpRpt's id array = " + (Calendar.getInstance().getTimeInMillis() - timeStart));
		timeStart = Calendar.getInstance().getTimeInMillis();								
		
		RcmsUserDetails user = CapSecurityContext.getUser();
		
		//分行資料
		log.debug("user.getUnitNo()="+user.getUnitNo());
		
		//若退回則預設經辦進入"待簽核報表"功能重新設定各簽核層級的人員
		//簽核狀態0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
		//報表改派只能針對簽核中(2)的進行改派 , 3: 簽核中(已退回) - 應在待簽核作業裡設定
		List<String> apprvStatusList = new ArrayList();
		apprvStatusList.add("2");//2:簽核中
		
		//20180315  加入empId判斷是否為總務或預設經辦
		//20180315 modify param infoGrpRptIds to Arrays.asList(selRptGrpIds)
		Page<VwRptContentApprvUserPDData> page = rptContentApprvUserService.getBySqlConditionAllApprvUser(search, rptId,
				Arrays.asList(selRptGrpIds), rptName, rptSeqno, rptCycle, mustPrint,pd, rptDateBegin, rptDateEnd,strApprvUserId,"N",user.getUserId());
		
		// 將報表週期改成中文
		for (VwRptContentApprvUserPDData rdm : page.getContent()) {
			String cycleValues = cfgCodeTypeRcmsService.getByValue("rptCycle",
					rdm.getRptCycle()).getCodeDesc();
			rdm.setRptCycle(cycleValues);
		}

		GridResult result = new GridResult(page.getContent(),page.getTotalRow());

		logger.debug("time spent : query = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
		timeStart = Calendar.getInstance().getTimeInMillis();

		// 從查詢result 取得本批筆數對映的RDM
		List<VwRptContentApprvUserPDData> vwRptIndexDataList = page.getContent();

		if (!vwRptIndexDataList.isEmpty()) {
			List<String> queryRptIds = new ArrayList<String>();
			for (VwRptContentApprvUserPDData vwData : vwRptIndexDataList) {
				queryRptIds.add(vwData.getRptContentMasterPK().getRptId());
			}
			
			//for個資  有版本
			List<VwRptDefineMaster> vwRdmList = vwRptDefineMasterService.getVwRptDefineMasterByRptids(queryRptIds);
			final Map<String, VwRptDefineMaster> vwRdmMap = new ConcurrentHashMap<String, VwRptDefineMaster>();
			for (VwRptDefineMaster rdm : vwRdmList) {
				vwRdmMap.put(rdm.getRptDefineMasterPK().getRptId() + "-"
						+ rdm.getRptDefineMasterPK().getRptVersion(), rdm);
			}
			
			//for其他RDM 欄位  取最新版
			List<RptDefineMaster> rdmList = rptDefineMasterService.getByRptIdList(queryRptIds);
			final Map<String, RptDefineMaster> rdmMap = new ConcurrentHashMap<String, RptDefineMaster>();
			for (RptDefineMaster rdm : rdmList) {
				rdmMap.put(rdm.getRptDefineMasterPK().getRptId(), rdm);
			}

			// FMT : codeType 業管單位
			result.addReformatData("rptMaterDept", new IBeanFormatter() {
				private static final long serialVersionUID = 1L;

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					String govUnitId = rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId())
							.getGoverningUnit();
					if (govUnitId != null && govUnitId.length() > 3) {
						govUnitId = govUnitId.substring(0, 3);
					}
					return governmentUnitMap.get(govUnitId);
				}
			});

			logger.debug("time spent : codeType governUnit = " + (Calendar.getInstance().getTimeInMillis() - timeStart));
			timeStart = Calendar.getInstance().getTimeInMillis();

			// FMT : RDM 報表類型
			result.addReformatData("rptType", new IBeanFormatter() {

				private static final long serialVersionUID = 1L;
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId()).getRptType();
				}
			});
			
			//必簽
			result.addReformatData("rptApprove", new IBeanFormatter() {
				
				private static final long serialVersionUID = 1L;
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					String rptid=((VwRptContentApprvUserPDData) in).getRptContentMasterPK().getRptId();
					List<String> approve = ((RcmsUserDetails) CapSecurityContext.getUser()).getApproveRptIds();
					if(approve.contains(rptid))
					return "Y";
					else
					return "N";
				}
			});

			// FMT : RDM 列印
			result.addReformatData("print", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId()).getPrint();
				}
			});

			// FMT : RDM 個資
			result.addReformatData("pd", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return vwRdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId()
									+ "-"
									+ ((VwRptContentApprvUserPDData) in)
											.getRptContentMasterPK()
											.getRptVersion()).getPd();
				}
			});

			// FMT : 收檔日期
			result.addReformatData("convertTimeStart", new IBeanFormatter() {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return sdf.format(ridv.getConvertTimeStart());
				}
			});
			
			// FMT : 收檔日期
			result.addReformatData("convertTimeStartFull", new IBeanFormatter() {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					log.debug("convertTimeStartFull="+sdf.format(ridv.getConvertTimeStart()));
					return sdf.format(ridv.getConvertTimeStart());
				}
			});
			
			// FMT : RCM轉檔日期
			result.addReformatData("rptReceiveDate", new IBeanFormatter() {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					
					return sdf.format(ridv.getConvertTimeStart());
				}
			});

			// FMT : RCM轉檔時間
			result.addReformatData("rptReceiveTime", new IBeanFormatter() {

				SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return sdf.format(ridv.getConvertTimeStart());
				}
			});
			
			// FMT : 預設經辦
			result.addReformatData("setUserId", new IBeanFormatter() {
				private static final long serialVersionUID = 1L;

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData rcam = (VwRptContentApprvUserPDData) in;
					String setUserId = rcam.getSetUserId();
					log.debug("setUserId="+setUserId);
					String setUserName = "";
					if (setUserId != null){
						setUserName = setUserId + "-" + aclUserService.getAclUserByUserId(setUserId).getEmpName();
						log.debug("setUserName="+setUserName);
					} 
					return setUserName;
				}
			});
			
			// FMT :PK
			result.addReformatData("id", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return ((VwRptContentApprvUserPDData) in).getId().toString();
				}
			});
			
			//逾期天數 overdueDays= 收檔日期 + 簽期期限(天數)  => 算出日期後 再扣掉 今天日期  的差距天數
			result.addReformatData("overdueDays", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					
					//逾期天數 : 收檔日期 + 簽期期限(天數)  => 算出日期後 再扣掉 今天日期  的差距天數
					if (ridv.getApprvStatus()!=null && ridv.getApprvStatus().equals("6"))
						return "0";
					else {
						if (ridv.getOverdueDays() < 0) 
							return "0";
						else
							return ridv.getOverdueDays()+"";
					}
				}
			});

			logger.debug("time spent : FMT RDM = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
			
			//簽核狀態 0:未設定  1:簽核中 3:簽核中(退回) 2:簽核中(作廢) 4:已作廢  5:已結案
			result.addReformatData("apprvStatus", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					log.debug("apprvStatus====" + ridv.getApprvStatus());
					log.debug("apprvStatus desc ====" + apprvStatusMap.get(ridv.getApprvStatus()));
					return (apprvStatusMap.get(ridv.getApprvStatus()));
				}
			});
			
		}

		return result;
	}
	
	/**
	 * <pre>
	 * 依登入使用者的角色判斷是否為分行-經理R004,總行-經理R010,分行-人事管理員R009,總行-人事管理員R011
	 * </pre>
	 * @param loginUserRoles 登入使用者的角色
	 * @param apprvMgrRoles 可執行放行的角色 - 分行-經理R004,總行-經理R010,分行-人事管理員R009,總行-人事管理員R011 定義在CFG_SYSPARAM 裡的apprv.mgrRoles
	 * @return
	 */
	private boolean isApprvMgr(String loginUserRole,String[] apprvMgrRoles){
		boolean isMgr = false;
		//for (String s : loginUserRoles) {
		if (ArrayUtils.contains(apprvMgrRoles, loginUserRole)){
			isMgr = true;
			return isMgr;
		}
		//}
		
		return isMgr;
	}
	
	/**
	 * 獲取用戶下拉框數據
	 * 
	 * @param request
	 *            IRequest
	 * @return AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult getAclUserList(IRequest request) {
		// String userId = request.get("userId");
		RcmsUserDetails user = CapSecurityContext.getUser();

		List<String> noInclude = new ArrayList<String>();
		// <2013/10/31因應華南需求做修改，總務可自行授權自己查表權限。>
		/*
		 * noInclude.add(user.getUserId()); if (!CapString.isEmpty(userId)) {
		 * noInclude.add(userId); }
		 */
		List<AclUser> list = aclUserService.findAclUserByUnit(user.getUnitNo(), noInclude);
		// logger.debug("get acluser list cnt="+list.size());
		AjaxFormResult afr = new AjaxFormResult();
		for (AclUser obj : list) {
			String empName = "";
			if (obj.getEmpName() != null) {
				empName = obj.getEmpName();
			}
			if (obj.getOffDate() == null)
				afr.set(obj.getEmpId(), empName);
		}
		/*CfgSysParm parm = parmSrv.getSysParmById("auth.op");
		if (parm != null) {
			if (user.getUnitNo().startsWith(parm.getParamValue())) {
				parm = parmSrv.getSysParmById("auth.dept");
				if (parm != null) {
					for (String q : parm.getParamValue().split(",")) {
						list = aclUserService.findAclUserByUnit(q, noInclude);
						if (list != null && !list.isEmpty()) {
							for (AclUser obj : list) {
								afr.set(obj.getEmpId(), obj.getEmpName());
							}
						}
					}
				}
			}
		}*/

		return afr;
	}

	/**
	 * 是否有未覆核的單子
	 * 
	 * @param request
	 *            IRequest
	 * @return AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult isReCheck(IRequest request) {
		String userId = null;
		if (!CapString.isEmpty(request.get("userId"))) {
			userId = request.get("userId");
		}
		AjaxFormResult afr = new AjaxFormResult();
		List<InfoGrpUserDraft> list = infoGrpUserDraftService.findInfoGrpUserDraftByCondition(userId, "01", null);
		afr.set("isReCheck", (list != null && !list.isEmpty()) ? "1" : "0");
		return afr;
	}

	/**
	 * 獲取群組下拉框
	 * 
	 * @param request
	 *            IRequest
	 * @return AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult getInfoGrpList(IRequest request) {

		AjaxFormResult afr = new AjaxFormResult();
		AjaxFormResult pms = new AjaxFormResult();
		String userId = request.get("userId");
		logger.debug("getInfoGrpList userId="+userId);
		
		for(InfoGrpUser grpUSer:  infoGrpUserService.findInfoGrpUserByConditions(userId, null)) {
			logger.debug("user's grpId:"+grpUSer.getInfoGrp().getGrpId() +", "+grpUSer.getInfoGrp().getGrpName());
			afr.set(grpUSer.getInfoGrp().getGrpId(), grpUSer.getInfoGrp().getGrpName());
		}
		
		/*
		// 判斷是否分行/總行-使用單位代號第一碼0與1區分總行與分行,例外102 國際金融部係屬於總行單位,070是分行非總行
		List<Map<String, Object>> list = infoGrpService
				.findInfoGrpByIdType(!CapString.checkRegularMatch(user.getUnitNo(), "(^0)|(^102)")
						|| CapString.checkRegularMatch(user.getUnitNo(), "(^070)"), user.getUnitNo());

		CfgCodeTypeFormatter codeFmt = new CfgCodeTypeFormatter(codeSrv, "permissionCategory");
		for (Map<String, Object> obj : list) {
			afr.set((String) obj.get("grpId"), (String) obj.get("grpName"));
			try {
				pms.set((String) obj.get("grpId"), codeFmt.reformat(obj.get("permission")));
			} catch (Exception e) {
				pms.set((String) obj.get("grpId"), "");
			}
		}
		List<InfoGrpUser> grpUser = infoGrpUserService.findInfoGrpUserByConditions(userId, null);
		for (InfoGrpUser grp : grpUser) {
			afr.removeField(grp.getInfoGrp().getGrpId());
		}
		if (!afr.isEmpty()) {
			List<InfoGrpUserDraft> grpUserDraft = infoGrpUserDraftService.findInfoGrpUserDraftByCondition(userId, null,
					null);
			for (InfoGrpUserDraft grp : grpUserDraft) {
				afr.removeField(grp.getInfoGrp().getGrpId());
			}
		}
		*/
		
		AjaxFormResult result = new AjaxFormResult();
		result.set("grpOps", afr);
		result.set("grpPms", pms);
		return result;
	}

	/**
	 * 從使用者 複製權限
	 * 
	 * @param request
	 *            IRequest
	 * @return AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult copyInfoGrpUser(IRequest request) {
		String userId = null;

		if (!CapString.isEmpty(request.get("userId"))) {
			userId = request.get("userId");
		}

		AjaxFormResult afr = new AjaxFormResult();
		List<InfoGrpUser> list = infoGrpUserService.findInfoGrpUserByCondition(userId, null, null, null);

		if (!list.isEmpty()) {
			ADDateFormatter dateFormatter = new ADDateFormatter();
			CfgCodeTypeFormatter permissionFmt = new CfgCodeTypeFormatter(codeSrv, "permissionCategory");
			CfgCodeTypeFormatter stateFmt = new CfgCodeTypeFormatter(codeSrv, "approveState");
			JSONArray rows = new JSONArray();
			for (InfoGrpUser obj : list) {
				Map<String, String> row = new HashMap<String, String>();
				if (obj.getInfoGrp() != null && obj.getInfoGrp().getInfoGrpPermission() != null
						&& obj.getInfoGrp().getInfoGrpPermission().getPermission() != null) {
					row.put("infoGrpPermission",
							permissionFmt.reformat(obj.getInfoGrp().getInfoGrpPermission().getPermission()));
				}
				row.put("id.grpId", obj.getInfoGrp().getGrpId());
				row.put("infoGrp.grpName", obj.getInfoGrp().getGrpName());

				row.put("effDateStart", dateFormatter.reformat(obj.getEffDateStart()));
				row.put("effDateEnd", dateFormatter.reformat(obj.getEffDateEnd()));
				row.put("dataStateNM", obj.getDataState());
				row.put("action", stateFmt.reformat(obj.getAction()));
				rows.add(row);
			}
			afr.set("copyData", rows.toString());
		}
		return afr;
	}

	
	/**
	 * <pre>
	 * 依登入人員的單位代號查詢出該單位內所有人員及主管員編和姓名
	 * </pre>
	 * @param request
	 *            用戶端所發出的請求之物件
	 * @return afr
	 * 			AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult getAllUser(IRequest request) {
		AjaxFormResult afr = new AjaxFormResult();
		AjaxFormResult afrMgr = new AjaxFormResult();
		
		RcmsUserDetails user = CapSecurityContext.getUser();
		String strDivisionId = user.getUnitNo();
		log.debug("getAllUser strDivisionId="+strDivisionId);
		//查詢單位內人員資料
		List<AclUser> list = aclUserService.getAclUserByCondition( null, null ,strDivisionId);
		
		for (AclUser obj : list) {
			afr.set((String) obj.get("empId"), (String) obj.get("empName"));
		}
		
		//查詢單位內主管資料
		List<AclUser> listMgr = aclUserService.getAclUserMgrByCondition(strDivisionId);
		for (AclUser obj2 : listMgr) {
			afrMgr.set((String) obj2.get("empId"), (String) obj2.get("empName"));
		}
		
		AjaxFormResult result = new AjaxFormResult();
		
		result.set("empOps", afr);
		result.set("mgrOps", afrMgr);
		
		return result;
	}
	
	/**
	 * 獲取目前登入使用者(被代理人預設選取)
	 * 
	 * @param request
	 *            IRequest
	 * @return AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult getLoginUserId(IRequest request) {
		// String userId = request.get("userId");
		RcmsUserDetails user = CapSecurityContext.getUser();
		AjaxFormResult afr = new AjaxFormResult();
		log.debug("登入使用者員編="+user.getUserId());
		afr.set("loginUserId", user.getUserId());
		afr.set("loginUserUnitNo", user.getUnitNo());
		return afr;
	}
	
	/**
	 * <pre>
	 * 	整批改派-修改簽核人員
	 *  須檢查
	 *  1.同一張報表的各簽核人員不能重覆
	 *  2.若被選取的人員沒有該報表的權限須顯示訊息,但仍可以設定(待確認)
	 *  3.若是決行則須改派給主管(不能設定,前端要顯示訊息)
	 *  
	 *  TODO 若為跨單位 要如何處理?
	 * </pre>
	 * @param request
	 * @return
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult doResetting(IRequest request) {
		
		AjaxFormResult afr = new AjaxFormResult();
		try {
		
			String loginUserId = CapSecurityContext.getUserId();
			
			//原本的簽核人員
			String oriSelUserId = (String)request.get("oriSelUserId");
			
			//改派後的簽核人員
			String selUserId = (String)request.get("selUserId");
			log.debug("doResetting selUserId="+selUserId);
			log.debug("doResetting oriSelUserId="+oriSelUserId);
			
			//選取的資料的id值
			String[] selIds= request.getParamsAsStringArray("selectdata");

			
			int n=selIds.length;
			
			String resultMsg ="";
			
			//取得可以進行放行的角色
			CfgSysParm parm = parmSrv.getSysParmById("apprv.mgrRoles");
			String[] apprvMgrRoles = parm.getParamValue().split(" ");
			
			Date sysDate = new Date();
			for (int t = 0; t < n; t++) {
				
				String id  = selIds[t];
				log.debug("doResetting t=" + t + "id:" + id);
				
				RptContentApprvUser main = rptContentApprvUserService.getByPk(Long.parseLong(id));
				
				List<RptContentApprvUser> apprvUsers = rptContentApprvUserService.getBySqlCondition(main.getRptId(), 
						main.getRptSeqno().intValue(),main.getRptDate(), main.getRptVersion(), main.getRptBranch());
				
				//檢查:同一張報表的各簽核人員不能重覆
				for(RptContentApprvUser e:apprvUsers){
					if (e.getApprvUser().equals(selUserId)){
						resultMsg = resultMsg +"報表代號:"+main.getRptId()+",序號:"+main.getRptSeqno().toString()+" 簽核人員("+ selUserId+")已存在"+"<br>";
					}
					
					//檢查決行的人員是否為主管
					if (e.getApprvUser().equals(selUserId) && e.getApprvStep().equals("End")){
						String roleId = aclUserService.getAclUserByUserId(selUserId).getAclRole().getRoleID();
						boolean isMgr = isApprvMgr(roleId, apprvMgrRoles);
						log.debug("selUserId="+selUserId+",roleId:"+roleId+",isMgr:"+isMgr);
								
						if (!isMgr)
						resultMsg = resultMsg +"報表代號:"+main.getRptId()+",序號:"+main.getRptSeqno().toString()+"("+ oriSelUserId+")為決行簽核人員,改派人員請選擇主管"+"<br>";
					}
				}
				
				if (resultMsg.length()>0){
					afr.set("result", "error");
					afr.set("resultMsg", resultMsg);
					return afr;
				} 
				
				if (main != null) {
					main.setUpdater(loginUserId);
					main.setUpdateTime(sysDate);
					main.setApprvUser(selUserId);
					if (main.getApprvUserDept() == null){
						main.setApprvUserDept(CapSecurityContext.getUnitNo());
					}
					rptContentApprvUserService.update(main);
				}
			}
			log.debug("doResetting--------------------loginUserId="+loginUserId+",resultMsg="+resultMsg);
			
			if (resultMsg.length()>0){
				afr.set("result", "error");
				afr.set("resultMsg", resultMsg);
			} else {
				afr.set("result", "success");
			}
			
		} catch(Exception e){
			log.error(e.getMessage());
			afr.set("result", "error");
		}

		return afr;
	}

}


