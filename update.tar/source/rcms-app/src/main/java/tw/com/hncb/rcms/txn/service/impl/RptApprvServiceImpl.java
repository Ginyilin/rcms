/* 
 * RptApprvServiceImpl.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.txn.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iisigroup.cap.response.AjaxFormResult;
import com.iisigroup.cap.security.CapSecurityContext;
import com.iisigroup.cap.service.AbstractService;

import net.sf.json.JSONObject;
import tw.com.hncb.rcms.acl.core.RcmsUserDetails;
import tw.com.hncb.rcms.com.service.RcmsEmailService;
import tw.com.hncb.rcms.dao.RptDefineFormFieldDao;
import tw.com.hncb.rcms.dao.RptDefineFormPageDao;
import tw.com.hncb.rcms.dao.VwRptContentMasterDao;
import tw.com.hncb.rcms.model.AclUser;
import tw.com.hncb.rcms.model.CfgSysParm;
import tw.com.hncb.rcms.model.InfoGrpRpt;
import tw.com.hncb.rcms.model.InfoGrpUser;
import tw.com.hncb.rcms.model.InfoUserDeputy;
import tw.com.hncb.rcms.model.RptContentApprv;
import tw.com.hncb.rcms.model.RptContentApprvHis;
import tw.com.hncb.rcms.model.RptContentApprvUser;
import tw.com.hncb.rcms.txn.service.AclBranchTransferService;
import tw.com.hncb.rcms.txn.service.AclUserService;
import tw.com.hncb.rcms.txn.service.CfgCodeTypeRcmsService;
import tw.com.hncb.rcms.txn.service.CfgSysParmService;
import tw.com.hncb.rcms.txn.service.InfoGrpPermissionService;
import tw.com.hncb.rcms.txn.service.InfoGrpRptService;
import tw.com.hncb.rcms.txn.service.InfoGrpService;
import tw.com.hncb.rcms.txn.service.InfoGrpUserService;
import tw.com.hncb.rcms.txn.service.InfoUserDeputyService;
import tw.com.hncb.rcms.txn.service.RptApprvService;
import tw.com.hncb.rcms.txn.service.RptContentApprvHisService;
import tw.com.hncb.rcms.txn.service.RptContentApprvService;
import tw.com.hncb.rcms.txn.service.RptContentApprvUserService;

/**<pre>
 * 簽核作業相關Service
 * </pre>
 * @since  2017/3/31
 * @author jean
 * @version <ul>
 *           <li>2017/3/31,jean,new
 *          </ul>
 */
@Service
public class RptApprvServiceImpl extends AbstractService implements
		RptApprvService {
	
	private static Log log = LogFactory.getLog(RptApprvServiceImpl.class);

	@Autowired
	RptDefineFormPageDao rptDefineFormPageDao;

	@Autowired
	RptDefineFormFieldDao rptDefineFormFieldDao;

	@Autowired
	VwRptContentMasterDao vwRptContentMasterDao;

	@Autowired
	RptContentApprvUserService rptContentApprvUserService;

	@Autowired
	RptContentApprvService rptContentApprvService;

	@Autowired
	InfoGrpPermissionService infoGrpPermissionService;
	
	@Autowired
	CfgCodeTypeRcmsService cfgCodeTypeRcmsService;

	@Autowired
	AclUserService aclUserService;
	
	@Autowired
	RptContentApprvHisService rptContentApprvHisService;

	/** 存取系統參數table[CFG_SYSPARM]的Service */
	@Autowired
	CfgSysParmService cfgSysParmService;
	
	/**發送Email之服務介面*/
	@Autowired
	private RcmsEmailService rcmsEmailSrv;
	
	@Autowired
	private InfoGrpUserService infoGrpUserService;
	
	@Autowired
	private InfoGrpRptService infoGrpRptService;
	
	@Autowired
	private InfoGrpService infoGrpService;
	
	@Autowired
	private InfoUserDeputyService infoUserDeputyService;
	
	@Autowired
	private AclBranchTransferService aclBranchTransferService;

	//for convertTime
	//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	
	/**
	 * 查詢該報表下一個待簽的簽核層級
	 * @param RptContentApprv 簽核主檔資料
	 * @param convertTimeStart 收檔時間(起)
	 * @return 簽核層級(1...End)
	 */
	@Override
	public String getNextApprvStep(RptContentApprv main,String convertTimeStart){
		
		String nextApprvStep = rptContentApprvUserService.getMinApprvStep(main.getRptId(), main.getRptSeqno().intValue(), 
				main.getRptDate(), main.getRptVersion(), main.getRptBranch(), convertTimeStart);
		
		log.debug("nextApprvStep="+nextApprvStep);
		return nextApprvStep;
		
	}
	
	/**
	 * 修改簽核主檔資料
	 * @param loginUserId 登入人員員編
	 * @param setUserId 預設經辦員編
	 * @param apprvUser 簽核人員員編
	 * @param unitNo 登入人員的單位代號
	 * @param rptContentApprv 簽核主檔
	 * @param currentApprvStep 欲修改的簽核層級
	 * @param sysDate 系統日期
	 * @param apprvStatus 簽核狀態
	 */	
	@Override
	public void updateRptContentApprv(String loginUserId,String setUserId,String apprvUser,String unitNo,RptContentApprv rptContentApprv,String currentApprvStep,Date sysDate,String apprvStatus){
		if (setUserId != null)
		rptContentApprv.setSetUserId(setUserId);
		//目前簽核層級,要由原本的流程未走完的往下走
		rptContentApprv.setApprvStep(currentApprvStep); //若第1關只有1人,則目前簽核層級直接變更為2, 若有多人,表示第一層級要會簽(須第1層的全部人會簽完才會送到第2層級),則更新簽核層級為1
		rptContentApprv.setApprvStatus(apprvStatus);	//報表目前簽核狀態  0:未設定 , 1:已簽核(RptContentApprv不會有此狀態,RptContetntApprvUser才會有) 2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案
		if (apprvUser != null)
		rptContentApprv.setApprvUser(apprvUser); 	    //目前待簽核人員員編 TODO 若第1關選多人為會簽 ? 會簽人員會有多個,須看RptContentApprvUser
		if (unitNo != null)
		rptContentApprv.setSetDivisionId(unitNo);       //預設經辦所屬單位
		if (loginUserId != null)
		rptContentApprv.setUpdater(loginUserId);
		rptContentApprv.setUpdateTime(sysDate);
		rptContentApprvService.update(rptContentApprv);
	}
	
	/**
	 * 寫入一筆簽核歷程
	 * @param rptContentApprvUser
	 * @param rptSeqno
	 * @param rptVersion
	 * @param apprvComment
	 * @param loginUserId
	 * @param sysDate
	 */
	@Override
	public void saveRptContentApprvHistory(RptContentApprvUser rptContentApprvUser,int rptSeqno,int rptVersion,String apprvComment,
			String loginUserId,String loginUserName,Date sysDate,String apprvAction,String apprvStatus){
		//寫入一筆簽核歷程
		RptContentApprvHis o = new  RptContentApprvHis();
		//RptContentApprvHistory o = new RptContentApprvHistory(rptContentApprvUser);
		
		o.setSetUserId(rptContentApprvUser.getSetUserId());
		o.setConvertTimeEnd(rptContentApprvUser.getConvertTimeEnd());
		o.setRptId(rptContentApprvUser.getRptId());
		o.setRptBranch(rptContentApprvUser.getRptBranch());
		o.setMustPrint(rptContentApprvUser.getMustPrint());
		o.setKeepYear(rptContentApprvUser.getKeepYear());
		o.setRptCycle(rptContentApprvUser.getRptCycle());
		o.setRptDate(rptContentApprvUser.getRptDate());
		o.setRptName(rptContentApprvUser.getRptName());
		o.setRptSeqno(new BigDecimal(rptSeqno));
		o.setRptVersion(rptVersion);
		o.setIndexGrpId("1");
		o.setConvertTimeStart(rptContentApprvUser.getConvertTimeStart());
		o.setSetDivisionId(rptContentApprvUser.getSetDivisionId());
		
		
		//o.setApprvUserName(rptContentApprvUser.getApprvUserName()); //format : "HB0016-XXXX"
		if (!loginUserId.equals(rptContentApprvUser.getApprvUser())){//代理人代簽才要寫入
			o.setApprvUserName(loginUserId+"-"+loginUserName); //format : "HB0016-XXXX" , 若為
		}
		o.setApprvComment(apprvComment);
		o.setApprvUser(rptContentApprvUser.getApprvUser());//原本設定的該簽核層級的人員員編
		//報表簽核動作 1.確認送出、2.會簽、3.覆核、4.核准、5.退回   6.作廢重簽  7.作廢重簽(放行) 8.作廢重簽(退回)
		o.setApprvAction(apprvAction);
		o.setApprvTime(sysDate);//簽核時間
		o.setCreator(loginUserId);
		o.setCreateTime(sysDate);
		o.setApprvStep(rptContentApprvUser.getApprvStep());
		////0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回  8.已退回(作廢)
		o.setApprvStatus(apprvStatus);
		
		log.debug("saveRptContentApprvHistory,RptContentApprvHistory="+o.toString());
		rptContentApprvHisService.insert(o);
	}
	
	/**
	 * <pre>
	 * 刪除原本於RptContentApprvUser 未簽核(isApprv=N)的人員ID
	 * </pre>
	 * @param apprvUserDataObj 原本的RptContentApprvUser的設定資料
	 * 
	 * @return
	 */
	@Override
	public void deleteOrigialUnApprvedUsers(JSONObject originalApprvUserDataObj,RptContentApprv main,String convertTimeStart,String excludeIsApprv){
		//apprvSte, HB00VV|Y,HB0493|Y
		List<String> list = new ArrayList();
		Set<String> apprvStepSet = originalApprvUserDataObj.keySet();
		
		for (String apprvStep : apprvStepSet) {
			//animals.trim().split("\\s*,\\s*");
			log.debug("deleteOrigialUnApprvedUsers apprvStep="+apprvStep);
			String apprvUserIds = originalApprvUserDataObj.getString(apprvStep);
			log.debug("deleteOrigialUnApprvedUsers apprvUserIds="+apprvUserIds);
			String[] arrApprvUserIds = apprvUserIds.trim().split("\\s*,\\s*");
			for (int i = 0 ; i <arrApprvUserIds.length;i++){
				String[] data = arrApprvUserIds[i].split("\\|");
				//String isApprv = data[1];
				
				log.debug("deleteOrigialUnApprvedUsers userId 00="+data[0]+",isApprv="+data[1]);
				
				if (excludeIsApprv!=null && excludeIsApprv.equals("Y")){
					if (data[1] != null && data[1].equals("N")){
						list.add(data[0]);
					}
				} else if (data[1] != null){
					list.add(data[0]);
				}
			}
		}
				 
		/*log.debug("apprvUserDataObj 1="+originalApprvUserDataObj.getString("1"));//format: HB00VV|Y,HB0493|Y
		log.debug("apprvUserDataObj 2="+originalApprvUserDataObj.getString("2"));//format: HB0761|Y,HB0665|N
		log.debug("apprvUserDataObj End="+originalApprvUserDataObj.getString("End"));*/
		
		log.debug("deleteOrigialUnApprvedUsers list="+list.size());
		
		if (list!=null && list.size()>0){
			int  cntDel = rptContentApprvUserService.deleteUsers(main.getRptId(), main.getRptSeqno().intValue(), main.getRptDate(), main.getRptVersion(), 
					main.getRptBranch(), convertTimeStart, list);
			
			log.debug("deleteOrigialUnApprvedUsers cntDel="+cntDel);
		}
	}
	
	
	/**
	 * <pre>
	 * 寫入或更新報表簽核人員設定檔
	 * 每一簽核層級有多少人(會簽) 則寫入幾筆
	 * </pre>
	 * @param rptContentApprv
	 * @param loginUserId
	 * @param sysDate
	 * @param apprvUser
	 * @param apprvStep
	 * @param apprvType
	 * @param isApprv
	 * @param apprvStatus 0:未設定 , 1:已簽核  2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案
	 */
	@Override
	public RptContentApprvUser saveRptContentApprvUser(RptContentApprv rptContentApprv,String loginUserId,Date sysDate,
			String apprvUser,String apprvUserDepCode,String apprvStep,String apprvType,String isApprv,String apprvStatus,String setDivisionId){
		
		RptContentApprvUser oldRptContentApprvUser = rptContentApprvUserService.getOneBySqlCondition(
				rptContentApprv.getRptId(), rptContentApprv.getRptSeqno().intValue(), rptContentApprv.getRptDate(),
				rptContentApprv.getRptVersion(), rptContentApprv.getRptBranch(), apprvStep, apprvUser);
		
		//若原本資料裡已簽核(isApprv=Y)則不能修改
		/*if (oldRptContentApprvUser != null && oldRptContentApprvUser.getIsApprv()!=null && oldRptContentApprvUser.getIsApprv().equals("Y")){
			log.debug("oldRptContentApprvUser(isApprv:Y)="+oldRptContentApprvUser.toString());
		} else if (oldRptContentApprvUser != null && oldRptContentApprvUser.getIsApprv()!=null && oldRptContentApprvUser.getIsApprv().equals("N")){
			//應是不會有這種狀況 因預設經辦設定完即按下[確認送出] 
			log.debug("oldRptContentApprvUser(isApprv:N)="+oldRptContentApprvUser.toString());
		} else {*/
			//2.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
			RptContentApprvUser dataUser = new RptContentApprvUser(rptContentApprv);
			dataUser.setCreator(loginUserId);
			dataUser.setCreateTime(sysDate);
			dataUser.setSetUserId(loginUserId);
			dataUser.setSetDivisionId(setDivisionId);
			dataUser.setApprvStep(apprvStep); ///** 簽核層級 1,2,3,4 ...End */
			dataUser.setApprvUser(apprvUser);
			dataUser.setIsApprv(isApprv);
			dataUser.setApprvType(apprvType);/** 1.會簽, 2.覆核, 3.主管  */
			dataUser.setApprvUserDept(apprvUserDepCode);
			
			/*dataUser.setSetDivisionId(rptContentApprv.getSetDivisionId());
			dataUser.setSetUserId(rptContentApprv.getSetUserId());
			dataUser.setRptName(rptContentApprv.getRptName());
			dataUser.setMustPrint(rptContentApprv.getMustPrint());*/
		
			//報表簽核狀態 
			//0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
			dataUser.setApprvStatus(apprvStatus);
			
			log.debug("saveOrUpdateRptContentApprvUser RptContentApprvUser ="+dataUser.toString());
			rptContentApprvUserService.insert(dataUser);
			
			return dataUser;
		//}
	}
	
	/**
	 * 修改單筆簽核人員設定資料
	 * @param rptContentApprvUser
	 * @return 修改過的 簽核人員設定資料 RptContentApprvUser
	 */
	@Override
	public RptContentApprvUser updateRptContentApprvUser(RptContentApprvUser rptContentApprvUser){
		
			log.debug("updateRptContentApprvUser RptContentApprvUser ="+rptContentApprvUser.toString());
			rptContentApprvUserService.updateById(rptContentApprvUser.getId(), rptContentApprvUser.getApprvStatus(), 
					rptContentApprvUser.getUpdateTime(), rptContentApprvUser.getUpdater(), rptContentApprvUser.getIsApprv(),rptContentApprvUser.getApprvStep());
			
			return rptContentApprvUser;
	}
	
	
	/**
	 *  0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回 8.已退回(作廢)
	 * @param apprvStatus
	 * @return
	 */
	@Override
	public String getApprvStatusDesc(String apprvStatus){
		//簽核狀態
		final Map<String,String> apprvStatusMap = cfgCodeTypeRcmsService.findByCodeType("apprvStatus");
		return apprvStatusMap.get(apprvStatus);
		
	}
	
	/**
	 * 找出下一個簽核層級的簽核人員
	 * @return
	 */
	@Override
	public List<RptContentApprvUser> getNextApprvUser(RptContentApprvUser currentApprvUser , List<RptContentApprvUser>  list){
		
		if (currentApprvUser.getApprvStep().equals("End")) 
			return null;
		
		List<RptContentApprvUser>  result = new ArrayList<RptContentApprvUser>();
		
		/*List<RptContentApprvUser>  list = rptContentApprvUserService.getBySqlCondition(currentApprvUser.getRptId(), 
				currentApprvUser.getRptSeqno().intValue(), currentApprvUser.getRptDate(), 
				currentApprvUser.getRptVersion(), currentApprvUser.getRptBranch());*/
		
		String currentApprvStep = currentApprvUser.getApprvStep();
		log.debug("getNextApprvUser currentApprvStep="+currentApprvStep);
		String nextApprvStep = String.valueOf(Integer.parseInt(currentApprvStep) + 1);
		log.debug("getNextApprvUser nextApprvStep="+nextApprvStep);
		
		
		for(int i=0;i<list.size();i++){
			RptContentApprvUser  e = list.get(i);
			if (e.getApprvStep() != null && e.getApprvStep().equals(nextApprvStep)){
				result.add(e);
			}
		}
		
		for(RptContentApprvUser a:result){
			log.debug("getNextApprvUser a 00 ="+a.getApprvUser());
		}
		
		//
		if (result.isEmpty()){
			for(int i=0;i<list.size();i++){
				RptContentApprvUser  e = list.get(i);
				if (e.getApprvStep() != null && e.getApprvStep().equals("End")){
					result.add(e);
				}
			}
			
		}
		
		for(RptContentApprvUser a:result){
			log.debug("getNextApprvUser a 11="+a.getApprvUser()+",apprvStep:"+a.getApprvStep());
		}
			
		return result;
		
	}
	
	/**
	 * 檢查第1關的預設經辦(第1次設定該報表的人員)是否有換單位或是已離職
	 * 若有自動寄給單位總務以進行報表改派
	 */
	@Override
	public AjaxFormResult doCheckSetApprvUser(RptContentApprvUser currentRptContentApprvUser,String loginUserId,Date sysDate){
		
		AjaxFormResult afr = new AjaxFormResult();
		String errorEmpDataDesc = "";
		
		try {
			//總務的角色代號
			CfgSysParm cfgSysParm = cfgSysParmService.getSysParmById("apprv.roleId");
			/* 收件人信箱String array*/
			//String[] sendTo = new String[] {};
			
			String subject ="";
			String sendContext="";
			List<String> listOfSendTo = new ArrayList<String>();
			
			//找出第一關的設定人員
			AclUser aclUser = aclUserService.getAclUserByUserId(currentRptContentApprvUser.getSetUserId());
			//log.debug("doCheckSetApprvUser aclUser="+aclUser.toString());
				
			//若下一層級的人已調動單位 
			//2017.12.19  加上判斷退休人員(offdate 有值)
			if (!currentRptContentApprvUser.getApprvUserDept().equals(aclUser.getDivisionId())
					|| (aclUser.getOffDate() != null)
					|| (aclUser.getStatus() != null && aclUser.getStatus().equals("A"))) {

				errorEmpDataDesc = errorEmpDataDesc + aclUser.getEmpId() + "-" + aclUser.getEmpName() + "\r\n";

				// 1.寄給預設經辦和單位總務以進行改派
				if (aclUser.getEmail() != null && aclUser.getEmail().indexOf('@') > 0) {
					// sendTo[0] = aclUser.getEmail();
					listOfSendTo.add(aclUser.getEmail());
				}
				// 查出單位內的總務
				List<AclUser> list = aclUserService.getAclUserByConditionAndDivision(null, null,
						cfgSysParm.getParamValue(), null, aclUser.getDivisionId());

				if (list != null && list.size() > 0) {
					for (AclUser user : list) {
						if (user.getEmail() != null && user.getEmail().indexOf('@') > 0) {
							log.debug("單位總務 user=" + user.getEmpId() + ",email=" + user.getEmail());
							listOfSendTo.add(user.getEmail());
						}
					}
				}
				
				afr.set("error", "簽核人員(預設經辦)單位已異動:" + errorEmpDataDesc);
				
				if (listOfSendTo != null && listOfSendTo.size()>0){
					// Body
					sendContext = getMailBody(currentRptContentApprvUser, errorEmpDataDesc);
	
					// Subject
					subject = getMailSubject(currentRptContentApprvUser.getRptId());
	
					// Mail Reciever
					String[] sendTo = listOfSendTo.toArray(new String[0]);
					rcmsEmailSrv.sendEmail(sendTo, subject, sendContext);
					log.debug("doCheckSetApprvUser email done");
				}
			}
		} catch(Exception ex){
			log.error(ExceptionUtils.getFullStackTrace(ex));
		}
		
		return afr;
		
		
	}
	
	/**
	 * 檢查下一簽核層級的人員是否有換單位或是已離職
	 * 若有自動寄給經辦及單位總務以進行報表改派
	 */
	@Override
	public AjaxFormResult doCheckNextApprvUser(RptContentApprvUser currentRptContentApprvUser,String loginUserId,Date sysDate,List<RptContentApprvUser>  apprvUserList){
		
		log.debug("doCheckNextApprvUser--------------------start");
		AjaxFormResult afr = new AjaxFormResult();
		
		String errorEmpDataDesc = "";
		
		try {
			//總務的角色代號
			CfgSysParm cfgSysParm = cfgSysParmService.getSysParmById("apprv.roleId");
			
			//找出下一關的簽核人員 可能會有多個人員 都要檢查
			List<RptContentApprvUser> nextRptContentApprvUsers = getNextApprvUser(currentRptContentApprvUser,apprvUserList);
			
			if (nextRptContentApprvUsers != null && nextRptContentApprvUsers.size()>0){
				
				log.debug("doCheckNextApprvUser--------------------nextRptContentApprvUsers.size="+nextRptContentApprvUsers.size());
				for (RptContentApprvUser nextRptContentApprvUser : nextRptContentApprvUsers ){
				
						/* 收件人信箱String array*/
						//String[] sendTo = new String[] {};
						
						String subject ="";
						String sendContext="";
						List<String> listOfSendTo = new ArrayList<String>();
						
						AclUser aclUser = aclUserService.getAclUserByUserId(nextRptContentApprvUser.getApprvUser());
						//log.debug("doCheckNextApprvUser aclUser="+aclUser.toString());
						
						//若下一層級的人已調動單位
						//2017.12.19  加上判斷退休人員(offdate 有值)
						if (!nextRptContentApprvUser.getApprvUserDept().equals(aclUser.getDivisionId()) 
								|| (aclUser.getOffDate() != null)
								|| (aclUser.getStatus() != null && aclUser.getStatus().equals("A"))){
							
							errorEmpDataDesc = errorEmpDataDesc + aclUser.getEmpId() + "-" + aclUser.getEmpName() + "\r\n";
							
							//1.找出預設經辦的Email 
							if (aclUser.getEmail() != null && aclUser.getEmail().indexOf('@')>0){
								//sendTo[0] = aclUser.getEmail();
								
								listOfSendTo.add(aclUser.getEmail());
							}
							//2.單位內的總務的Email
							List<AclUser> list = aclUserService.getAclUserByConditionAndDivision(null, null, cfgSysParm.getParamValue(), null, aclUser.getDivisionId());
							
							if (list != null && list.size()>0){
								log.debug("list size 查出單位內的總務 =" + list.size());
								for (AclUser user:list){
									if (user.getEmail()!=null && user.getEmail().indexOf('@')>0){
										log.debug("單位總務 user="+user.getEmpId()+",email="+user.getEmail());
										listOfSendTo.add(user.getEmail());
									}
								}
							}
							
							afr.set("error", "簽核人員單位已異動:" + errorEmpDataDesc);	
							
							if (listOfSendTo.size() > 0){
								//Body
								sendContext = getMailBody(currentRptContentApprvUser, errorEmpDataDesc);
								//Subject
								subject = getMailSubject(currentRptContentApprvUser.getRptId());
								//Mail Reciever
								String[] sendTo = listOfSendTo.toArray(new String[0]);
								rcmsEmailSrv.sendEmail(sendTo, subject, sendContext);
								log.debug("doCheckNextApprvUser email done ");
							}
					}//if apprvUserDept changed end
				}//for end
			}
		} catch(Exception ex){
			log.error(ExceptionUtils.getFullStackTrace(ex));
		}

		return afr;
		
		
	}
	
	private String getMailSubject(String rptId){
		/* 信件主題*/
		StringBuffer subject = new StringBuffer().append("報表集中管理系統")
				.append("_").append("簽核作業_簽核層級人員異動通知![報表代號:"+rptId+"]");
		return subject.toString();
	}
	
	private String getMailBody(RptContentApprvUser rptContentApprvUser,String desc){
		/*信件內容*/
		StringBuffer sendContext = new StringBuffer()
				.append("報表代號 : ")
				.append(rptContentApprvUser.getRptId())
				.append("\r\n")
				.append("版本: ")
				.append(String.valueOf(rptContentApprvUser.getRptVersion()))
				.append("\r\n")
				.append("序號: ")
				.append(String.valueOf(rptContentApprvUser.getRptSeqno()))
				.append("\r\n")
				.append("報表日期: ")
				.append(String.valueOf(rptContentApprvUser.getRptDate()))
				.append("\r\n")
				.append("異動簽核層級人員 : ")
				.append(desc)
				.append("\r\n")
				.append("\r\n")
				.append("請至[報表改派]功能重設指定簽核人員")
				.append("\r\n")
				.append("--------------------------------------------------------------------------------\r\n")
				;
		
		return sendContext.toString();
	}
	
	/**
	 * 修改簽核人員設定資料的簽核狀態為已簽核
	 * @param rptContentApprvUser 簽核人員設定資料
	 * @param apprvComment 簽核意見
	 * @param sysDate 系統日期
	 * @param loginUserId 登入人員員編
	 * @param loginUserName 登入人員姓名
	 * @param realApprvUserId 實際簽核人員員編
	 * @return AjaxFormResult
	 */
	@Override
	public AjaxFormResult updateRptToApprove(RptContentApprvUser rptContentApprvUser,
			String apprvComment,Date sysDate,String loginUserId,String loginUserName,String realApprvUserId){
		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		String strConverTimeStart = sdf.format(rptContentApprvUser.getConvertTimeStart());
		log.debug("updateRptToApprove strConverTimeStart:"+strConverTimeStart);
		return this.updateRptToApprove(rptContentApprvUser.getRptId(),rptContentApprvUser.getRptVersion(),rptContentApprvUser.getRptDate(),
				rptContentApprvUser.getRptSeqno().intValue(),rptContentApprvUser.getRptBranch(),
				apprvComment,strConverTimeStart,sysDate,loginUserId,loginUserName,realApprvUserId);
	}
	
	/**
	 * 單筆退回 - 一律退回第1關
	 * @param rptContentApprvUser
	 * @param apprvComment
	 * @param sysDate
	 * @return AjaxFormResult
	 */
	@Override
	public AjaxFormResult updateRptToReject(RptContentApprvUser rptContentApprvUser,
			String apprvComment,Date sysDate,String loginUserId,String loginUserName,String realApprvUserId,String realApprvUserUnitNo){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		String strConverTimeStart = sdf.format(rptContentApprvUser.getConvertTimeStart());
		log.debug("updateRptToReject strConverTimeStart:"+strConverTimeStart);
		return this.updateRptToReject(rptContentApprvUser.getRptId(),rptContentApprvUser.getRptVersion(),rptContentApprvUser.getRptDate(),
				rptContentApprvUser.getRptSeqno().intValue(),rptContentApprvUser.getRptBranch(),
				apprvComment,strConverTimeStart,sysDate,loginUserId,loginUserName,realApprvUserId,realApprvUserUnitNo);
	}
	
	/**
	 * 非跨單位簽核:若在第一段流程內退回,則回到第一段的預設經辦;若在第二段的流程退回則回到第二段的預設經辦
	 * 跨單位簽核 : 退回一律回到第1關(預設經辦)
	 * 
	 * 回到預設經辦後可再調整人員後再送出
	 */
	public AjaxFormResult updateRptToReject(String rptId,int rptVersion,String rptDate,int rptSeqno,String rptBranch,
			String apprvComment,String convertTimeStart,Date sysDate,String loginUserId,String loginUserName,String realApprvUserId,String realApprvUserUnit) {
		log.debug("updateRptToReject--------------------");
		AjaxFormResult afr = new AjaxFormResult();
		int rowsUpd = 0;
		try {
		if (sysDate == null)
		sysDate = Calendar.getInstance().getTime();
		
		log.debug("updateRptToReject--------------------loginUserId="+loginUserId +"loginUserName:"+loginUserName+",rptId="+rptId +",rptVersion="+rptVersion 
				+",realApprvUserId="+realApprvUserId);
		
		//0.先找出該報表所有簽核人員
		List<RptContentApprvUser>  rptContentUserList = rptContentApprvUserService.getBySqlCondition(rptId, rptSeqno, rptDate, rptVersion, rptBranch);
		
		RptContentApprvUser setUserIdCrossDept =  findSetUserIdCrossDept(rptContentUserList);
		
		//log.debug("setUserIdCrossDept==" + setUserIdCrossDept.toString());
		
		for (RptContentApprvUser rptContentApprvUser : rptContentUserList){
				log.debug("updateRptToReject rptContentApprvUser id="+ rptContentApprvUser.getId().toString());
				
				if (rptContentApprvUser != null && rptContentApprvUser.getApprvUser().equals(realApprvUserId)){
					
					//檢查第1關是否已單位異動   若有email給單位總務
					AjaxFormResult afrCheck = doCheckSetApprvUser(rptContentApprvUser, loginUserId, sysDate);
					
					if (afrCheck!=null && afrCheck.get("error") != null){
						afr.set("result", "error");
						log.debug("updateRptToReject error ="+ (String)afrCheck.get("error"));
						afr.set("resultMsg", (String)afrCheck.get("error"));
						return afr;
					}
					
					//寫入一筆簽核歷程
					//報表簽核動作 apprvAction 1.確認送出、2.會簽、3.覆核、4.核准、5.退回   6.作廢重簽  7.作廢重簽(放行) 8.作廢重簽(退回)
					saveRptContentApprvHistory(rptContentApprvUser,rptSeqno,rptVersion, apprvComment,loginUserId,loginUserName, sysDate,"5","3");
					//更新明細資料的狀態為 已退回
					//(Long id,String apprvStatus,Date updateTime,String updater,String isApprove);
					//rowsUpd = rptContentApprvUserService.updateById(rptContentApprvUser.getId(), RptContentApprvUser.STATUS_TOAPPROVE_REJECTED,sysDate,loginUserId,"Y");
					//20170705 修改 退回的人員可能是因設定有誤才退回,因此退回經辦後須開放供其修改或刪除
					rowsUpd = rptContentApprvUserService.updateById(rptContentApprvUser.getId(), RptContentApprvUser.STATUS_TOAPPROVE,sysDate,loginUserId,"N");
					log.debug("updateRptToReject--------------------rowsUpd==="+rowsUpd);
					
					RptContentApprv master = rptContentApprvService.getOneBySqlCondition(rptId, rptSeqno, rptDate, rptVersion, rptBranch, convertTimeStart);		
					log.debug("updateRptToReject master="+master.toString());
					//Map<String,String> nextStepAndStatus = getNextApprvStep(rptContentUserList,rptContentApprvUser.getApprvStep(),loginUserId);
					
					if (master.getCrossDept() != null){//表示為跨單位簽核
						//表示是第一段流程,退回第一段的經辦
						if (realApprvUserUnit.equals(rptBranch)){
							master.setApprvStep("1");//非跨單位簽核,一律退回到第1關
							master.setApprvStatus("3");//apprvStatus= 3: 簽核中(已退回)
							master.setApprvUser(master.getSetUserId());//待簽核人員為第二段流程的預設經辦
						} else {//表示是第二段流程,退回第二段的經辦
							log.debug("setUserIdCrossDept.getApprvStep()==="+setUserIdCrossDept.getApprvStep());
							master.setApprvStep(setUserIdCrossDept.getApprvStep());//非跨單位簽核,一律退回到第1關
							master.setApprvStatus("3");//apprvStatus= 3: 簽核中(已退回)
							master.setApprvUser(setUserIdCrossDept.getApprvUser());//待簽核人員為第二段流程的預設經辦
						}
					} else {
						master.setApprvStep("1");//非跨單位簽核,一律退回到第1關
						master.setApprvStatus("3");//apprvStatus= 3: 簽核中(已退回)
						master.setApprvUser(master.getSetUserId());//待簽核人員為預設經辦
					}
					master.setUpdater(loginUserId);
					master.setUpdateTime(sysDate);
					rptContentApprvService.update(master);
					
					//依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
					//更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId 
					String masterApprvStatus = "3";
					rptContentApprvUserService.updateMasterColumnsByKey(master.getRptId(), master.getRptVersion(), master.getRptDate(), master.getRptSeqno().intValue(), master.getRptBranch(), (Long) master.get("id"), masterApprvStatus, master.getCrossDept(), master.getCrossDeptSetUserId(), master.getApprvStep());
					
					
					afr.set("result", "success");
						
					}
		}
		
		} catch(Exception e){
			log.error(ExceptionUtils.getFullStackTrace(e));
		}
		
		return afr;
	}
	
	//List<RptContentApprvUser>  rptContentUserList = rptContentApprvUserService.getBySqlCondition(rptId, rptSeqno, rptDate, rptVersion, rptBranch);
	//找出第二段流程的預設經辦
	private RptContentApprvUser findSetUserIdCrossDept(List<RptContentApprvUser>  rptContentUserList){
		String lastApprvUserDept = "";
		for(RptContentApprvUser o:rptContentUserList){			
			if (!lastApprvUserDept.equals("") && !o.getApprvUserDept().equals(lastApprvUserDept)){
				return o;
			}
			lastApprvUserDept = o.getApprvUserDept();
		}
		
		return null;
		
	}
	
	/**
	 *  
	 * <pre>
	 *   於待簽核報表按下[確認送出] - 單筆簽核
	 *   1.更新Table:RPT_CONTENT_APPRV_USER ,APPRVSTATUS= 2(apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回 ), ISAPPRV=Y,updateTime= 系統時間
	 *   2.更新Table:RPT_CONTENT_APPRV - apprvStep,apprvStatus
	 *   3.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
	 * </pre>
	 * @param request
	 * @return
	 * @ref Txn103011Handler updateRptToApprove
	 */
	@Override
	public AjaxFormResult updateRptToApprove(String rptId,int rptVersion,String rptDate,int rptSeqno,String rptBranch,
			String apprvComment,String convertTimeStart,Date sysDate,String loginUserId,String loginUserName,String realApprvUserId) {
		log.debug("updateRptToApprove--------------------");
		AjaxFormResult afr = new AjaxFormResult();
		
		/*String rptId = (String) request.get("rptId");
		int rptVersion = Integer.parseInt(request.get("rptVersion"));
		String rptDate = (String) request.get("rptDate");
		int rptSeqno = Integer.parseInt(request.get("rptSeqno"));
		String rptBranch = (String) request.get("rptBranch");
		//簽核作業加入  判斷必簽若為Y 則筆數加1 
		String rptApprove = (String)request.get("rptApprove");
		String apprvComment = (String)request.get("apprvComment");
		
		//收檔時間 see Txn104051Handler:query 格式: yyyy-MM-dd HH:mm:ss.SSS 
		String convertTimeStartFull = (String)request.get("convertTimeStartFull");*/
		int rowsUpd = 0;
		try {
		//RcmsUserDetails rcmsUserDetails = CapSecurityContext.getUser();
		//String loginUserId = CapSecurityContext.getUserId();//
		
		if (sysDate == null)
		sysDate = Calendar.getInstance().getTime();
		
		log.debug("updateRptToApprove--------------------loginUserId="+loginUserId +",rptId="+rptId +",rptVersion="+rptVersion+",realApprvUserId="+realApprvUserId);
		
		/*set apprvStatus=:apprvStatus,
				apprvTime=:apprvTime,
				apprvComment=:apprvComment,
				isApprove=:isApprove
				updateTime = :updateTime,*/
		
		//0.先找出該報表所有簽核人員,依簽核層級排序
		List<RptContentApprvUser>  rptContentUserList = rptContentApprvUserService.getBySqlCondition(rptId, rptSeqno, rptDate, rptVersion, rptBranch);
		
		int idx = 0;
		for (RptContentApprvUser rptContentApprvUser : rptContentUserList){
				log.debug("updateRptToApprove rptContentApprvUser id="+ rptContentApprvUser.getId().toString());
				
				if (rptContentApprvUser!=null && rptContentApprvUser.getApprvUser().equals(realApprvUserId)){
					
					//檢查下一簽核層級的人是否有單位異動  若有email給經辦和單位總務
					AjaxFormResult afrCheck = doCheckNextApprvUser(rptContentApprvUser, realApprvUserId, sysDate,rptContentUserList);
					
					if (afrCheck!=null && afrCheck.get("error") != null){
						log.debug("afrCheck error="+(String)afrCheck.get("error"));
						afr.set("result", "error");
						afr.set("resultMsg", (String)afrCheck.get("error"));
						return afr;
					}
					
					//寫入一筆簽核歷程
					//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
					saveRptContentApprvHistory(rptContentApprvUser,rptSeqno,rptVersion, apprvComment,loginUserId, loginUserName,sysDate,"1",RptContentApprvUser.STATUS_APPROVED);
					//更新明細資料的狀態為 已簽核
					//(Long id,String apprvStatus,Date updateTime,String updater,String isApprove);
					rowsUpd = rptContentApprvUserService.updateById(rptContentApprvUser.getId(), RptContentApprvUser.STATUS_APPROVED,sysDate,loginUserId,"Y");
					log.debug("updateRptToApprove--------------------rowsUpd==="+rowsUpd);
					
					//若同一層級尚有其它人須簽核(會簽), RptContentApprv的apprvStep和apprvStatus不用更新
					int countToApprv = rptContentApprvUserService.countToApprvUsers(rptId, rptSeqno, rptDate, rptVersion, rptBranch, rptContentApprvUser.getApprvStep());
					log.debug("countToApprv=" + countToApprv);
					idx ++;
					log.debug("idx="+idx);
					if (countToApprv == 0){
						//TODO RptContentApprv 簽過就刪除 RptContentApprv
						//更新簽核主檔
						//String nextApprvUser = ((RptContentApprvUser)rptContentUserList.get(idx)).getApprvUser();
						//log.debug("nextApprvUser="+nextApprvUser);
						String nextApprvUserId = "";
						List<RptContentApprvUser> nextApprvUsers = getNextApprvUser(rptContentApprvUser,rptContentUserList);
						if (nextApprvUsers != null && !nextApprvUsers.isEmpty()){
							nextApprvUserId = nextApprvUsers.get(0).getApprvUser();
							log.debug("nextApprvUserId="+nextApprvUserId);
						}
						
						updateRptContentApprv(rptId, rptSeqno, rptDate, rptVersion, rptBranch, rptContentApprvUser.getApprvStep(), nextApprvUserId, 
								convertTimeStart, loginUserId, sysDate);
						
						
					}
					
				}
		}
		
		
		//查詢該筆RPT_CONTENT_APPRV_USER資料
		/*RptContentApprvUser rptContentApprvUser = rptContentApprvUserService.getOneBySqlCondition(rptId, rptSeqno,
				rptDate, rptVersion, rptBranch, null, loginUserId);
			
			log.debug("updateRptToApprove rowsUpd="+rowsUpd);*/
			
		
		} catch(Exception e){
			log.error(e.getMessage());
		}
		
		if (rowsUpd > 0){
			afr.set("result", "success");
		}
		
		return afr;
	}
	
	/**
	 * 取得下一簽核層級ApprvStep及更新ApprvStatus,以回寫主檔 RptContentApprv
	 * 
	 * apprvStatus:0:未設定 , 1:已簽核(RptContentApprv 主檔應沒有此選項)   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
	 * 
	 * @param rptContentUserList
	 * @param thisApprvStep
	 * @return
	 */
	@Override
	public Map<String,String> updateRptContentApprv(String rptId, int rptSeqno, String rptDate, int rptVersion,String rptBranch,
			String thisApprvStep,String nextApprvUser,String convertTimeStartFull,String loginUserId,Date sysDate){
		
		log.debug("countToApprv=0,rptId="+rptId+",rptSeqno="+rptSeqno+",rptDate="+rptDate+",rptVersion="+rptVersion+",rptBranch="+rptBranch+",convertTimeStartFull="+convertTimeStartFull+",nextApprvUser="+nextApprvUser);
		RptContentApprv master = rptContentApprvService.getOneBySqlCondition(rptId, rptSeqno, rptDate, rptVersion, rptBranch, convertTimeStartFull);		
		log.debug("updateRptToApprove master="+master.toString());
		
		Map<String,String> result = new HashMap<String,String>();
		String nextApprvStep = "";
		String nextApprvStatus = "";
		
		//TODO 要考慮若最後一關有多人會簽時?
		if (thisApprvStep.equals("End")) {//表示目前已是最後一關,則狀態更改為 已結案
			
			nextApprvStep = getNextApprvStep(master,convertTimeStartFull);
			log.debug("nextApprvStep 00 ="+nextApprvStep);
			
			if (nextApprvStep == null || nextApprvStep.equals("")){
				nextApprvStep ="";
				log.debug("nextApprvStep 01 ="+nextApprvStep);
				nextApprvStatus = RptContentApprvUser.STATUS_CLOSED; //6.已結案
			} else {
				log.debug("nextApprvStep 02 ="+nextApprvStep);
				nextApprvStatus = RptContentApprvUser.STATUS_TOAPPROVE; //待最後一關會簽 2:簽核中
			}
		}
		
		if (!thisApprvStep.equals("End")){
			nextApprvStep = getNextApprvStep(master,convertTimeStartFull);
			nextApprvStatus = RptContentApprvUser.STATUS_TOAPPROVE;//則狀態更改為 2:簽核中
			log.debug("nextApprvStep 11 ="+nextApprvStep);
		}
		
		result.put("nextApprvStep", nextApprvStep);
		result.put("nextApprvStatus", nextApprvStatus);
		
		log.debug("nextApprvStep="+nextApprvStep);
		log.debug("nextApprvStatus="+nextApprvStatus);
		
	/*	if (nextApprvStep.equals("E1")){
			nextApprvStatus = "9";//將主檔的status改為9 待第二單位的經辦進入[報表簽核流程設定]進行第二段流程的設定
		}*/
		
		log.debug("master.getCrossDeptSetUserId()="+master.getCrossDeptSetUserId()+",nextApprvUser="+nextApprvUser);
		if (master.getCrossDeptSetUserId()!=null && master.getCrossDeptSetUserId().equals(nextApprvUser)){
			nextApprvStatus = "9";//將主檔的status改為9 待第二單位的經辦進入[報表簽核流程設定]進行第二段流程的設定
		}
		
		master.setApprvStep(nextApprvStep);
		master.setApprvStatus(nextApprvStatus);
		master.setUpdater(loginUserId);
		master.setUpdateTime(sysDate);
		rptContentApprvService.update(master);
		
		//依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
		//更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId 
		rptContentApprvUserService.updateMasterColumnsByKey(rptId, rptVersion, rptDate, rptSeqno, rptBranch, (Long) master.get("id"), nextApprvStatus, master.getCrossDept(), master.getCrossDeptSetUserId(), master.getApprvStep());
		
		return result;
		
	}
	
	/**
	 * for 報表退回後重新設定送出/報素改派
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param id
	 * @param strArrSelStartUserIds
	 * @param strArrSelEndUserIds
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 */
	@Override
	public AjaxFormResult updateRptSetting(String rptId,String rptVersion,String rptDate,String rptSeqno,String rptBranch,
			String[] strArrSelStartUserIds,String[] strArrSelEndUserIds,String strConvertTimeStartFull,String[] selDataArr,
			String strApprvComment,JSONObject apprvUserDataObj){

		AjaxFormResult afr = new AjaxFormResult();
		
		try {
		RcmsUserDetails rcmsUserDetails = CapSecurityContext.getUser();
		String loginUserId = CapSecurityContext.getUserId();
		String loginUserName = CapSecurityContext.getUserName();
		String loginUserDepCode = rcmsUserDetails.getUnitNo();
		
		log.debug("updateRptSetting--------------------loginUserId:"+loginUserId+",loginUserName:"+loginUserName);
		
		
		RptContentApprv rptContentApprv = null;
		Date sysDate = Calendar.getInstance().getTime();
		List<InfoGrpRpt> infoGrpRptList =  infoGrpRptService.getInfoGrpRptByRptId(rptId);
		
		String resultMsg = "";
		for (String strStarUser:strArrSelStartUserIds){
			boolean b1 = checkInfoGrpRpt(strStarUser,infoGrpRptList);
			if (!b1) {
				//afr.set("result", "error");
				resultMsg = "["+strStarUser+"] 尚未設定此報表的群組權限<br>";
				//afr.set("resultMsg", "["+strStarUser+"] 尚未設定此報表的群組權限<br>");
				afr.set("result", "error");
				afr.set("resultMsg", resultMsg);
				return afr;
			}
		}
		
		for (String strEndUser:strArrSelEndUserIds){
			boolean b1 = checkInfoGrpRpt(strEndUser,infoGrpRptList);
			if (!b1) {
				resultMsg = resultMsg + "["+strEndUser+"] 尚未設定此報表的群組權限<br>"; 
				afr.set("result", "error");
				afr.set("resultMsg", resultMsg);
				return afr;
				
			}
		}
		
		for (String empData:selDataArr){
			log.debug("第2關人員00:"+empData);
			
			String[] empDataArr = empData.split("\\|");
			log.debug("---000----第"+empDataArr[0]+"關,人員:"+empDataArr[1]);
			//String[] strSelUserIds = empIds.split(",");
			
			String[] strSelUserIds = empDataArr[1].split("\\s*,\\s*");
			
			//String[] strSelUserIds = empIds.split(",");
			for (String selUserId:strSelUserIds){
				boolean b1 = checkInfoGrpRpt(selUserId,infoGrpRptList);
				if (!b1) {
					resultMsg = resultMsg + "["+selUserId+"] 尚未設定此報表的群組權限<br>"; 
					afr.set("result", "error");
					afr.set("resultMsg", resultMsg);
					return afr;
				}
			}
		}
		
		log.debug("afr result="+ (String)afr.get("result"));
		/*if (resultMsg.length()>0){
			afr.set("result", "error");
			afr.set("resultMsg", resultMsg);
			return afr;
		}*/
			
		log.debug("updateRptSetting strConvertTimeStartFull=" + strConvertTimeStartFull);
		
		/*log.debug("apprvUserDataObj 1="+apprvUserDataObj.getString("1"));//format: HB00VV|Y,HB0493|Y
		log.debug("apprvUserDataObj 2="+apprvUserDataObj.getString("2"));//format: HB0761|Y,HB0665|N
		log.debug("apprvUserDataObj End="+apprvUserDataObj.getString("End"));*/
		
		for (String emp:selDataArr){
			log.debug("updateRptSetting save emp="+emp);
		}
		
		log.debug("updateRptSetting strSelStartUserId="+strArrSelStartUserIds);
		log.debug("updateRptSetting strArrSelEndUserIds="+strArrSelEndUserIds);
		
		//改派完須下一個須簽核的層級
		String nextApprvStep = "";
		
		//1.更新[報表簽核設定]資料(Table:RPT_CONTENT_APPRV)
		//if (StringUtils.isNotEmpty(id)){
			//rptContentApprv = rptContentApprvService.getByPk(Long.valueOf(id));
			
			rptContentApprv = rptContentApprvService.getOneBySqlCondition(rptId, Integer.parseInt(rptSeqno), rptDate, Integer.parseInt(rptVersion), rptBranch, strConvertTimeStartFull);
			
			//第1次初始設定時
			if (rptContentApprv.getSetUserId() == null){
				rptContentApprv.setSetDivisionId(rptBranch);
				rptContentApprv.setSetUserId(loginUserId);
				rptContentApprv.setCreator(loginUserId);
				rptContentApprv.setCreateTime(sysDate);
				rptContentApprv.setIndexGrpId("1");
			}
			
			//找出原本已設定的簽核人員
			List<RptContentApprvUser> apprvUsers1stStage = rptContentApprvUserService.getBySqlCondition(rptContentApprv.getRptId(),rptContentApprv.getRptSeqno().intValue(),  
					rptContentApprv.getRptDate(),rptContentApprv.getRptVersion(),rptContentApprv.getRptBranch());
			
			List<String> apprvUserList = new ArrayList<String>();
			for(RptContentApprvUser oldUser:apprvUsers1stStage){
				log.debug("oldUser="+oldUser.toString());
				if (oldUser.getIsApprv()!=null && oldUser.getIsApprv().equals("Y"))//已簽過的不能動資料
				apprvUserList.add(oldUser.getApprvUser());
			}
			
			log.debug("updateRptSetting rptContentApprv="+rptContentApprv.toString());
			
			//apprvSte, HB00VV|Y,HB0493|Y
			//0.先刪除原本isApprv=N的RptContentApprvUser資料
			if (apprvUserDataObj != null)
			deleteOrigialUnApprvedUsers(apprvUserDataObj,rptContentApprv,strConvertTimeStartFull,"Y");
			 
			if (strApprvComment != null) strApprvComment = strApprvComment.trim();
			log.debug("updateRptSetting save strApprvComment="+strApprvComment);
		
			//2.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
			//2.1 處理第1關
			//String[] strSelStartUserIds = strSelStartUserId.split(",");
			//1.會簽, 2.覆核, 3.主管  */
			String strApprvTypeStart = strArrSelStartUserIds.length > 1 ? "1" : "2";
			log.debug("strSelStartUserIds.length="+strArrSelStartUserIds.length);
			log.debug("strApprvTypeStart="+strApprvTypeStart);
			String strApprvStepStart = "1";//第1關
			
			for(String str:strArrSelStartUserIds){
				log.debug("updateRptSetting 第1關簽核人員:"+str);
			}
			
			// apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
			if (strArrSelStartUserIds.length == 1){//若第1關只有預設經辦,則非會簽
				log.debug("updateRptSetting 第1關人員:"+strArrSelStartUserIds[0]);
				
				RptContentApprvUser rptContentApprvUser = null; 
				//若登入人員不為總務,則isApprv=N, 若為預設經辦,isApprv=Y
				if (strArrSelStartUserIds[0].equals(loginUserId)){
					if (apprvUserList.indexOf(strArrSelStartUserIds[0])<0){
						rptContentApprvUser = saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,strArrSelStartUserIds[0],loginUserDepCode,strApprvStepStart,strApprvTypeStart,"Y","1",loginUserDepCode);
						//寫入一筆簽核記錄
						saveRptContentApprvHistory(rptContentApprvUser,rptContentApprv.getRptSeqno().intValue(),rptContentApprv.getRptVersion(),strApprvComment,
								loginUserId,loginUserName,sysDate,"1","1");
					}
				} else { ////若登入人員為總務,則isApprv=N, 若為預設經辦,isApprv=Y
					if (apprvUserList.indexOf(strArrSelStartUserIds[0])<0){
					rptContentApprvUser = saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,strArrSelStartUserIds[0],loginUserDepCode,strApprvStepStart,strApprvTypeStart,"N","2",loginUserDepCode);
					//寫入一筆簽核記錄
					saveRptContentApprvHistory(rptContentApprvUser,rptContentApprv.getRptSeqno().intValue(),rptContentApprv.getRptVersion(),strApprvComment,
							loginUserId,loginUserName,sysDate,"1","1");
					}
				}
				
			} else {//若第1關有多人以上,則為會簽
				for (String selStartUserId:strArrSelStartUserIds){
					//apprvType 1.會簽, 2.覆核, 3.主管  */
					if (selStartUserId.equals(loginUserId)){
						//設定人員為經辦自己,apprvStatus更改為1 已簽核
						if (apprvUserList.indexOf(strArrSelStartUserIds[0])<0){
							RptContentApprvUser rptContentApprvUser = null; 
							rptContentApprvUser = saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,selStartUserId,loginUserDepCode,strApprvStepStart,strApprvTypeStart,"Y","1",loginUserDepCode);
							//寫入一筆簽核記錄,,
							saveRptContentApprvHistory(rptContentApprvUser,rptContentApprv.getRptSeqno().intValue(),rptContentApprv.getRptVersion(),strApprvComment,
									loginUserId,loginUserName,sysDate,"1","1");
						}
					} else {
						//設定人員為單位總務 apprvStatus更改為2  簽核中
						saveRptContentApprvUser(rptContentApprv,selStartUserId,sysDate,selStartUserId,loginUserDepCode,strApprvStepStart,strApprvTypeStart,"N","2",loginUserDepCode);
					}
				}
			}
			
			//處理第2關~倒數第2關(決行前一關)
			int apprvStep = 2;			
			for (String empData:selDataArr){
				log.debug("第2關人員00:"+empData);
				
				String[] empDataArr = empData.split("\\|");
				log.debug("---000----第"+empDataArr[0]+"關,人員:"+empDataArr[1]);
				
				String[] strSelUserIds = empDataArr[1].split("\\s*,\\s*");
				
				//1.會簽, 2.覆核, 3.主管  */
				String strApprvType = strSelUserIds.length > 1 ? "1" : "2";
				String strApprvStep = apprvStep+"";//第幾關
				for (String selUserId:strSelUserIds){
					log.debug("第2關人員11:"+selUserId);
					//apprvType 1.會簽, 2.覆核, 3.主管  */
					//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回	
					if (apprvUserList.indexOf(selUserId)<0){
						saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,selUserId,loginUserDepCode,strApprvStep,strApprvType,"N","2",loginUserDepCode);
					}
				}
				apprvStep ++;
			}
			
			//2.1 處理決行/最後1關
			//String[] strSelEndUserIds = strSelEndUserId.split(",");
			//1.會簽, 2.覆核, 3.主管  */
			String strApprvTypeEnd = strArrSelEndUserIds.length > 1 ? "1" : "3";
			String strApprvStepEnd = "End";//最後一關
			for (String selEndUserId:strArrSelEndUserIds){
				//apprvType 1.會簽, 2.覆核, 3.主管  */
				log.debug("第End關人員11:"+selEndUserId);
				saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,selEndUserId,loginUserDepCode,strApprvStepEnd,strApprvTypeEnd,"N","2",loginUserDepCode);
			}
			
			nextApprvStep = getNextApprvStep(rptContentApprv,strConvertTimeStartFull);
			log.debug("updateRptSetting nextApprvStep:"+nextApprvStep);
			
			//若原本狀態是"3.退回", 由於第一關已不再寫入歷史紀錄　 故新增一筆新的歷史紀錄 apprvStatus=1.已簽
			if("3".equals(rptContentApprv.getApprvStatus())) {
				
			}
			
			//更新簽核主檔 
			//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
			updateRptContentApprv(loginUserId,loginUserId,loginUserId,rcmsUserDetails.getUnitNo(),rptContentApprv,nextApprvStep, sysDate,"2");
			
			//依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
			//更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId 
			rptContentApprvUserService.updateMasterColumnsByKey(rptId, Integer.parseInt(rptVersion), rptDate, Integer.parseInt(rptSeqno), rptBranch, (Long) rptContentApprv.get("id"), "2", rptContentApprv.getCrossDept(), rptContentApprv.getCrossDeptSetUserId(), rptContentApprv.getApprvStep());
			
			afr.set("result", "success");
		} catch(Exception e){
			log.debug(ExceptionUtils.getFullStackTrace(e));
			afr.set("result", "error");
			
		}
		
		return afr;
				
	}
	
	/**
	 * 移管後的新單位設定(不設跨單位) 模擬status=0
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param strArrSelStartUserIds
	 * @param strArrSelEndUserIds
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 * @return
	 */
	@Override
	public AjaxFormResult updateRptSettingByBranchTransfer(String rptId, String rptVersion, String rptDate,
			String rptSeqno, String rptBranch, String[] strArrSelStartUserIds, String[] strArrSelEndUserIds,
			String strConvertTimeStartFull, String[] selDataArr, String strApprvComment, JSONObject apprvUserDataObj) {
		//若是移管 先移除被移管單位原本設定的待簽人員 後續再根據apprvStatus=0,1,2...(排除6結案&9跨過單位等)
		rptContentApprvUserService.deleteUsers(rptId, Integer.parseInt(rptSeqno), rptDate, Integer.parseInt(rptVersion), rptBranch, strConvertTimeStartFull);
		
		return this.updateRptSetting(rptId, rptVersion, rptDate, rptSeqno, rptBranch, strArrSelStartUserIds, strArrSelEndUserIds, strConvertTimeStartFull, selDataArr, strApprvComment, apprvUserDataObj);
	}
	
	
	/**
	 * 跨單位簽核
	 * for 第一關的經辦設定寫入RPT_CONTENT_APPRV_USER
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param id
	 * @param strArrSelStartUserIds
	 * @param strArrSelEndUserIds
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 */
	@Override
	public AjaxFormResult insertForCrossUnit(String rptId,String rptVersion,String rptDate,String rptSeqno,String rptBranch,
			String[] strArrSelStartUserIds,String strEndUserId,String strEndUserDepCode,String strConvertTimeStartFull,String[] selDataArr,
			String strApprvComment,JSONObject apprvUserDataObj){

		AjaxFormResult afr = new AjaxFormResult();
		
		try {
		RcmsUserDetails rcmsUserDetails = CapSecurityContext.getUser();
		String loginUserId = CapSecurityContext.getUserId();
		String loginUserName = CapSecurityContext.getUserName();
		String loginUserDepCode = rcmsUserDetails.getUnitNo();
		
		log.debug("updateRptSettingForCrossUnit--------------------loginUserId:"+loginUserId+",loginUserName:"+loginUserName);
		
		RptContentApprv rptContentApprv = null;
		Date sysDate = Calendar.getInstance().getTime();
		List<InfoGrpRpt> infoGrpRptList =  infoGrpRptService.getInfoGrpRptByRptId(rptId);
		
		String resultMsg = "";
		for (String strStarUser:strArrSelStartUserIds){
			boolean b1 = checkInfoGrpRpt(strStarUser,infoGrpRptList);
			if (!b1) {
				//afr.set("result", "error");
				resultMsg = "["+strStarUser+"] 尚未設定此報表的群組權限<br>";
				//afr.set("resultMsg", "["+strStarUser+"] 尚未設定此報表的群組權限<br>");
				afr.set("result", "error");
				afr.set("resultMsg", resultMsg);
				return afr;
			}
		}
		
		//for (String strEndUser:strArrSelEndUserIds){
			boolean b1 = checkInfoGrpRpt(strEndUserId,infoGrpRptList);
			if (!b1) {
				resultMsg = resultMsg + "["+strEndUserId+"] 尚未設定此報表的群組權限<br>"; 
				afr.set("result", "error");
				afr.set("resultMsg", resultMsg);
				return afr;
				
			}
		//}
		
		for (String empData:selDataArr){
			String[] empDataArr = empData.split("\\|");
			log.debug("---000----第"+empDataArr[0]+"關,人員:"+empDataArr[1]);
			String[] strSelUserIds = empDataArr[1].split("\\s*,\\s*");
			for (String selUserId:strSelUserIds){
				boolean b2 = checkInfoGrpRpt(selUserId,infoGrpRptList);
				if (!b2) {
					resultMsg = resultMsg + "["+selUserId+"] 尚未設定此報表的群組權限<br>"; 
					afr.set("result", "error");
					afr.set("resultMsg", resultMsg);
					return afr;
				}
			}
		}
		
		log.debug("afr result="+ (String)afr.get("result"));
		
		
		log.debug("updateRptSettingForCrossUnit strConvertTimeStartFull=" + strConvertTimeStartFull);
		
		//第2關~決行前一關的簽核人員
		//String[] selDataArr =  request.getParamsAsStringArray("selDataArr");
		
		//簽核意見
		//String strApprvComment = request.get("apprvComment");//可以是null
		
		//原本的RPT_CONTENT_APPRV_USER 設定值
		//JSONObject apprvUserDataObj = JSONObject.fromObject(request.get("apprvUserData"));
		
		/*log.debug("apprvUserDataObj 1="+apprvUserDataObj.getString("1"));//format: HB00VV|Y,HB0493|Y
		log.debug("apprvUserDataObj 2="+apprvUserDataObj.getString("2"));//format: HB0761|Y,HB0665|N
		log.debug("apprvUserDataObj End="+apprvUserDataObj.getString("End"));*/
		
		for (String emp:selDataArr){
			log.debug("updateRptSetting save emp="+emp);
		}
		
		log.debug("updateRptSettingForCrossUnit strSelStartUserId="+strArrSelStartUserIds);
		log.debug("updateRptSettingForCrossUnit strEndUserId="+strEndUserId);
		
		
		String strSetDivisionId = loginUserDepCode;
		//改派完須下一個須簽核的層級
		String nextApprvStep = "";
		
		//1.更新[報表簽核設定]資料(Table:RPT_CONTENT_APPRV)
		//if (StringUtils.isNotEmpty(id)){
			//rptContentApprv = rptContentApprvService.getByPk(Long.valueOf(id));
			
			rptContentApprv = rptContentApprvService.getOneBySqlCondition(rptId, Integer.parseInt(rptSeqno), rptDate, Integer.parseInt(rptVersion), rptBranch, strConvertTimeStartFull);
			
			//第1次初始設定時
			if (rptContentApprv.getApprvStatus() == null || rptContentApprv.getApprvStatus().equals("0")){
				rptContentApprv.setSetDivisionId(rptBranch);
				rptContentApprv.setSetUserId(loginUserId);
				rptContentApprv.setCreator(loginUserId);
				rptContentApprv.setCreateTime(sysDate);
				rptContentApprv.setIndexGrpId("1");
				rptContentApprv.setCrossDept(strEndUserDepCode);//第二段流程的單位代號
				rptContentApprv.setCrossDeptSetUserId(strEndUserId);//第二段流程的經辦
				
			}
			
			log.debug("updateRptSetting rptContentApprv="+rptContentApprv.toString());
			
			//apprvSte, HB00VV|Y,HB0493|Y
			//0.先刪除原本isApprv=N的RptContentApprvUser資料
			if (apprvUserDataObj != null)
			deleteOrigialUnApprvedUsers(apprvUserDataObj,rptContentApprv,strConvertTimeStartFull,null);
			 
			if (strApprvComment != null) strApprvComment = strApprvComment.trim();
			log.debug("updateRptSetting save strApprvComment="+strApprvComment);
		
			//2.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
			//2.1 處理第1關
			//String[] strSelStartUserIds = strSelStartUserId.split(",");
			//1.會簽, 2.覆核, 3.主管  */
			String strApprvTypeStart = strArrSelStartUserIds.length > 1 ? "1" : "2";
			log.debug("strSelStartUserIds.length="+strArrSelStartUserIds.length);
			log.debug("strApprvTypeStart="+strApprvTypeStart);
			String strApprvStepStart = "1";//第1關
			
			for(String str:strArrSelStartUserIds){
				log.debug("updateRptSetting 第1關簽核人員:"+str);
			}
			
			// apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
			if (strArrSelStartUserIds.length == 1){//若第1關只有預設經辦,則非會簽
				log.debug("updateRptSetting 第1關人員:"+strArrSelStartUserIds[0]);
				
				RptContentApprvUser rptContentApprvUser = null; 
				//若登入人員不為總務,則isApprv=N, 若為預設經辦,isApprv=Y
				if (strArrSelStartUserIds[0].equals(loginUserId)){
					rptContentApprvUser = saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,strArrSelStartUserIds[0],loginUserDepCode,strApprvStepStart,strApprvTypeStart,"Y","1",strSetDivisionId);
				} else { ////若登入人員為總務,則isApprv=N, 若為預設經辦,isApprv=Y
					rptContentApprvUser = saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,strArrSelStartUserIds[0],loginUserDepCode,strApprvStepStart,strApprvTypeStart,"N","2",strSetDivisionId);
				}
				//寫入一筆簽核記錄
				//saveRptContentApprvHis(RptContentApprvUser rptContentApprvUser,int rptSeqno,int rptVersion,String apprvComment,
				//String loginUserId,Date sysDate,String apprvAction,String apprvStatus);
				
				saveRptContentApprvHistory(rptContentApprvUser,rptContentApprv.getRptSeqno().intValue(),rptContentApprv.getRptVersion(),strApprvComment,
						loginUserId,loginUserName,sysDate,"1","1");
				
			} else {//若第1關有多人以上,則為會簽
				for (String selStartUserId:strArrSelStartUserIds){
					//apprvType 1.會簽, 2.覆核, 3.主管  */
					if (selStartUserId.equals(loginUserId)){
						//設定人員為經辦自己,apprvStatus更改為1 已簽核
						RptContentApprvUser rptContentApprvUser = null; 
						rptContentApprvUser = saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,selStartUserId,loginUserDepCode,strApprvStepStart,strApprvTypeStart,"Y","1",strSetDivisionId);
						//寫入一筆簽核記錄,,
						saveRptContentApprvHistory(rptContentApprvUser,rptContentApprv.getRptSeqno().intValue(),rptContentApprv.getRptVersion(),strApprvComment,
								loginUserId,loginUserName,sysDate,"1","1");
					} else {
						//設定人員為單位總務 apprvStatus更改為2  簽核中
						saveRptContentApprvUser(rptContentApprv,selStartUserId,sysDate,selStartUserId,loginUserDepCode,strApprvStepStart,strApprvTypeStart,"N","2",strSetDivisionId);
					}
				}
			}
			
			//處理第2關~倒數第2關(決行前一關)
			int apprvStep = 2;			
			for (String empData:selDataArr){
				String[] empDataArr = empData.split("\\|");
				log.debug("---000----第"+empDataArr[0]+"關,人員:"+empDataArr[1]);
				String[] strSelUserIds = empDataArr[1].split("\\s*,\\s*");
				//1.會簽, 2.覆核, 3.主管  */
				String strApprvType = strSelUserIds.length > 1 ? "1" : "2";
				String strApprvStep = apprvStep+"";//第幾關
				for (String selUserId:strSelUserIds){
					log.debug("第2關人員11:"+selUserId);
					//apprvType 1.會簽, 2.覆核, 3.主管  */
					//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回					
					saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,selUserId,loginUserDepCode,strApprvStep,strApprvType,"N","2",strSetDivisionId);
				}
				apprvStep ++;
			}
			
			//2.1 處理決行/最後1關
			//String[] strSelEndUserIds = strSelEndUserId.split(",");
			//1.會簽, 2.覆核, 3.主管   4.待設定 */
			String strApprvTypeEnd = "4";
			//String strApprvStepEnd = "E1";//第1段簽核流程的最後一關
			String strApprvStepEnd = apprvStep+"";//第1段簽核流程的最後一關
			
				//apprvType 1.會簽, 2.覆核, 3.主管  */
			log.debug("第End關人員11:"+strEndUserId);
			
			saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,strEndUserId,strEndUserDepCode,strApprvStepEnd,strApprvTypeEnd,"N","9",strSetDivisionId);
			
			nextApprvStep = getNextApprvStep(rptContentApprv,strConvertTimeStartFull);
			log.debug("updateRptSetting nextApprvStep:"+nextApprvStep);
			//更新簽核主檔 TODO
			//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
			String masterApprvStatus = "2";
			if (selDataArr == null || selDataArr.length == 0){
				updateRptContentApprv(loginUserId,loginUserId,loginUserId,rcmsUserDetails.getUnitNo(),rptContentApprv,nextApprvStep, sysDate,"9");
				masterApprvStatus = "9";
			} else {
				updateRptContentApprv(loginUserId,loginUserId,loginUserId,rcmsUserDetails.getUnitNo(),rptContentApprv,nextApprvStep, sysDate,"2");
				masterApprvStatus = "2";
			}
			
			//依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
			//更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId 
			rptContentApprvUserService.updateMasterColumnsByKey(rptId, Integer.parseInt(rptVersion), rptDate, Integer.parseInt(rptSeqno), rptBranch, (Long) rptContentApprv.get("id"), masterApprvStatus, rptContentApprv.getCrossDept(), rptContentApprv.getCrossDeptSetUserId(), rptContentApprv.getApprvStep());
				
			afr.set("result", "success");
		} catch(Exception e){
			log.debug(e);
			afr.set("result", "error");
			
		}
		
		return afr;	
	}
	
	/**
	 * 移管後的新單位設定(設跨單位) 模擬status=0
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param strArrSelStartUserIds
	 * @param strEndUserId
	 * @param strEndUserDepCode
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 * @return
	 */
	@Override
	public AjaxFormResult insertForCrossUnitByBranchTransfer(String rptId, String rptVersion, String rptDate,
			String rptSeqno, String rptBranch, String[] strArrSelStartUserIds, String strEndUserId,
			String strEndUserDepCode, String strConvertTimeStartFull, String[] selDataArr, String strApprvComment,
			JSONObject apprvUserDataObj) {
		//若是移管 先移除被移管單位原本設定的待簽人員 後續再根據apprvStatus=0,1,2...(排除6結案&9跨過單位等)
		rptContentApprvUserService.deleteUsers(rptId, Integer.parseInt(rptSeqno), rptDate, Integer.parseInt(rptVersion), rptBranch, strConvertTimeStartFull);
		
		return this.insertForCrossUnit(rptId, rptVersion, rptDate, rptSeqno, rptBranch, strArrSelStartUserIds, strEndUserId, strEndUserDepCode, strConvertTimeStartFull, selDataArr, strApprvComment, apprvUserDataObj);
	}
	
	/**
	 * 跨單位簽核 apprvStatus:9 表示第二段流程的經辦設定
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param id
	 * @param strArrSelStartUserIds
	 * @param strArrSelEndUserIds
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 */
	@Override
	public AjaxFormResult updateForCrossUnit(RptContentApprv rptContentApprv,
			String[] strArrEndUserIds,String strEndUserDepCode,String[] selDataArr,
			String strApprvComment){

		AjaxFormResult afr = new AjaxFormResult();
		
		try {
		RcmsUserDetails rcmsUserDetails = CapSecurityContext.getUser();
		String loginUserId = CapSecurityContext.getUserId();
		String loginUserName = CapSecurityContext.getUserName();
		String loginUserDepCode = rcmsUserDetails.getUnitNo();
		
		log.debug("updateForCrossUnit--------------------loginUserId:"+loginUserId+",loginUserName:"+loginUserName);
		
		Date sysDate = Calendar.getInstance().getTime();
		List<InfoGrpRpt> infoGrpRptList =  infoGrpRptService.getInfoGrpRptByRptId(rptContentApprv.getRptId());
		
		String resultMsg = "";
		
		String strSetDivisionId = loginUserDepCode;
		
		for (String strEndUserId:strArrEndUserIds){
			boolean b1 = checkInfoGrpRpt(strEndUserId,infoGrpRptList);
			if (!b1) {
				resultMsg = resultMsg + "["+strEndUserId+"] 尚未設定此報表的群組權限\n"; 
				afr.set("result", "error");
				afr.set("resultMsg", resultMsg);
				return afr;
				
			}
		}
		
		List<RptContentApprvUser> apprvUsers1stStage = rptContentApprvUserService.getBySqlCondition(rptContentApprv.getRptId(),rptContentApprv.getRptSeqno().intValue(),  
				rptContentApprv.getRptDate(),rptContentApprv.getRptVersion(),rptContentApprv.getRptBranch());
		
		List<String> apprvUserList = new ArrayList<String>();
		for(RptContentApprvUser oldUser:apprvUsers1stStage){
			log.debug("oldUser="+oldUser.toString());
			apprvUserList.add(oldUser.getApprvUser());
		}
		
		for (String empData:selDataArr){
			String[] empDataArr = empData.split("\\|");
			log.debug("---000----第"+empDataArr[0]+"關,人員:"+empDataArr[1]);
			String[] strSelUserIds = empDataArr[1].split("\\s*,\\s*");
			for (String selUserId:strSelUserIds){
				if (apprvUserList.indexOf(selUserId)<0){//第二段的簽核人員才要檢查
					boolean b2 = checkInfoGrpRpt(selUserId,infoGrpRptList);
					if (!b2) {
						resultMsg = resultMsg + "["+selUserId+"] 尚未設定此報表的群組權限\n"; 
						afr.set("result", "error");
						afr.set("resultMsg", resultMsg);
						return afr;
					}
				}
			}
		}
		
		log.debug("afr result="+ (String)afr.get("result"));
		
		for (String emp:selDataArr){
			log.debug("updateForCrossUnit save emp="+emp);
		}
		
		//改派完須下一個須簽核的層級
		String nextApprvStep = "";
		
		log.debug("updateForCrossUnit rptContentApprv="+rptContentApprv.toString());
		 
		if (strApprvComment != null) strApprvComment = strApprvComment.trim();
		log.debug("updateForCrossUnit save strApprvComment="+strApprvComment);
	
		//2.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
		//2.1 處理第1關
		//略
		
		// apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
		List<String> secondStageApprvSteps = new ArrayList();
		//處理第2關~倒數第2關(決行前一關)
		int apprvStep = apprvUsers1stStage.size()+1;			
		for (String empData:selDataArr){
			log.debug("empData:"+empData);
			
			String[] empDataArr = empData.split("\\|");
			log.debug("---000----第"+empDataArr[0]+"關,人員:"+empDataArr[1]);
			
			
			//String[] strSelUserIds = empIds.split(",");
			String[] strSelUserIds = empDataArr[1].split("\\s*,\\s*");
			
			//String[] strSelUserIds = empIds.split(",");
			//1.會簽, 2.覆核, 3.主管  */
			String strApprvType = strSelUserIds.length > 1 ? "1" : "2";
			String strApprvStep = empDataArr[0];//第幾關
			for (String selUserId:strSelUserIds){
				log.debug("第"+strApprvStep+"關人員:"+selUserId);
				//apprvType 1.會簽, 2.覆核, 3.主管  */
				//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回	
				log.debug("selUserId="+selUserId+",apprvUsers1stStage.indexOf(selUserId)="+apprvUsers1stStage.indexOf(selUserId));
				if (apprvUserList.indexOf(selUserId)<0){
					secondStageApprvSteps.add(strApprvStep);
					saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,selUserId,loginUserDepCode,strApprvStep,strApprvType,"N","2",strSetDivisionId);
				}
			}
			apprvStep ++;
		}
			
			//2.1 處理決行/最後1關
			//String[] strSelEndUserIds = strSelEndUserId.split(",");
			//1.會簽, 2.覆核, 3.主管   4.待設定 */
			String strApprvTypeEnd = "4";
			String strApprvStepEnd = "End";//第1段簽核流程的最後一關
			
			//apprvType 1.會簽, 2.覆核, 3.主管  */
			//log.debug("第End關人員11:"+strEndUserId);
			for (String strEndUserId:strArrEndUserIds){
				saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,strEndUserId,strEndUserDepCode,strApprvStepEnd,strApprvTypeEnd,"N","2",strSetDivisionId);
			}
			
			if (!secondStageApprvSteps.isEmpty())
				nextApprvStep = secondStageApprvSteps.get(0);
			else 
				nextApprvStep = "End";
			
			for(RptContentApprvUser apprvUser:apprvUsers1stStage){
				if (apprvUser.getApprvUser().equalsIgnoreCase(loginUserId)){
					//2.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
					//RptContentApprvUser dataUser = new RptContentApprvUser(rptContentApprv);
					apprvUser.setUpdater(loginUserId);
					apprvUser.setUpdateTime(sysDate);
					apprvUser.setApprvStep(apprvUsers1stStage.size()+""); ///** 簽核層級 1,2,3,4 ...End */
					apprvUser.setIsApprv("Y");
					apprvUser.setApprvStatus("1");
					apprvUser = updateRptContentApprvUser(apprvUser);
					saveRptContentApprvHistory(apprvUser,rptContentApprv.getRptSeqno().intValue(),rptContentApprv.getRptVersion(), strApprvComment,loginUserId, loginUserName,sysDate,"1",RptContentApprvUser.STATUS_APPROVED);
					
				}
			}
			
			log.debug("updateForCrossUnit nextApprvStep:"+nextApprvStep);
			//更新簽核主檔 TODO
			//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
			rptContentApprv.setCrossDeptSetUserId(loginUserId);
			updateRptContentApprv(null,null,loginUserId,null,rptContentApprv,nextApprvStep, sysDate,"2");
			
			//依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
			//更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId 
			rptContentApprvUserService.updateMasterColumnsByKey(rptContentApprv.getRptId(), rptContentApprv.getRptVersion(), rptContentApprv.getRptDate(), rptContentApprv.getRptSeqno().intValue(), rptContentApprv.getRptBranch(), (Long) rptContentApprv.get("id"), "2", rptContentApprv.getCrossDept(), rptContentApprv.getCrossDeptSetUserId(), rptContentApprv.getApprvStep());
			
			afr.set("result", "success");
		} catch(Exception e){
			log.debug(ExceptionUtils.getFullStackTrace(e));
			afr.set("result", "error");
		}
		
		return afr;
				
	}
	
	/**
	 * 第二段經辦被退回後重設後送出更新RPT_CONTENT_APPRV_USER和主檔RPT_CONTENT_APPRV
	 * 只會新增或修改第二關經辦(即第二段流程的第1關)之後的簽核人員
	 * 跨單位簽核 apprvStatus:9 表示第二段流程的經辦設定
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param id
	 * @param strArrSelStartUserIds
	 * @param strArrSelEndUserIds
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 */
	@Override
	public AjaxFormResult updateForCrossUnit2(JSONObject apprvUserDataObj,RptContentApprv rptContentApprv,
			String[] strArrEndUserIds,String strEndUserDepCode,String[] selDataArr,
			String strApprvComment){

		AjaxFormResult afr = new AjaxFormResult();
		
		try {
		RcmsUserDetails rcmsUserDetails = CapSecurityContext.getUser();
		String loginUserId = CapSecurityContext.getUserId();
		String loginUserName = CapSecurityContext.getUserName();
		String loginUserDepCode = rcmsUserDetails.getUnitNo();
		
		log.debug("updateForCrossUnit2--------------------loginUserId:"+loginUserId+",loginUserName:"+loginUserName);
		
		Date sysDate = Calendar.getInstance().getTime();
		List<InfoGrpRpt> infoGrpRptList =  infoGrpRptService.getInfoGrpRptByRptId(rptContentApprv.getRptId());
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		String strConvertTimeStart = sdf.format(rptContentApprv.getConvertTimeStart());
		
		String resultMsg = "";
		
		for (String strEndUserId:strArrEndUserIds){
			boolean b1 = checkInfoGrpRpt(strEndUserId,infoGrpRptList);
			if (!b1) {
				resultMsg = resultMsg + "["+strEndUserId+"] 尚未設定此報表的群組權限\n"; 
				afr.set("result", "error");
				afr.set("resultMsg", resultMsg);
				return afr;
			}
		}
		
		List<RptContentApprvUser> existApprvUsers = rptContentApprvUserService.getBySqlCondition(rptContentApprv.getRptId(),rptContentApprv.getRptSeqno().intValue(),  
				rptContentApprv.getRptDate(),rptContentApprv.getRptVersion(),rptContentApprv.getRptBranch());
		//selDataArr 格式:2|HB00001,HB00002  2為層級 有新增的資料才會傳過來
		
		List<String> existApprvUserIds = new ArrayList();
		for ( RptContentApprvUser emp2: existApprvUsers){
			log.debug("emp2==" + emp2.toString());
			if(emp2.getIsApprv()!= null && "Y".equals(emp2.getIsApprv())) {
				existApprvUserIds.add(emp2.getApprvUser());
			}
		}
		for (String empData:selDataArr){
			String[] empDataArr = empData.split("\\|");
			log.debug("---000----第"+empDataArr[0]+"關,人員:"+empDataArr[1]);
			String[] strSelUserIds = empDataArr[1].split("\\s*,\\s*");
			for (String selUserId:strSelUserIds){
				if (existApprvUsers.indexOf(selUserId)<0){//第二段的簽核人員才要檢查
					boolean b2 = checkInfoGrpRpt(selUserId,infoGrpRptList);
					if (!b2) {
						resultMsg = resultMsg + "["+selUserId+"] 尚未設定此報表的群組權限\n"; 
						afr.set("result", "error");
						afr.set("resultMsg", resultMsg);
						return afr;
					}
				}
			}
		}
		
		log.debug("afr result="+ (String)afr.get("result"));
		
		deleteOrigialUnApprvedUsers(apprvUserDataObj,rptContentApprv,strConvertTimeStart);
		
		//改派完須下一個須簽核的層級
		String nextApprvStep = "";
		
		log.debug("updateForCrossUnit2 rptContentApprv="+rptContentApprv.toString());
		 
		if (strApprvComment != null) strApprvComment = strApprvComment.trim();
		log.debug("updateForCrossUnit2 save strApprvComment="+strApprvComment);
	
		//2.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
		//2.1 處理第1關
		//String[] strSelStartUserIds = strSelStartUserId.split(",");
		//1.會簽, 2.覆核, 3.主管  */
		
		
		// apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
		List<String> secondStageApprvSteps = new ArrayList();
		//處理第2關~倒數第2關(決行前一關)
		List<String> stepList = new ArrayList();
		for (String empData:selDataArr){
			String[] empDataArr = empData.split("\\|");
			log.debug("---111----"+empDataArr[0]+"關,人員:"+empDataArr[1]);
			String[] strSelUserIds = empDataArr[1].split("\\s*,\\s*");
			String strApprvStep = empDataArr[0];
			log.debug("strApprvStep="+strApprvStep);
			stepList.add(strApprvStep);
			//1.會簽, 2.覆核, 3.主管  */
			String strApprvType = strSelUserIds.length > 1 ? "1" : "2";
			//String strApprvStep = apprvStep+"";//第幾關
			for (String selUserId:strSelUserIds){
				log.debug("第2關人員11:"+selUserId);
				
				//apprvType 1.會簽, 2.覆核, 3.主管  */
				//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回	
					secondStageApprvSteps.add(strApprvStep);
				if (existApprvUserIds.indexOf(selUserId)<0){
					saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,selUserId,loginUserDepCode,strApprvStep,strApprvType,"N","2",loginUserDepCode);
				} 
			}
		}
			
			//2.1 處理決行/最後1關
			//String[] strSelEndUserIds = strSelEndUserId.split(",");
			//1.會簽, 2.覆核, 3.主管   4.待設定 */
			String strApprvTypeEnd = "3";
			String strApprvStepEnd = "End";//第1段簽核流程的最後一關
			
				//apprvType 1.會簽, 2.覆核, 3.主管  */
			//log.debug("第End關人員11:"+strEndUserId);
			for (String strEndUserId:strArrEndUserIds){
				saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,strEndUserId,strEndUserDepCode,strApprvStepEnd,strApprvTypeEnd,"N","2",loginUserDepCode);
			}
			
			for(RptContentApprvUser apprvUser:existApprvUsers){
				if (apprvUser.getApprvUser().equalsIgnoreCase(loginUserId)){
					//2.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
					//RptContentApprvUser dataUser = new RptContentApprvUser(rptContentApprv);
					apprvUser.setUpdater(loginUserId);
					apprvUser.setUpdateTime(sysDate);
					//apprvUser.setApprvStep(secondStageApprvSteps[1]); ///** 簽核層級 1,2,3,4 ...End */
					apprvUser.setIsApprv("Y");
					apprvUser.setApprvStatus("1");
					apprvUser = updateRptContentApprvUser(apprvUser);
					saveRptContentApprvHistory(apprvUser,rptContentApprv.getRptSeqno().intValue(),rptContentApprv.getRptVersion(), strApprvComment,loginUserId, loginUserName,sysDate,"1",RptContentApprvUser.STATUS_APPROVED);
				} else if (apprvUser.getIsApprv().equals("Y") && apprvUser.getApprvStatus().equals("3")){
					apprvUser.setIsApprv("N");
					apprvUser.setApprvStatus("2");
					updateRptContentApprvUser(apprvUser);
				}
			}
			
			//退回後由第二關的經辦送出
			nextApprvStep = getNextApprvStep(rptContentApprv, strConvertTimeStart);
			
			log.debug("nextApprvStep="+nextApprvStep);
			log.debug("updateForCrossUnit2 nextApprvStep:"+nextApprvStep);
			//更新簽核主檔
			//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
			updateRptContentApprv(loginUserId,null,loginUserId,null,rptContentApprv,nextApprvStep, sysDate,"2");
			
			//依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
			//更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId 
			rptContentApprvUserService.updateMasterColumnsByKey(rptContentApprv.getRptId(), rptContentApprv.getRptVersion(), rptContentApprv.getRptDate(), rptContentApprv.getRptSeqno().intValue(), rptContentApprv.getRptBranch(), (Long) rptContentApprv.get("id"), "2", rptContentApprv.getCrossDept(), rptContentApprv.getCrossDeptSetUserId(), rptContentApprv.getApprvStep());
			
			afr.set("result", "success");
		} catch(Exception e){
			log.debug(e);
			afr.set("result", "error");
			
		}
		
		return afr;
				
	}
	
	
	/**
	 * 跨單位簽核 - 第一段流程退回至第一個單位的經辦後於[待簽核報表]功能重新設定後送出
	 * 更新RPT_CONTENT_APPRV_USER和主檔RPT_CONTENT_APPRV
	 * 只會新增或修改第二關經辦(即第二段流程的第1關)之後的簽核人員
	 * TODO:須考慮第1關若有設定多人會簽 則退回至經辦第1關應仍可以修改簽核人員
	 * 
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param id
	 * @param strArrSelStartUserIds
	 * @param strArrSelEndUserIds
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 */
	@Override
	public AjaxFormResult updateForCrossUnit1(JSONObject apprvUserDataObj,RptContentApprv rptContentApprv,
			String[] strArrEndUserIds,String strEndUserDepCode,String[] selDataArr,
			String strApprvComment){

		AjaxFormResult afr = new AjaxFormResult();
		
		try {
		RcmsUserDetails rcmsUserDetails = CapSecurityContext.getUser();
		String loginUserId = CapSecurityContext.getUserId();
		String loginUserName = CapSecurityContext.getUserName();
		String loginUserDepCode = rcmsUserDetails.getUnitNo();
		
		log.debug("updateForCrossUnit1--------------------loginUserId:"+loginUserId+",loginUserName:"+loginUserName);
		
		Date sysDate = Calendar.getInstance().getTime();
		List<InfoGrpRpt> infoGrpRptList =  infoGrpRptService.getInfoGrpRptByRptId(rptContentApprv.getRptId());
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		String strConvertTimeStart = sdf.format(rptContentApprv.getConvertTimeStart());
		
		String resultMsg = "";
		
		for (String strEndUserId:strArrEndUserIds){
			boolean b1 = checkInfoGrpRpt(strEndUserId,infoGrpRptList);
			if (!b1) {
				resultMsg = resultMsg + "["+strEndUserId+"] 尚未設定此報表的群組權限\n"; 
				afr.set("result", "error");
				afr.set("resultMsg", resultMsg);
				return afr;
			}
		}
		
		List<RptContentApprvUser> existApprvUsers = rptContentApprvUserService.getBySqlCondition(rptContentApprv.getRptId(),rptContentApprv.getRptSeqno().intValue(),  
				rptContentApprv.getRptDate(),rptContentApprv.getRptVersion(),rptContentApprv.getRptBranch());
		//selDataArr 格式:2|HB00001,HB00002  2為層級 有新增的資料才會傳過來
		
		List<String> existApprvUserIds = new ArrayList();
		for ( RptContentApprvUser emp2: existApprvUsers){
			log.debug("emp2==" + emp2.toString());
			if(emp2.getIsApprv()!= null && "Y".equals(emp2.getIsApprv())) {
				existApprvUserIds.add(emp2.getApprvUser());
			}
		}
		for (String empData:selDataArr){
			String[] empDataArr = empData.split("\\|");
			log.debug("---000----第"+empDataArr[0]+"關,人員:"+empDataArr[1]);
			String[] strSelUserIds = empDataArr[1].split("\\s*,\\s*");
			for (String selUserId:strSelUserIds){
				if (existApprvUsers.indexOf(selUserId)<0){//第二段的簽核人員才要檢查
					boolean b2 = checkInfoGrpRpt(selUserId,infoGrpRptList);
					if (!b2) {
						resultMsg = resultMsg + "["+selUserId+"] 尚未設定此報表的群組權限\n"; 
						afr.set("result", "error");
						afr.set("resultMsg", resultMsg);
						return afr;
					}
				}
			}
		}
		
		log.debug("afr result="+ (String)afr.get("result"));
		
		deleteOrigialUnApprvedUsers(apprvUserDataObj,rptContentApprv,strConvertTimeStart);
		
		//改派完須下一個須簽核的層級
		String nextApprvStep = "";
		
		log.debug("updateForCrossUnit1 rptContentApprv="+rptContentApprv.toString());
		 
		if (strApprvComment != null) strApprvComment = strApprvComment.trim();
		log.debug("updateForCrossUnit1 save strApprvComment="+strApprvComment);
	
		//2.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
		//2.1 處理第1關
		//String[] strSelStartUserIds = strSelStartUserId.split(",");
		//1.會簽, 2.覆核, 3.主管  */
		
		
		// apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
		List<String> secondStageApprvSteps = new ArrayList();
		//處理第2關~倒數第2關(決行前一關)
		String lastSetp = "1";
		List<String> stepList = new ArrayList();
		for (String empData:selDataArr){
			String[] empDataArr = empData.split("\\|");
			log.debug("---111----"+empDataArr[0]+"關,人員:"+empDataArr[1]);
			String[] strSelUserIds = empDataArr[1].split("\\s*,\\s*");
			String strApprvStep = empDataArr[0];
			log.debug("strApprvStep="+strApprvStep);
			stepList.add(strApprvStep);
			//1.會簽, 2.覆核, 3.主管  */
			String strApprvType = strSelUserIds.length > 1 ? "1" : "2";
			//String strApprvStep = apprvStep+"";//第幾關
			for (String selUserId:strSelUserIds){
				log.debug("第2關人員11:"+selUserId);
				
				//apprvType 1.會簽, 2.覆核, 3.主管  */
				//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回	
					secondStageApprvSteps.add(strApprvStep);
				if (existApprvUserIds.indexOf(selUserId)<0){
					saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,selUserId,loginUserDepCode,strApprvStep,strApprvType,"N","2",loginUserDepCode);
				} 
			}
			
			lastSetp = strApprvStep;
		}
			
			//2.1 處理決行/最後1關
			//String[] strSelEndUserIds = strSelEndUserId.split(",");
			//1.會簽, 2.覆核, 3.主管   4.待設定 */
			String strApprvTypeEnd = "3";
			//String strApprvStepEnd = "E1";//第1段簽核流程的最後一關
			log.debug("lastSetp==="+lastSetp);
			String strApprvStepEnd =  (Integer.parseInt(lastSetp) + 1)+"";
			
			log.debug("strApprvStepEnd==="+strApprvStepEnd);
			
				//apprvType 1.會簽, 2.覆核, 3.主管  */
			//log.debug("第End關人員11:"+strEndUserId);
			for (String strEndUserId:strArrEndUserIds){
				saveRptContentApprvUser(rptContentApprv,loginUserId,sysDate,strEndUserId,strEndUserDepCode,strApprvStepEnd,strApprvTypeEnd,"N","2",loginUserDepCode);
			}
			
			for(RptContentApprvUser apprvUser:existApprvUsers){
				if (apprvUser.getApprvUser().equalsIgnoreCase(loginUserId)){
					//2.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
					//RptContentApprvUser dataUser = new RptContentApprvUser(rptContentApprv);
					apprvUser.setUpdater(loginUserId);
					apprvUser.setUpdateTime(sysDate);
					//apprvUser.setApprvStep(secondStageApprvSteps[1]); ///** 簽核層級 1,2,3,4 ...End */
					apprvUser.setIsApprv("Y");
					apprvUser.setApprvStatus("1");
					apprvUser = updateRptContentApprvUser(apprvUser);
					saveRptContentApprvHistory(apprvUser,rptContentApprv.getRptSeqno().intValue(),rptContentApprv.getRptVersion(), strApprvComment,loginUserId, loginUserName,sysDate,"1",RptContentApprvUser.STATUS_APPROVED);
				} else if (apprvUser.getIsApprv().equals("Y") && apprvUser.getApprvStatus().equals("3")){
					apprvUser.setIsApprv("N");
					apprvUser.setApprvStatus("2");
					updateRptContentApprvUser(apprvUser);
				}
			}
			
			//退回後由第二關的經辦送出
			nextApprvStep = getNextApprvStep(rptContentApprv, strConvertTimeStart);
			
			log.debug("updateForCrossUnit1 nextApprvStep:"+nextApprvStep);
			//更新簽核主檔
			//apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回
			if (strApprvStepEnd!=null && strApprvStepEnd.equals("2")){//下一關為第2單位經辦設定
				updateRptContentApprv(loginUserId,null,loginUserId,null,rptContentApprv,nextApprvStep, sysDate,"9");
				
				//依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
				//更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId 
				rptContentApprvUserService.updateMasterColumnsByKey(rptContentApprv.getRptId(), rptContentApprv.getRptVersion(), rptContentApprv.getRptDate(), rptContentApprv.getRptSeqno().intValue(), rptContentApprv.getRptBranch(), (Long) rptContentApprv.get("id"), "9", rptContentApprv.getCrossDept(), rptContentApprv.getCrossDeptSetUserId(), rptContentApprv.getApprvStep());
			} else {
				updateRptContentApprv(loginUserId,null,loginUserId,null,rptContentApprv,nextApprvStep, sysDate,"2");
				
				//依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
				//更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId 
				rptContentApprvUserService.updateMasterColumnsByKey(rptContentApprv.getRptId(), rptContentApprv.getRptVersion(), rptContentApprv.getRptDate(), rptContentApprv.getRptSeqno().intValue(), rptContentApprv.getRptBranch(), (Long) rptContentApprv.get("id"), "2", rptContentApprv.getCrossDept(), rptContentApprv.getCrossDeptSetUserId(), rptContentApprv.getApprvStep());
			}
			
			
			afr.set("result", "success");
		} catch(Exception e){
			log.debug(e);
			afr.set("result", "error");
			
		}
		
		return afr;
				
	}
	
	/** 
	 * <pre>
	 * 刪除原本於RptContentApprvUser 未簽核(isApprv=N)的人員ID
	 * </pre>
	 * @param apprvUserDataObj 原本的RptContentApprvUser的設定資料
	 * 
	 * @return
	 * @see txn104041Handler
	 */
	private void deleteOrigialUnApprvedUsers(JSONObject originalApprvUserDataObj,RptContentApprv main,String convertTimeStart){
		//apprvSte, HB00VV|Y,HB0493|Y
		List<String> list = new ArrayList();
		Set<String> apprvStepSet = originalApprvUserDataObj.keySet();
		
		for (String apprvStep : apprvStepSet) {
			//animals.trim().split("\\s*,\\s*");
			log.debug("deleteOrigialUnApprvedUsers apprvStep="+apprvStep);
			String apprvUserIds = originalApprvUserDataObj.getString(apprvStep);
			log.debug("deleteOrigialUnApprvedUsers apprvUserIds="+apprvUserIds);
			String[] arrApprvUserIds = apprvUserIds.trim().split("\\s*,\\s*");
			for (int i = 0 ; i <arrApprvUserIds.length;i++){
				String[] data = arrApprvUserIds[i].split("\\|");
				//String isApprv = data[1];
				
				log.debug("deleteOrigialUnApprvedUsers userId 00="+data[0]+",isApprv="+data[1]);
				
				if (data[1] != null && data[1].equals("N")){
					list.add(data[0]);
				}
			}
		}
				 
		/*log.debug("apprvUserDataObj 1="+originalApprvUserDataObj.getString("1"));//format: HB00VV|Y,HB0493|Y
		log.debug("apprvUserDataObj 2="+originalApprvUserDataObj.getString("2"));//format: HB0761|Y,HB0665|N
		log.debug("apprvUserDataObj End="+originalApprvUserDataObj.getString("End"));*/
		
		log.debug("deleteOrigialUnApprvedUsers list="+list.size());
		
		if (list!=null && list.size()>0){
			int  cntDel = rptContentApprvUserService.deleteUsers(main.getRptId(), main.getRptSeqno().intValue(), main.getRptDate(), main.getRptVersion(), 
					main.getRptBranch(), convertTimeStart, list);
			
			log.debug("deleteOrigialUnApprvedUsers cntDel="+cntDel);
		}
		
	}
	
	/**
	 * 檢查人員是否有該報表的報表群組權限
	 */
	private boolean checkInfoGrpRpt(String userId,List<InfoGrpRpt> list){
		boolean isExist = false;
		for(InfoGrpRpt infoGrpRpt: list){
			log.debug("checkInfoGrpRpt isExist="+isExist+",userId="+userId+",infoGrpRpt grpId="+infoGrpRpt.getId().getGrpId()+",rptId="+infoGrpRpt.getId().getRptId());
			List<InfoGrpUser>  infoGrpUserList = infoGrpUserService.findInfoGrpUserByConditions(userId,infoGrpRpt.getId().getGrpId()); 
			if (infoGrpUserList!=null && infoGrpUserList.size()>0){
				isExist = true;
				break;
			}
		}
		
		log.debug("checkInfoGrpRpt isExist="+isExist+",userId="+userId);
		return isExist;
	}
	
	@Override
	public  int getRptApprvHisPageRows(String pageSize,String pageOrientation){
		int pageRows = 20;
		Map<String,String> map = new HashMap<String,String>();
		/*map.put("A3_P", "20"); //297*420
		map.put("A4_P", "10"); //210*297
		map.put("B4_P", "15"); //250*353
		map.put("15x11_P", "15"); //
		map.put("B3_P", "20"); //353*500
		map.put("B5_P", "10"); //176*250
*/		
		map.put("A3_L", "26"); //420*397
		map.put("A3_P", "20"); //297*420
		map.put("A4_P", "10"); //210*297
		map.put("B4_P", "15"); //250*353
		map.put("15x11_P", "15"); //
		map.put("B3_P", "30"); //353*500
		map.put("B5_P", "10"); //176*250
		
		if (map.get(pageSize +"_" +pageOrientation) != null){
			pageRows = Integer.parseInt(map.get(pageSize +"_" +pageOrientation));
			log.debug("getRptApprvHisPageRows 00 pageSize:" +pageSize +",pageOrientation:" +pageOrientation + ",pageRows="+pageRows);
		}
		
		log.debug("getRptApprvHisPageRows 11 pageSize:" +pageSize +",pageOrientation:" +pageOrientation + ",pageRows="+pageRows);
		
		return pageRows;
	}
	
	/**
	 * 查詢待簽核報表件數(含簽核中及退回)
	 * @param apprvCaseType 本人案件0或代理案件1
	 * @param loginUserId
	 * @return
	
	@Override
	public int getToApprvCnt(String apprvCaseType,String loginUserId) {
		long timeStart = Calendar.getInstance().getTimeInMillis();
		//1:代理案件 找出目前代理的被代人ID及代理群組 (apprvCaseType=0:本人案件 1:代理案件)
		if (apprvCaseType.equals("1")){
			//依員編查詢待簽核筆數(含簽核中及退回)
			int cnt = rptContentApprvUserService.countToApprvDeputy(loginUserId); 			
			log.debug("time spent apprvCaseType(1) : getToApprvCnt = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
			return cnt;
		} else {
			log.debug("0:本人案件 loginUserId="+loginUserId);			
			int cnt = rptContentApprvUserService.countToApprv(loginUserId);
			log.debug("time spent  apprvCaseType(0): getToApprvCnt = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
			return cnt;
		}
	}
	 */
	
	/**
	 * 查詢待簽核報表件數(含簽核中及退回)
	 * @param apprvCaseType 本人案件0或代理案件1
	 * @param loginUserId
	 * @return 待簽核報表件數(含簽核中及退回)
	*/
	@Override
	public int getToApprvCnt(String apprvCaseType,String loginUserId) {
		RcmsUserDetails user = CapSecurityContext.getUser();
		String strApprvUserDept = user.getUnitNo();
		log.debug("strApprvUserDept="+strApprvUserDept);
		
		final List<String> oldBranchIds = aclBranchTransferService.getAllAclBranchTransferIdsByNewBranchId(strApprvUserDept);
		oldBranchIds.add("none");
		log.debug("oldBranchIds="+oldBranchIds);
		
		//預設只會找出必簽報表
		List<String> infoGrpRptIds = ((RcmsUserDetails) CapSecurityContext.getUser()).getApproveRptIds();
		
		String rptId = null;
		String rptName = null;
		int rptSeqno = 0;
		String rptCycle = null;
		String mustPrint = null;
		String rptDateBegin = null;
		String rptDateEnd = null;
		String convertDateStart = null ;
		String convertDateEnd = null ;
		Date sysDate = new Date();
		String strQueryUserId = "";
		
		//1:代理案件 找出目前代理的被代人ID及代理群組 (apprvCaseType=0:本人案件 1:代理案件)
		if (apprvCaseType.equals("1")){
			infoGrpRptIds = new ArrayList<String>();
			List<InfoUserDeputy> list = infoUserDeputyService.findByCondition(null, user.getUserId(), sysDate);
			for (InfoUserDeputy e:list){
				strQueryUserId = e.getUserId();
				
				//若為跨單位簽核,則要找出該人員所在單位
				List<AclUser> aclUserList = aclUserService.getAclUserByCondition(strQueryUserId, null, null);
				
				if (aclUserList!=null && !aclUserList.isEmpty()){
					strApprvUserDept = aclUserList.get(0).getDivisionId();
					log.debug("strApprvUserDept 11="+strApprvUserDept);
				}
				
				log.debug("1:代理案件 strQueryUserId="+strQueryUserId);
				String[] grpIds = e.getGrpId().split(",");

				for (String grpId: grpIds){
					List<InfoGrpRpt> infoGrpRptList = infoGrpRptService.getInfoGrpRptByGrpId(grpId);
					for (InfoGrpRpt infoGrpRpt:infoGrpRptList){
						infoGrpRptIds.add(infoGrpRpt.getId().getRptId());
					}
				}	
				
				HashSet set = new HashSet();
				set.addAll(infoGrpRptIds);
				infoGrpRptIds.clear();
				infoGrpRptIds.addAll(set);
			}
			
			
			
			//依員編查詢待簽核筆數(含簽核中及退回)
			//int cnt = rptContentApprvUserService.countToApprvDeputy(loginUserId); 			
			//log.debug("time spent apprvCaseType(1) : getToApprvCnt = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
			//return cnt;
		} else {
			strQueryUserId = user.getUserId();
			
			//log.debug("0:本人案件 loginUserId="+loginUserId);			
			//int cnt = rptContentApprvUserService.countToApprv(loginUserId);
			//log.debug("time spent  apprvCaseType(0): getToApprvCnt = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
			//return cnt;
		}
		
		return rptContentApprvUserService.countBySqlCondition(rptId,
				infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint, rptDateBegin, rptDateEnd,strQueryUserId,"N",
				strApprvUserDept, oldBranchIds, convertDateStart,convertDateEnd);
	}
	
	
	/**
	 * 經辦已送出作廢待主管放行的筆數
	 * @return 經辦已送出作廢待主管放行的筆數
	 * @ref Txn104121Handler
	 */
	@Override
	public int getToApprvInvalidCnt(String unitNo){
		int cnt = 0;
		try {
			cnt = rptContentApprvService.countInvalid(unitNo);
		} catch(Exception e){
			log.debug("getToApprvInvalidCnt Exception:" + e);
		}
		return cnt;
		
	}
	
	/**
	 * 經辦已送出作廢待主管放行的筆數
	 * @return 經辦已送出作廢待主管放行的筆數
	 * @ref Txn104121Handler
	 */
	@Override
	public int getToApprvInvalidCntByUser(String empId){
		int cnt = 0;
		try {
			cnt = rptContentApprvService.countInvalidByUser(empId);
		} catch(Exception e){
			log.debug("getToApprvInvalidCntByUser Exception:" + e);
		}
		return cnt;
		
	}
	
	/**
	 * 待改派(單位異動)報表件數
	 * from Txn104031
	 * @param empId 登入者員編
	 * @return 待改派(單位異動)報表件數
	 */
	@Override
	public int getToReAssignCnt(String empId){
		int cnt = 0;
		// --AclUser Status=A 離職或是所屬單位與setUserDivisionId不同
		try{
			cnt =  rptContentApprvUserService.countToApprvByUnitChange(empId);
		} catch(Exception e){
			log.error("getToReAssignCnt Exception:"+e.getMessage());
		}
		
		return cnt;

	}
	
	/**
	 * 代理人維護(待簽核) 件數
	 * 代理人維護(退回) 件數
	 * @param userId 使用者員編	
	 * @return 代理人維護(待簽核/退回) 件數
	 */
	@Override
	public int getToApprvDeputyCnt(String userId) {
		/*int cnt = 0;
		log.debug("getToApprvDeputyCnt,loginUserId:"+loginUserId+",unitNo:"+unitNo+",isMgr:"+isMgr);
		if (isMgr!=null && isMgr.equals("Y")){
			cnt =  cnt + infoUserDeputyService.countByDivisionId(unitNo);
			log.debug("getToApprvDeputyCnt,unitNo:" + unitNo + ",cnt:" + cnt);
		}
		
		//查詢被主管退回action=02的資料
		cnt =  cnt + infoUserDeputyService.countByApplicant(loginUserId, "02");
		log.debug("getRejectDeputyCnt 代理人維護(退回)的資料筆數==="+cnt);
		*/
		
		int cnt = infoUserDeputyService.countByUser(userId);
		return cnt;
	}
	
	/**
	 * 查詢待設定件數(含跨單位)
	 * @param empId
	 * @return 待設定件數(含跨單位)
	 */
	@Override
	public int getToSettingCnt(String empId){
		return rptContentApprvService.getToSettingCnt(empId);
	}
	
	/**
	 * 依員編查詢是否有任何簽核相關資料
	 * @param empId
	 * @return 依員編查詢是否有任何簽核相關資料筆數
	 */
	@Override
	public int getExistApprvDataCnt(String empId){
		return rptContentApprvService.getExistApprvDataCnt(empId);
	}
}