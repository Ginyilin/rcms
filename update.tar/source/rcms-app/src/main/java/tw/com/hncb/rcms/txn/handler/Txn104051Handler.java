/* 
 * Txn104051Handler.java
 * 
 * Copyright (c) 2009-2017 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.txn.handler;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import com.iisigroup.cap.annotation.HandlerType;
import com.iisigroup.cap.annotation.HandlerType.HandlerTypeEnum;
import com.iisigroup.cap.component.IRequest;
import com.iisigroup.cap.dao.utils.ISearch;
import com.iisigroup.cap.formatter.IBeanFormatter;
import com.iisigroup.cap.handler.MFormHandler;
import com.iisigroup.cap.model.Page;
import com.iisigroup.cap.response.AjaxFormResult;
import com.iisigroup.cap.response.GridResult;
import com.iisigroup.cap.security.CapSecurityContext;
import com.iisigroup.cap.utils.CapString;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import tw.com.hncb.rcms.acl.core.RcmsUserDetails;
import tw.com.hncb.rcms.com.core.RcmsContextAware;
import tw.com.hncb.rcms.com.formatter.CfgCodeTypeFormatter;
import tw.com.hncb.rcms.com.service.RcmsEmailService;
import tw.com.hncb.rcms.model.AclUser;
import tw.com.hncb.rcms.model.CfgSysParm;
import tw.com.hncb.rcms.model.InfoDep;
import tw.com.hncb.rcms.model.InfoGrpRpt;
import tw.com.hncb.rcms.model.InfoGrpUser;
import tw.com.hncb.rcms.model.InfoGrpUserDraft;
import tw.com.hncb.rcms.model.InfoUserDeputy;
import tw.com.hncb.rcms.model.RptContentApprvUser;
import tw.com.hncb.rcms.model.RptDefineMaster;
import tw.com.hncb.rcms.model.VwRptContentApprvPDData;
import tw.com.hncb.rcms.model.VwRptContentApprvUserPDData;
import tw.com.hncb.rcms.model.VwRptDefineMaster;
import tw.com.hncb.rcms.txn.service.AclBranchTransferService;
import tw.com.hncb.rcms.txn.service.AclUserService;
import tw.com.hncb.rcms.txn.service.CfgCodeTypeRcmsService;
import tw.com.hncb.rcms.txn.service.CfgSysParmService;
import tw.com.hncb.rcms.txn.service.InfoDepService;
import tw.com.hncb.rcms.txn.service.InfoGrpRptService;
import tw.com.hncb.rcms.txn.service.InfoGrpService;
import tw.com.hncb.rcms.txn.service.InfoGrpUserDraftService;
import tw.com.hncb.rcms.txn.service.InfoGrpUserService;
import tw.com.hncb.rcms.txn.service.InfoUserDeputyService;
import tw.com.hncb.rcms.txn.service.RptApprvService;
import tw.com.hncb.rcms.txn.service.RptClassService;
import tw.com.hncb.rcms.txn.service.RptContentApprvHisService;
import tw.com.hncb.rcms.txn.service.RptContentApprvService;
import tw.com.hncb.rcms.txn.service.RptContentApprvUserService;
import tw.com.hncb.rcms.txn.service.RptDataService;
import tw.com.hncb.rcms.txn.service.RptDefineMasterService;
import tw.com.hncb.rcms.txn.service.VwRptDefineMasterService;



/**
 * <pre>
 * 簽核作業 - 待簽核報表處理器
 * 決行 - 自動帶出單位內的主管人員(判斷人員的職稱代號是否為主管Table : INFO_POSITION)
 * 找出本人案件或代理案件
 * 若為報表的第1關預設經辦,案件若有退回也須查詢出來
 * 
 * 
 * </pre>
 * 
 * @since 2017-3-19
 * @author jeanlin
 * @version <ul>
 *          <li>2017-3-19,jeanlin,new
 *          </ul>
 */
@Scope("request")
@Controller("txn104051handler")
public class Txn104051Handler extends MFormHandler {
	
	private static Log log = LogFactory.getLog(Txn104051Handler.class);
	
	/** 存取群組與使用者對映草稿table[INFO_GRP_USER_DRAFT]的Service */
	@Autowired
	private InfoGrpUserDraftService infoGrpUserDraftService;
	
	/**簽核:代理人資料的Service */
	@Autowired
	private InfoUserDeputyService infoUserDeputyService;
	
	/** 存取使用者帳號table[ACL_USER]的Service */
	@Autowired
	private AclUserService aclUserService;
	
	/** 存取群組資料table[INFO_GRP]的Service */
	@Autowired
	private InfoGrpService infoGrpService;
	
	/** 存取群組與使用者對映table[INFO_GRP_USER]的Service */
	@Autowired
	private InfoGrpUserService infoGrpUserService;
	
	/** 存取系統參數代碼table[CFG_CODETYPE]的Service */
	@Autowired
	private CfgCodeTypeRcmsService cfgCodeTypeRcmsService;
	
	/** 存取系統參數table[CFG_SYSPARM]的Service */
	@Autowired
	private CfgSysParmService parmSrv;
	
	@Autowired
	private RptDefineMasterService rptDefineMasterService;
	
	/** 存取報表定義view[VW_RPT_DEFINE_MASTER]的Service */
	@Autowired
	private  VwRptDefineMasterService vwRptDefineMasterService;
	
	@Autowired
	RptContentApprvService rptContentApprvService;
	
	@Autowired
	RptContentApprvUserService rptContentApprvUserService;
	
	@Autowired
	RptContentApprvHisService rptContentApprvHistoryService;
	
	@Autowired
	RptDataService rptDataService;
	
	@Autowired
	RptClassService rptClassService;
	
	@Autowired
	RptApprvService rptApprvService;
	
	@Autowired
	private InfoGrpRptService infoGrpRptService;
	
	@Autowired
	private InfoDepService infoDepService;
	
	@Autowired
	private AclBranchTransferService aclBranchTransferService;
	
	
	/**
	 * <pre>
	 * 確認使用者身份並取得目前該使用者身上的待簽核報表(包含退回案件 : 一律退回設定該報表的第1關人員/預設經辦 )。
	 * </pre>
	 * @param search
	 * 			設定查詢結果
	 * @param request
	 *             用戶端所發出的請求之物件
	 * @return 常用報表查詢結果(RptContentMaster)和view開啟所需的參數(RptDefineMaster)
	 */
	@SuppressWarnings("serial")
	@HandlerType(HandlerTypeEnum.GRID)
	public GridResult query(ISearch search, IRequest request) {
		
		RcmsUserDetails user = CapSecurityContext.getUser();
		
		
		final String loginUserId = user.getUserId();
		
		//簽核狀態
		final Map<String,String> apprvStatusMap = cfgCodeTypeRcmsService.findByCodeType("apprvStatusQry");
				
		long timeStart = Calendar.getInstance().getTimeInMillis();

		String rptId = null;
		String rptName = null;
		int rptSeqno = 0;
		String rptCycle = null;
		String mustPrint = null;
		String mustApprove = "Y";//只找出必簽報表
		String rptDateBegin = null;
		String rptDateEnd = null;
		String convertDateStart = null ;
		String convertDateEnd = null ;
		String pd = "Y";
		
		//本人案件0或代理案件1
		String apprvCaseType ="";
		
		Date sysDate = new Date();
		
		String strQueryUserId = "";
		
		String strApprvUserDept = "";
		
		strApprvUserDept = user.getUnitNo();
		log.debug("strApprvUserDept="+strApprvUserDept);
		
		final List<String> oldBranchIds = aclBranchTransferService.getAllAclBranchTransferIdsByNewBranchId(strApprvUserDept);
		oldBranchIds.add("none");
		logger.debug("oldBranchIds="+oldBranchIds);
		

		// 取得codeType
		final Map<String, String> governmentUnitMap = cfgCodeTypeRcmsService.findByCodeType("governingUnit");
		logger.debug("time spent : governmentUnitMap = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
		timeStart = Calendar.getInstance().getTimeInMillis();

		if (!CapString.isEmpty(request.get("rptId"))) {
			rptId = request.get("rptId");
		}
		
		if (!CapString.isEmpty(request.get("rptName"))) {
			rptName = request.get("rptName");
		}
		
		//0:本人案件 1:代理案件
		if (!CapString.isEmpty(request.get("q_apprvCaseType"))) {
			apprvCaseType = request.get("q_apprvCaseType");
			log.debug("apprvCaseType="+apprvCaseType);
		}
		
		List<String> infoGrpRptIds = new ArrayList<String>();
		infoGrpRptIds.addAll(((RcmsUserDetails) CapSecurityContext.getUser()).getUserRptIds());
		
		//預設只會找出必簽報表
		if(mustApprove != null && mustApprove.trim().equals("Y")){
			infoGrpRptIds = ((RcmsUserDetails) CapSecurityContext.getUser()).getApproveRptIds();
		}else if (mustApprove != null && mustApprove.trim().equals("N")){
			List<String> approve = ((RcmsUserDetails) CapSecurityContext.getUser()).getApproveRptIds();
			infoGrpRptIds.removeAll(approve);
		}
		
		//0:本人案件 1:代理案件
		final String type = apprvCaseType;
		/*for(String s:infoGrpRptIds){
			log.debug("InfoGrpRptid="+s);
		}*/
		
		//1:代理案件 找出目前代理的被代人ID及代理群組 (apprvCaseType=0:本人案件 1:代理案件)
		if (apprvCaseType.equals("1")){
			infoGrpRptIds = new ArrayList<String>();
			//只找出代理群組裡的待簽核報表
			List<InfoUserDeputy> list = infoUserDeputyService.findByCondition(null, user.getUserId(), sysDate);
			for (InfoUserDeputy e:list){
				strQueryUserId = e.getUserId();
				
				//若為跨單位簽核,則要找出該人員所在單位
				List<AclUser> aclUserList = aclUserService.getAclUserByCondition(strQueryUserId, null, null);
				
				if (aclUserList!=null && !aclUserList.isEmpty()){
					strApprvUserDept = aclUserList.get(0).getDivisionId();
					log.debug("strApprvUserDept 11="+strApprvUserDept);
				}
				
				log.debug("1:代理案件 strQueryUserId="+strQueryUserId);
				String[] grpIds = e.getGrpId().split(",");

				for (String grpId: grpIds){
					List<InfoGrpRpt> infoGrpRptList = infoGrpRptService.getInfoGrpRptByGrpId(grpId);
					for (InfoGrpRpt infoGrpRpt:infoGrpRptList){
						infoGrpRptIds.add(infoGrpRpt.getId().getRptId());
					}
				}
				HashSet set = new HashSet();
				set.addAll(infoGrpRptIds);
				infoGrpRptIds.clear();
				infoGrpRptIds.addAll(set);
				
				for (String g:infoGrpRptIds){
					log.debug("代理群組:"+g);
				}
			}
		} else {
			strQueryUserId = user.getUserId();
			log.debug("0:本人案件 strQueryUserId="+strQueryUserId);
		}
		
		final String realApprvUserId = strQueryUserId;
		
		
		// 取符合類別的報表的交集
		/*if (serviceType != null || rptFunc != null || serviceName != null) {
			infoGrpRptIds.retainAll(rptClassService.findRptIdsMatchedClass(serviceType, rptFunc, serviceName));
		} */
				
		// 查詢條件加上 必須在該使用者所有群組的所有報表之中
		// 不管rptId是否有值,仍須過濾infoGrpRptIds
		// infoGrpRptIdsStr =((RcmsUserDetails)
		// CapSecurityContext.getUser()).getInfoGrpRptIdsStr();
		// logger.debug("query with permission rptIds="+infoGrpRptIdsStr);
		// logger.debug("infoGrpRptIds cnt="+infoGrpRptIdsStr.split(",").length);

		logger.debug("time spent : infoGrpRpt's id array = " + (Calendar.getInstance().getTimeInMillis() - timeStart));
		timeStart = Calendar.getInstance().getTimeInMillis();

		if (!CapString.isEmpty(request.get("rptDateBegin"))) {
			rptDateBegin = request.get("rptDateBegin").replaceAll("-", "");
		}

		if (!CapString.isEmpty(request.get("rptDateEnd"))) {
			rptDateEnd = request.get("rptDateEnd").replaceAll("-", "");
		}
		if (!CapString.isEmpty(request.get("convertDateStart"))) {
			convertDateStart = request.get("convertDateStart").replaceAll("-", "");
		}

		if (!CapString.isEmpty(request.get("convertDateEnd"))) {
			convertDateEnd = request.get("convertDateEnd").replaceAll("-", "");
		}
		
		if (strQueryUserId.equals("")){
			new GridResult();
		}
		
		//1.先找出該報表目前(待簽)的簽核層級
		
		//分頁查詢
		Page<VwRptContentApprvUserPDData> page = rptContentApprvUserService.getBySqlCondition(search, rptId,
						infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint,pd, rptDateBegin, rptDateEnd,strQueryUserId,"N",
						strApprvUserDept, oldBranchIds, convertDateStart,convertDateEnd);
		

		// 將報表週期改成中文
		for (VwRptContentApprvUserPDData rdm : page.getContent()) {
			String cycleValues = cfgCodeTypeRcmsService.getByValue("rptCycle",rdm.getRptCycle()).getCodeDesc();
			rdm.setRptCycle(cycleValues);

		}

		GridResult result = new GridResult(page.getContent(),page.getTotalRow());

		logger.debug("time spent : query = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
		timeStart = Calendar.getInstance().getTimeInMillis();

		/*
		 * 從session取得所有RDM final Map<String, RptDefineMaster> rdmMap
		 * =((RcmsUserDetails) CapSecurityContext.getUser()).getRdmMap();
		 * logger.
		 * debug("time spent : rdmMap = "+(Calendar.getInstance().getTimeInMillis
		 * ()-timeStart)); timeStart = Calendar.getInstance().getTimeInMillis();
		 */

		// 從查詢result 取得本批筆數對映的RDM
		List<VwRptContentApprvUserPDData> vwRptIndexDataList = page.getContent();

		if (!vwRptIndexDataList.isEmpty()) {
			List<String> queryRptIds = new ArrayList<String>();
			for (VwRptContentApprvUserPDData vwData : vwRptIndexDataList) {
				queryRptIds.add(vwData.getRptContentMasterPK().getRptId());
			}
			
			//for個資  有版本
			List<VwRptDefineMaster> vwRdmList = vwRptDefineMasterService.getVwRptDefineMasterByRptids(queryRptIds);
			final Map<String, VwRptDefineMaster> vwRdmMap = new ConcurrentHashMap<String, VwRptDefineMaster>();
			for (VwRptDefineMaster rdm : vwRdmList) {
				vwRdmMap.put(rdm.getRptDefineMasterPK().getRptId() + "-"
						+ rdm.getRptDefineMasterPK().getRptVersion(), rdm);
			}
			
			//for其他RDM 欄位  取最新版
			List<RptDefineMaster> rdmList = rptDefineMasterService.getByRptIdList(queryRptIds);
			final Map<String, RptDefineMaster> rdmMap = new ConcurrentHashMap<String, RptDefineMaster>();
			for (RptDefineMaster rdm : rdmList) {
				rdmMap.put(rdm.getRptDefineMasterPK().getRptId(), rdm);
			}

			// FMT : codeType 業管單位
			result.addReformatData("rptMaterDept", new IBeanFormatter() {
				private static final long serialVersionUID = 1L;

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					String govUnitId = rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId())
							.getGoverningUnit();
					if (govUnitId != null && govUnitId.length() > 3) {
						govUnitId = govUnitId.substring(0, 3);
					}
					return governmentUnitMap.get(govUnitId);
				}
			});

			logger.debug("time spent : codeType governUnit = " + (Calendar.getInstance().getTimeInMillis() - timeStart));
			timeStart = Calendar.getInstance().getTimeInMillis();

			// FMT : RDM 報表類型
			result.addReformatData("rptType", new IBeanFormatter() {

				private static final long serialVersionUID = 1L;

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId()).getRptType();
				}
			});
			
			//------------------------------------------
			// FMT : RDM 頁面大小
			result.addReformatData("rptPageSize", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId()).getPageSize();
				}
			});

			// FMT : RDM 頁面方向
			result.addReformatData("rptPageOrientation", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId())
							.getPageOrientation();
				}
			});

			// FMT : RDM 下載pdf
			result.addReformatData("dlPdf", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId()).getDlPdf();
				}
			});

			// FMT : RDM 下載txt
			result.addReformatData("dlTxt", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId()).getDlTxt();
				}
			});

			// FMT : RDM 浮水印
			result.addReformatData("waterMark", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId()).getWaterMark();
				}
			});

			//必簽
			result.addReformatData("rptApprove", new IBeanFormatter() {

				private static final long serialVersionUID = 1L;

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					String rptid=((VwRptContentApprvUserPDData) in).getRptContentMasterPK().getRptId();
					List<String> approve = ((RcmsUserDetails) CapSecurityContext.getUser()).getApproveRptIds();
					if(approve.contains(rptid))
					return "Y";
					else
					return "N";
				}
			});

			// FMT : RDM 列印
			result.addReformatData("print", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK().getRptId()).getPrint();
				}
			});

			// FMT : RDM 個資
			result.addReformatData("pd", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return vwRdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId()
									+ "-"
									+ ((VwRptContentApprvUserPDData) in)
											.getRptContentMasterPK()
											.getRptVersion()).getPd();
				}
			});

			// FMT : 收檔日期
			result.addReformatData("convertTimeStart", new IBeanFormatter() {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return sdf.format(ridv.getConvertTimeStart());
				}
			});
			
			result.addReformatData("convertTimeStartFull", new IBeanFormatter() {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return sdf.format(ridv.getConvertTimeStart());
				}
			});
			
			// FMT : RCM轉檔日期
			result.addReformatData("rptReceiveDate", new IBeanFormatter() {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					
					return sdf.format(ridv.getConvertTimeStart());
				}
			});
			
			//RptDefineMaster rdm = rptDefineMasterService.getRptDefineMasterByRptId(rptId);
			
			
			// FMT : 字型大小
			result.addReformatData("fontSize", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return String.valueOf(ridv.getFontSize());
				}
			});
			
			// FMT : RDM 頁面大小
			result.addReformatData("rptPageSize", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return ridv.getPageSize();
				}
			});
			
			// FMT : RDM 頁面方向
			result.addReformatData("rptPageOrientation", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return ridv.getPageOrientation();
				}
			});
			
			// FMT : RDM 邊距left
			result.addReformatData("marginLeft", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return String.valueOf(ridv.getPageMarginLeft());
				}
			});

			// FMT : RDM 邊距Top
			result.addReformatData("marginTop", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return String.valueOf(ridv.getPageMarginTop());
				}
			});
						
			// FMT : RCM轉檔時間
			result.addReformatData("rptReceiveTime", new IBeanFormatter() {

				SimpleDateFormat sdf = new SimpleDateFormat("HHmmss");

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return sdf.format(ridv.getConvertTimeStart());
				}
			});
			
			// FMT : 預設經辦
			result.addReformatData("setUserId", new IBeanFormatter() {
				private static final long serialVersionUID = 1L;

				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData rcam = (VwRptContentApprvUserPDData) in;
					String setUserId = rcam.getSetUserId();
					log.debug("setUserId="+setUserId);
					String setUserName = "";
					if (setUserId != null){
						setUserName = setUserId + "-" + aclUserService.getAclUserByUserId(setUserId).getEmpName();
						log.debug("setUserName="+setUserName);
					} 
					return setUserName;
				}
			});
			
			// FMT :PK
			result.addReformatData("id", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return ((VwRptContentApprvUserPDData) in).getId().toString();
				}
			});
			
			//逾期天數 overdueDays= 收檔日期 + 簽期期限(天數)  => 算出日期後 再扣掉 今天日期  的差距天數
			result.addReformatData("overdueDays", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					SimpleDateFormat sdf = new SimpleDateFormat("yyyMMdd");
					//String today = sdf.format(new Date());
					//CapDate.c
					log.debug("報表代號="+ridv.getRptContentMasterPK().getRptId()+",簽核期限"+ridv.getApprvDays());
					
					//逾期天數 : 收檔日期 + 簽期期限(天數)  => 算出日期後 再扣掉 今天日期  的差距天數
					if (ridv.getApprvStatus()!=null && ridv.getApprvStatus().equals("6"))
						return "0";
					else {
						if (ridv.getOverdueDays() < 0) 
							return "0";
						else
							return ridv.getOverdueDays()+"";
					}
				}
			});

			logger.debug("time spent : FMT RDM = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
			
			
			//簽核狀態 0:未設定  1:簽核中 3:簽核中(退回) 2:簽核中(作廢) 4:已作廢  5:已結案
			result.addReformatData("apprvStatusDesc", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					log.debug("apprvStatus====" + ridv.getApprvStatus());
					log.debug("apprvStatus desc ====" + apprvStatusMap.get(ridv.getApprvStatus()));
					return (apprvStatusMap.get(ridv.getApprvStatus()));
				}
			});
			
			//簽核狀態 0:未設定  1:簽核中 3:簽核中(退回) 2:簽核中(作廢) 4:已作廢  5:已結案
			result.addReformatData("apprvStatus", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return ridv.getApprvStatus();
				}
			});
			
			//for 代理人 apprvCaseType 0:本人 1:代理
			result.addReformatData("apprvCaseType", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return type;
				}
			});
			
			//for 代理人 apprvCaseType 0:本人 1:代理
			result.addReformatData("realApprvUserId", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return realApprvUserId;
				}
			});
			
			//loginUserId
			
			result.addReformatData("loginUserId", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					return loginUserId;
				}
			});
			
			//for 代理人 apprvCaseType 0:本人 1:代理
			result.addReformatData("apprvDepType", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					String apprvDepType = rdmMap.get(
							((VwRptContentApprvUserPDData) in).getRptContentMasterPK()
									.getRptId())
							.getApprvDepType();
					return apprvDepType;
				}
			});
			
			//for 代理人 apprvCaseType 0:本人 1:代理
			result.addReformatData("crossUnit", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return ridv.getCrossUnit();
				}
			});
			
			//for 代理人 apprvCaseType 0:本人 1:代理
			result.addReformatData("crossDept", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return ridv.getCrossDept();
				}
			});
			
			//for 代理人 apprvCaseType 0:本人 1:代理
			result.addReformatData("rptBranch", new IBeanFormatter() {
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData ridv = (VwRptContentApprvUserPDData) in;
					return ridv.getRptBranch();
				}
			});
			
			/*
			 * 顯示此份簽核報表的分行別名稱  (華銀表示 報表單位不會細到總行的科)
			 * rptBranchName
			 * ============================
			 * 因此若有重複單位 總行為科單位 不需考慮   例如 426-A / 426-B 則會選擇426-B(分行) 
			 */
			final Map<String, InfoDep> infoDepMap = infoDepService.getInfoDeps();
			result.addReformatData("rptBranchName", new IBeanFormatter() {
				private static final long serialVersionUID = 1L;
				@SuppressWarnings("unchecked")
				@Override
				public String reformat(Object in) {
					VwRptContentApprvUserPDData vwRptContentApprvUserPDData = (VwRptContentApprvUserPDData) in;
					
					InfoDep dep = null;
					if(infoDepMap.get(vwRptContentApprvUserPDData.getRptBranch() + "-A") != null && infoDepMap.get(vwRptContentApprvUserPDData.getRptBranch() + "-B")!=null) {
						//總行分行重複單位代號, 取分行
						dep = infoDepMap.get(vwRptContentApprvUserPDData.getRptBranch() + "-B");
					} else if (infoDepMap.get(vwRptContentApprvUserPDData.getRptBranch() + "-A") != null && infoDepMap.get(vwRptContentApprvUserPDData.getRptBranch() + "-B") == null) {
						//只存在總行單位代號, 取總行
						dep = infoDepMap.get(vwRptContentApprvUserPDData.getRptBranch() + "-A");
					} else if (infoDepMap.get(vwRptContentApprvUserPDData.getRptBranch() + "-A") == null && infoDepMap.get(vwRptContentApprvUserPDData.getRptBranch() + "-B") != null) {
						//只存在分行單位代號, 取分行
						dep = infoDepMap.get(vwRptContentApprvUserPDData.getRptBranch() + "-B");
					}
					
					if(dep != null) {
						return new StringBuffer(vwRptContentApprvUserPDData.getRptBranch()).append(dep.getDepName()).toString();
					}else {
						return new StringBuffer(vwRptContentApprvUserPDData.getRptBranch()).toString();
					}
				}
			});	
		}

		return result;
	}
	

	
	/**
	 * <pre>
	 * 依登入使用者的角色判斷是否為分行-經理R004,總行-經理R010,分行-人事管理員R009,總行-人事管理員R011
	 * </pre>
	 * @param loginUserRoles 登入使用者的角色
	 * @param apprvMgrRoles 可執行放行的角色 - 分行-經理R004,總行-經理R010,分行-人事管理員R009,總行-人事管理員R011 定義在CFG_SYSPARAM 裡的apprv.mgrRoles
	 * @return
	 */
	private boolean isApprvMgr(String loginUserRole,String[] apprvMgrRoles){
		boolean isMgr = false;
		//for (String s : loginUserRoles) {
		if (ArrayUtils.contains(apprvMgrRoles, loginUserRole)){
			isMgr = true;
			return isMgr;
		}
		//}
		
		return isMgr;
	}
	
	/**
	 * 獲取用戶下拉框數據
	 * 
	 * @param request
	 *            IRequest
	 * @return AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult getAclUserList(IRequest request) {
		// String userId = request.get("userId");
		RcmsUserDetails user = CapSecurityContext.getUser();

		List<String> noInclude = new ArrayList<String>();
		// <2013/10/31因應華南需求做修改，總務可自行授權自己查表權限。>
		/*
		 * noInclude.add(user.getUserId()); if (!CapString.isEmpty(userId)) {
		 * noInclude.add(userId); }
		 */
		List<AclUser> list = aclUserService.findAclUserByUnit(user.getUnitNo(), noInclude);
		// logger.debug("get acluser list cnt="+list.size());
		AjaxFormResult afr = new AjaxFormResult();
		for (AclUser obj : list) {
			String empName = "";
			if (obj.getEmpName() != null) {
				empName = obj.getEmpName();
			}
			afr.set(obj.getEmpId(), empName);
		}
		CfgSysParm parm = parmSrv.getSysParmById("auth.op");
		if (parm != null) {
			if (user.getUnitNo().startsWith(parm.getParamValue())) {
				parm = parmSrv.getSysParmById("auth.dept");
				if (parm != null) {
					for (String q : parm.getParamValue().split(",")) {
						list = aclUserService.findAclUserByUnit(q, noInclude);
						if (list != null && !list.isEmpty()) {
							for (AclUser obj : list) {
								afr.set(obj.getEmpId(), obj.getEmpName());
							}
						}
					}
				}
			}
		}

		return afr;
	}

	/**
	 * 是否有未覆核的單子
	 * 
	 * @param request
	 *            IRequest
	 * @return AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult isReCheck(IRequest request) {
		String userId = null;
		if (!CapString.isEmpty(request.get("userId"))) {
			userId = request.get("userId");
		}
		AjaxFormResult afr = new AjaxFormResult();
		List<InfoGrpUserDraft> list = infoGrpUserDraftService.findInfoGrpUserDraftByCondition(userId, "01", null);
		afr.set("isReCheck", (list != null && !list.isEmpty()) ? "1" : "0");
		return afr;
	}

	/**
	 * 獲取群組下拉框
	 * 
	 * @param request
	 *            IRequest
	 * @return AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult getInfoGrpList(IRequest request) {

		AjaxFormResult afr = new AjaxFormResult();
		AjaxFormResult pms = new AjaxFormResult();
		RcmsUserDetails user = CapSecurityContext.getUser();
		String userId = request.get("userId");
		logger.debug("getInfoGrpList userId="+userId);
		// 判斷是否分行/總行-使用單位代號第一碼0與1區分總行與分行,例外102 國際金融部係屬於總行單位,070是分行非總行
		List<Map<String, Object>> list = infoGrpService
				.findInfoGrpByIdType(!CapString.checkRegularMatch(user.getUnitNo(), "(^0)|(^102)")
						|| CapString.checkRegularMatch(user.getUnitNo(), "(^070)"), user.getUnitNo());

		CfgCodeTypeFormatter codeFmt = new CfgCodeTypeFormatter(cfgCodeTypeRcmsService, "permissionCategory");
		for (Map<String, Object> obj : list) {
			afr.set((String) obj.get("grpId"), (String) obj.get("grpName"));
			try {
				pms.set((String) obj.get("grpId"), codeFmt.reformat(obj.get("permission")));
			} catch (Exception e) {
				pms.set((String) obj.get("grpId"), "");
			}
		}
		List<InfoGrpUser> grpUser = infoGrpUserService.findInfoGrpUserByConditions(userId, null);
		for (InfoGrpUser grp : grpUser) {
			afr.removeField(grp.getInfoGrp().getGrpId());
		}
		if (!afr.isEmpty()) {
			List<InfoGrpUserDraft> grpUserDraft = infoGrpUserDraftService.findInfoGrpUserDraftByCondition(userId, null,
					null);
			for (InfoGrpUserDraft grp : grpUserDraft) {
				afr.removeField(grp.getInfoGrp().getGrpId());
			}
		}
		AjaxFormResult result = new AjaxFormResult();
		result.set("grpOps", afr);
		result.set("grpPms", pms);
		return result;
	}
	
	/**
	 * <pre>
	 * 依登入人員的單位代號查詢出該單位內所有人員及主管員編和姓名
	 * </pre>
	 * @param request
	 *            用戶端所發出的請求之物件
	 * @return afr
	 * 			AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult getAllUser(IRequest request) {
		AjaxFormResult afr = new AjaxFormResult();
		AjaxFormResult afrMgr = new AjaxFormResult();
		
		RcmsUserDetails user = CapSecurityContext.getUser();
		String strDivisionId = user.getUnitNo();
		
		//如果角色是總務,則代理人可以選取單位內的人員
		List<AclUser> list = aclUserService.getAclUserByCondition( null, null ,strDivisionId);
		
		for (AclUser obj : list) {
			afr.set((String) obj.get("empId"), (String) obj.get("empName"));
		}
		
		List<AclUser> listMgr = aclUserService.getAclUserMgrByCondition(strDivisionId);
		for (AclUser obj2 : listMgr) {
			afrMgr.set((String) obj2.get("empId"), (String) obj2.get("empName"));
		}
		
		AjaxFormResult result = new AjaxFormResult();
		
		result.set("empOps", afr);
		result.set("mgrOps", afrMgr);
		
		return result;
	}
	
	/**
	 * 獲取目前登入使用者(被代理人預設選取)
	 * 
	 * @param request
	 *            IRequest
	 * @return AjaxFormResult
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult getLoginUserId(IRequest request) {
		// String userId = request.get("userId");
		RcmsUserDetails user = CapSecurityContext.getUser();
		AjaxFormResult afr = new AjaxFormResult();
		log.debug("登入使用者員編="+user.getUserId());
		afr.set("loginUserId", user.getUserId());
		afr.set("loginUserUnitNo", user.getUnitNo());
		return afr;
	}
	
	
	/**
	 * <pre>
	 * 	整批簽核
	 * - 逐筆進行簽核,若下一關的簽核人員有異動單位,須Email通知經辦或單位總務,且沒有簽核成功的資料須顯示在UI 上
	 * - 若其它筆可正常簽核,則先commit 
	 * 
	 *   0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7.已退回  
	 * </pre>
	 * @param request
	 * @return
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult doBatchApprove(IRequest request) {
		
		AjaxFormResult afrBatch = new AjaxFormResult();
		
		String resultMsg  ="";
		
		String loginUserId = CapSecurityContext.getUserId();
		String loginUserName = CapSecurityContext.getUserName();
		String jsonData =request.get("selectdata");
		//jsonData=jsonData.substring(1, jsonData.length()-1);
		//jsonArray = new JSONObject(jsonData);
		JSONArray list= JSONArray.fromObject(jsonData);
		
		int n=list.size();
		Date sysDate = new Date();
		String apprvComment = "";
		for(int t=0;t<n;t++){
			JSONObject data = list.getJSONObject(t);
			//logger.info("jsonObj = "+data.toString());
			String id=data.getString("id");//RptContentApprvUser pk
			
			log.debug("doBatchApprove t="+t+"data:"+data.toString());
			
			//若為代理人進來做簽核,則以下值放被代理人員編
			String realApprvUserId = data.getString("realApprvUserId");
			log.debug("doBatchReject ="+t+"data: realApprvUserId:"+realApprvUserId);
			
			RptContentApprvUser rptContentApprvUser = rptContentApprvUserService.getByPk(Long.parseLong(id));
			//String masterId = data.getString("masterId");//RptContentApprv pk
			//RptContentApprv rptContentApprv = rptContentApprvService.getByPk(Long.parseLong(masterId));
			//TODO 待確認整批簽核的代理人簽核怎做?
			if (rptContentApprvUser != null){
				AjaxFormResult afrSingle = rptApprvService.updateRptToApprove(rptContentApprvUser,apprvComment, sysDate,loginUserId,loginUserName,realApprvUserId);
				//取回下一關有異動單位的人員資料
				if (afrSingle.get("result") != null && !afrSingle.get("result").equals("success")){
					log.debug("doBatchApprove result :"+afrSingle.get("result") );
					resultMsg = resultMsg + (String)afrSingle.get("resultMsg");
				}
			}
			
		}
		
		log.debug("doBatchApprove--------------------loginUserId="+loginUserId);
		
		
		if (resultMsg != null && resultMsg.length()>0){
			afrBatch.set("result", "error");
			afrBatch.set("resultMsg", resultMsg);
		} else {
			afrBatch.set("result", "success");
			afrBatch.set("resultMsg", resultMsg);
		}

		
		return afrBatch;
	}
	

	/**
	 * <pre>
	 * 	整批退回 - 退回一律退回到第1關的設定人員
	 * - 逐筆進行簽核,若第一關的簽核人員有異動單位,須Email通知經辦或單位總務,且沒有簽核成功的資料須顯示在UI 上
	 * - 若其它筆可正常簽核,則先commit 
	 * 
	 *   0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7.已退回  
	 * </pre>
	 * @param request
	 * @return
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult doBatchReject(IRequest request) {
		
		AjaxFormResult afrBatch = new AjaxFormResult();
		
		String resultMsg  ="";
		
		String loginUserId = CapSecurityContext.getUserId();
		String loginUserName = CapSecurityContext.getUserName();
		//RcmsUserDetails rcmsUserDetails = CapSecurityContext.getUser();
		String loginUserUnit = CapSecurityContext.getUnitNo();
		
		String jsonData =request.get("selectdata");
		
		//jsonData=jsonData.substring(1, jsonData.length()-1);
		//jsonArray = new JSONObject(jsonData);
		JSONArray list= JSONArray.fromObject(jsonData);
		int n=list.size();
		Date sysDate = new Date();
		String apprvComment = "";
		for(int t=0;t<n;t++){
			JSONObject data = list.getJSONObject(t);
			//logger.info("jsonObj = "+data.toString());
			String id=data.getString("id");//RptContentApprvUser pk
			
			log.debug("doBatchReject t="+t+"data:"+data.toString());
			
			//若為代理人進來做簽核,則以下值放被代理人員編
			String realApprvUserId = data.getString("realApprvUserId");
			log.debug("doBatchReject ="+t+"data: realApprvUserId:"+realApprvUserId);
			
			RptContentApprvUser rptContentApprvUser = rptContentApprvUserService.getByPk(Long.parseLong(id));
			//String masterId = data.getString("masterId");//RptContentApprv pk
			//RptContentApprv rptContentApprv = rptContentApprvService.getByPk(Long.parseLong(masterId));
			
			log.debug("doBatchReject rptContentApprvUser:"+rptContentApprvUser.toString());
			
			if (rptContentApprvUser != null){
				AjaxFormResult afrSingle = rptApprvService.updateRptToReject(rptContentApprvUser,apprvComment, sysDate,loginUserId,loginUserName,realApprvUserId,loginUserUnit);
				
				log.debug("doBatchReject result :"+afrSingle.get("result") );
				//取回第一關有異動單位的人員資料
				if (afrSingle.get("result") != null && !afrSingle.get("result").equals("success")){
					resultMsg = resultMsg + (String)afrSingle.get("resultMsg");
				}
			}
			
		}
		
		log.debug("doBatchReject--------------------loginUserId="+loginUserId);
		
		
		if (resultMsg != null && resultMsg.length()>0){
			afrBatch.set("result", "error");
			afrBatch.set("resultMsg", resultMsg);
		} else {
			afrBatch.set("result", "success");
			afrBatch.set("resultMsg", resultMsg);
		}

		return afrBatch;
	}
	
	/**
	 * 登入RCMS 後查詢登入人員的各類待簽核案件數目
	 * cnt1 : 待簽核報表件數 txn104051
	   cnt2 : 代理簽核報表件數 txn104051
	   cnt3 : 待改派(異動單位) txn104031
	   cnt4 : 代理人維護(待簽核) txn104071
	   cnt5 : 作廢重簽放行 txn104121
	   cnt6 : 待設定報表件數
				
	 * @param request
	 * @return
	 */
	@HandlerType(HandlerTypeEnum.FORM)
	public AjaxFormResult getApprvToDoCnt(IRequest request) {
		
		AjaxFormResult afr = new AjaxFormResult();
		String loginUserId = CapSecurityContext.getUserId();
		RcmsUserDetails user = CapSecurityContext.getUser();
		String unitNo = user.getUnitNo();
		String loginUserRoleId = user.getUser().getAclRole().getRoleID();
		
		log.debug("getApprvToDoCnt user:"+loginUserId+",unitNo:"+unitNo+",loginUserRoleId:"+loginUserRoleId);
		
		long timeStart = Calendar.getInstance().getTimeInMillis();
		
		int cnt1=0;
		int cnt2=0;
		int cnt3=0;
		int cnt4=0;
		int cnt5=0;
		//int cnt6=0;
		
		cnt1 = rptApprvService.getToApprvCnt("0",loginUserId);
		afr.set("cnt1", cnt1); //待簽核報表件數 本人案件
		logger.debug("getApprvToDoCnt time spent : cnt1 = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
		
		cnt2 = rptApprvService.getToApprvCnt("1",loginUserId);
		afr.set("cnt2",cnt2);  //待簽核報表件數 代理案件
		// logger.debug("getApprvToDoCnt time spent : cnt2 = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
		
		//cnt3 = rptApprvService.getToReAssignCnt(loginUserId);
		//afr.set("cnt3",cnt3);//OK
		//logger.debug("getApprvToDoCnt time spent : cnt3 = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
		
		//cnt4 = rptApprvService.getToApprvDeputyCnt(loginUserId);
		//afr.set("cnt4",cnt4);
		//logger.debug("getApprvToDoCnt time spent : cnt4 = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
		
		//if (user.getIsRoleMgr( )!= null && user.getIsRoleMgr().equals("Y")){
		//	cnt5 = rptApprvService.getToApprvInvalidCnt(unitNo);
		//	logger.debug("getApprvToDoCnt time spent : cnt5 = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
		//}
		//afr.set("cnt5", cnt5);
		
		//cnt6 = rptApprvService.getToSettingCnt(loginUserId);
		//logger.debug("getApprvToDoCnt time spent : cnt6 = "+ (Calendar.getInstance().getTimeInMillis() - timeStart));
		//afr.set("cnt6",cnt6);
		
		logger.debug("getApprvToDoCnt,empId="+loginUserId+",cnt1="+cnt1);
		
		
		return afr;
	}
	
}


