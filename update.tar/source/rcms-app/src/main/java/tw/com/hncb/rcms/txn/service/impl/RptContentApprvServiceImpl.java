/* 
 * RptContentApprvServiceImpl.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.txn.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iisigroup.cap.dao.utils.ISearch;
import com.iisigroup.cap.model.Page;
import com.iisigroup.cap.service.AbstractService;

import tw.com.hncb.rcms.dao.RptContentApprvDao;
import tw.com.hncb.rcms.dao.RptContentApprvUserDao;
import tw.com.hncb.rcms.model.RptContentApprv;
import tw.com.hncb.rcms.model.VwRptContentApprvPDData;
import tw.com.hncb.rcms.txn.service.RptContentApprvService;

/**
 * <pre>
 * 報表資料簽核檔(TABLE:RPT_CONTENT_APPRV)的服務介面
 * </pre>
 * 
 * @since 2017/3/13
 * @author jeanlin
 * @version <ul>
 *          <li>2017/3/13,jeanlin,new
 *          </ul>
 */
@Service
public class RptContentApprvServiceImpl extends AbstractService implements
RptContentApprvService {
	
	/** 存取報表資料簽核檔 Table[RPT_CONTENT_APPRV]的Dao */
	@Autowired
	RptContentApprvDao rptContentApprvDao;
	
	/** 存取報表簽核人員設定檔[Table:RPT_CONTENT_APPRV_USER]之Dao */
	@Autowired
	RptContentApprvUserDao rptContentApprvUserDao;
	
	/**
	 * 根據SQL的搜尋條件查詢VwRptIndexPDData
	 * 
	 * @param search
	 * 			ISearch
	 * @param rptId
	 * 			報表代號
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptName
	 * 			報表名稱
	 * @param rptSeqno
	 * 			報表序號
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @return List<VwRptIndexPDData>
	 */
	@Override
	public Page<VwRptContentApprvPDData> getBySqlCondition(
			ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch, List<String> apprvStatus) {
		return rptContentApprvDao.getBySqlCondition(search,
				rptId, infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint,
				pd, rptDateBegin, rptDateEnd, convertTimeStart, convertTimeEnd,setUserId,rptBranch, apprvStatus);
	}
	
	@Override
	public Page<VwRptContentApprvPDData> getBySqlConditionSetting(
			ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch, List<String> oldBranchIds, List<String> apprvStatus) {
		return rptContentApprvDao.getBySqlConditionSetting(search,
				rptId, infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint,
				pd, rptDateBegin, rptDateEnd, convertTimeStart, convertTimeEnd,setUserId,rptBranch, oldBranchIds, apprvStatus);
	}
	
	/**
	 * 報表改派查詢
	 * @param search
	 * @param rptId
	 * @param infoGrpRptIds
	 * @param rptName
	 * @param rptSeqno
	 * @param rptCycle
	 * @param mustPrint
	 * @param pd
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param convertTimeStart
	 * @param convertTimeEnd
	 * @param setUserId
	 * @param rptBranch
	 * @param apprvStatus
	 * @return
	 */
	@Override
	public Page<VwRptContentApprvPDData> getBySqlCondition2(
			ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch,List<String> apprvStatus) {
		return rptContentApprvDao.getBySqlCondition2(search,
				rptId, infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint,
				pd, rptDateBegin, rptDateEnd, convertTimeStart, convertTimeEnd,setUserId,rptBranch,apprvStatus);
	}
	
	/**
	 * 根據SQL的搜尋條件查詢VwRptIndexPDData
	 * 
	 * @param search
	 * 			ISearch
	 * @param rptId
	 * 			報表代號
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptName
	 * 			報表名稱
	 * @param rptSeqno
	 * 			報表序號
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @return List<VwRptIndexPDData>
	 */
	@Override
	public Page<VwRptContentApprvPDData> getByGoverningDept(
			ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch,List<String> apprvStatus,List<String> governingDept) {
		return rptContentApprvDao.getByGoverningDept(search,
				rptId, infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint,
				pd, rptDateBegin, rptDateEnd, convertTimeStart, convertTimeEnd,setUserId,rptBranch,apprvStatus,governingDept);
	}
	
	
	/**
	 * 
	 * 根據SQL的搜尋條件查詢RptContentApprv
	 * 
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @param sortColName
	 * 			列數名稱
	 * @param sortOrder
	 * 			排序
	 * @return List<VwRptIndexPDData>
	 */
	@Override
	public List<RptContentApprv> getBySqlCondition(
			List<String> infoGrpRptIds, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd,
			String sortColName, String sortOrder) {
		return rptContentApprvDao.getBySqlCondition(
				infoGrpRptIds, rptCycle, mustPrint, pd, rptDateBegin,
				rptDateEnd, sortColName, sortOrder);
	}
	
	@Override
	public List<RptContentApprv> getBySqlCondition(List<String> infoGrpRptIds, String rptBranch, List<String> apprvStatus) {
		return rptContentApprvDao.getBySqlCondition(infoGrpRptIds,  rptBranch,  apprvStatus);
	}
	
	@Override
	public RptContentApprv getByPk(Long pk){
		return rptContentApprvDao.find(pk);
	}
	
	@Override
	public RptContentApprv getOneBySqlCondition(String rptId,int rptSeqno,String rptDate, int rptVersion,String rptBranch,String convertTimeStart){
		return rptContentApprvDao.getOneBySqlCondition(rptId,rptSeqno,rptDate,rptVersion,rptBranch,convertTimeStart);
	}
	
	@Override
	public void update(RptContentApprv o){
		rptContentApprvDao.saveOrUpdate(o);
	}

	/**
	 * 依單位查詢作廢待簽核status=4的資料筆數
	 * @param unitNo
	 * @return
	 */
	@Override
	public int countInvalid(String unitNo){
		return rptContentApprvDao.countInvalid(unitNo);
	}
	
	/**
	 * 依單位查詢作廢待簽核status=4的資料筆數
	 * @param unitNo
	 * @return
	 */
	@Override
	public int countInvalidByUser(String empId){
		return rptContentApprvDao.countInvalidByUser(empId);
	}
	
	/**
	 * 跨單位簽核 - 找出設定的單位和跨單位的單位代號
	 * @return
	 */
	@Override
	public String getSetDivisionIdByCrossDept(String rptId,int rptSeqno,String rptDate,int rptVersion,String crossDept,String convertTimeStart){
		return rptContentApprvDao.getSetDivisionIdByCrossDept(rptId,rptSeqno,rptDate,rptVersion,crossDept,convertTimeStart);
	}
	
	/**
	 * 依員工編號查詢待設定(報表簽核流程設定,含非跨單位及跨單位)件數
	 * @param empId
	 * @return
	 */
	@Override 
	public int getToSettingCnt(String empId){
		return rptContentApprvDao.getToSettingCnt(empId);
	}
	

	/**
	 * 依員編查詢是否有任何簽核相關資料
	 * @param empId
	 * @return
	 */
	@Override 
	public int getExistApprvDataCnt(String empId){
		return rptContentApprvDao.getExistApprvDataCnt(empId);
	}

	/**
	 * 查詢簽核單狀態
	 * @param search ISearch
	 * @param rptId
	 * @param rptBranch
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param qryType
	 * @return
	 */
	@Override
	public Page<VwRptContentApprvPDData> getCaseListBySqlCondition(ISearch search, String rptId, String rptBranch, String rptDateBegin,
			String rptDateEnd, String qryType) {
		return rptContentApprvDao.getCaseListBySqlCondition(search, rptId, rptBranch, rptDateBegin, rptDateEnd, qryType);
	}
}
