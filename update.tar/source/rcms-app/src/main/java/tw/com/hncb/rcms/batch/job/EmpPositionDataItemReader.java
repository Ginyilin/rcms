/* 
 * EmpPositionDataItemReader.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.batch.job;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import tw.com.hncb.rcms.batch.core.BahRptConstants;
import tw.com.hncb.rcms.batch.utils.BatchFileUtil;
import tw.com.hncb.rcms.txn.service.CfgSysParmService;

/**<pre>
 * 讀取員工職稱代碼(EMP20170316.txt) 資料內容
 * 如:
 *  HB00081;退休總經理;A5;1;51;null;N;N;
	HB0001;老董;A@;1;51;null;N;N;
	HB0002;總經理;A5;1;51;;N;N;
	HB0012;吳秘書;D4;1;51;58111;N;N;zac.chen@hncb.com.tw
 * </pre>
 * @since  2017/4/13
 * @author jeanlin
 * @version <ul>
 *           <li>2017/4/13,jeanlin,new
 *          </ul>
 */
@Component
@Scope("step")
public class EmpPositionDataItemReader implements ItemReader<File>, InitializingBean {
	/** 存取系統參數table[CFG_SYSPARM]的Service */
	@Autowired
	private CfgSysParmService paramSrv;
	
	private final Logger logger = LoggerFactory.getLogger(EmpPositionDataItemReader.class);
	
	@Value("#{jobParameters['processDate']}")
	private String processDate;
	
	/**取得檔案路徑和檔案名稱， 讀取 CSV 資料內容*/
	@Override
	public File read() throws Exception {
		String empDataDir = paramSrv.getSysParmById(BahRptConstants.empPosDataDir).getParamValue();
		String empDataFile;
		if ((processDate == null) || "sysdate".equals(processDate)) {
			empDataFile = BatchFileUtil.getParamVal(paramSrv, BahRptConstants.empPosDataFile);
		} else {
			if (BatchFileUtil.isValidDate(processDate)) {
				empDataFile = BatchFileUtil.getParamVal(paramSrv, BahRptConstants.empPosDataFile, processDate);
			} else {
				throw new Exception("Invalid input parameter, processDate = " + processDate);
			}
		}
		
		File empDataCsvFile = new File(empDataDir + File.separator + empDataFile);
		if (empDataCsvFile.isFile() && empDataCsvFile.canRead()) {
			return empDataCsvFile;
		}else {
			logger.error("empDataCsvFile="+empDataCsvFile.getAbsolutePath()+", isExists="+empDataCsvFile.exists()+", canRead="+empDataCsvFile.canRead());
		}
		
		return null;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("afterPropertiesSet is called!");
	}
}