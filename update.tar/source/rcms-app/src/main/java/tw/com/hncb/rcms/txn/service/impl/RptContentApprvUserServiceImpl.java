/* 
 * RptContentApprvUserServiceImpl.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.txn.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iisigroup.cap.dao.utils.ISearch;
import com.iisigroup.cap.model.Page;
import com.iisigroup.cap.service.AbstractService;

import tw.com.hncb.rcms.dao.RptContentApprvUserDao;
import tw.com.hncb.rcms.model.RptContentApprvUser;
import tw.com.hncb.rcms.model.VwRptContentApprvUserPDData;
import tw.com.hncb.rcms.txn.service.RptContentApprvUserService;

/**
 * <pre>
 * 報表簽核人員設定(VIEW)的服務介面
 * </pre>
 * 
 * @since 2017/3/13
 * @author jeanlin
 * @version <ul>
 *          <li>2017/3/13,jeanlin,new
 *          </ul>
 */
@Service
public class RptContentApprvUserServiceImpl extends AbstractService implements
RptContentApprvUserService {
	
	@Autowired
	RptContentApprvUserDao rptContentApprvUserDao;
	
	/**新增一筆報表簽核人員設定檔*/
	@Override
	public void insert(RptContentApprvUser o){
		 rptContentApprvUserDao.save(o);
	}
	
	@Override
	public RptContentApprvUser getByPk(Long pk){
		return rptContentApprvUserDao.find(pk);
	}
	
	/**
	 * 根據SQL的搜尋條件查詢VwRptIndexPDData
	 * 
	 * @param search
	 * 			ISearch
	 * @param rptId
	 * 			報表代號
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptName
	 * 			報表名稱
	 * @param rptSeqno
	 * 			報表序號
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @return List<VwRptIndexPDData>
	 */
	@Override
	public Page<VwRptContentApprvUserPDData> getBySqlCondition(
			ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd,String apprvUserId,String isApprv,String rptBranch, List<String> oldBranchIds,String convertDateStart,String convertDateEnd) {
		return rptContentApprvUserDao.getBySqlCondition(search,
				rptId, infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint,
				pd, rptDateBegin, rptDateEnd,apprvUserId,isApprv,rptBranch, oldBranchIds, convertDateStart, convertDateEnd);
	}
	
	@Override
	public int countBySqlCondition(String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String rptDateBegin, String rptDateEnd,String apprvUserId,String isApprv,String rptBranch, List<String> oldBranchIds,String convertDateStart,String convertDateEnd) {
		return rptContentApprvUserDao.countBySqlCondition(rptId, infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint,
				rptDateBegin, rptDateEnd,apprvUserId,isApprv,rptBranch, oldBranchIds, convertDateStart, convertDateEnd);
	}
	
	@Override
	public Page<VwRptContentApprvUserPDData> getBySqlConditionAllApprvUser(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String apprvUserId,String isApprv,String empId) {
		return rptContentApprvUserDao.getBySqlConditionAllApprvUser(search,
				rptId, infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint,
				pd, rptDateBegin, rptDateEnd,apprvUserId,isApprv,empId);
		
	}
	
	@Override
	public Page<VwRptContentApprvUserPDData> getBySqlConditionAllApprvUserByUnitNo(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String apprvUserId,String isApprv, String unitNo) {
		return rptContentApprvUserDao.getBySqlConditionAllApprvUserByUnitNo(search,
				rptId, infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint,
				pd, rptDateBegin, rptDateEnd,apprvUserId,isApprv, unitNo);
		
	}
	
	@Override
	public List<VwRptContentApprvUserPDData> getAllBySqlCondition(
			ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd,String apprvUserId) {
		return rptContentApprvUserDao.getAllBySqlCondition(search,
				rptId, infoGrpRptIds, rptName, rptSeqno, rptCycle, mustPrint,
				pd, rptDateBegin, rptDateEnd,apprvUserId);
	}
	
	@Override
	public List<RptContentApprvUser> getBySqlCondition(String rptId,int rptSeqno,  String rptDate,int rptVersion,String rptBranch){
		return rptContentApprvUserDao.getBySqlCondition(rptId,rptSeqno,rptDate,rptVersion,rptBranch);
	}
	
	@Override
	public List<RptContentApprvUser> getToApprvUsers(String rptId,int rptSeqno,  String rptDate,int rptVersion,String rptBranch,String currentApprvStep){
		return rptContentApprvUserDao.getToApprvUsers(rptId,rptSeqno,rptDate,rptVersion,rptBranch,currentApprvStep);
	}
	
	/**
	 * 整批改派(依單位異動人員) - 查詢人員若為預設經辦或總務,查出單位有異動或離職日有值的人員資料
	 */
	@Override
	public	List<RptContentApprvUser> getToApprvUsersByUnit(String rptBranch,String empId){
		return rptContentApprvUserDao.getToApprvUsersByUnit(rptBranch,empId);
	}	
	
	@Override
	public RptContentApprvUser getOneBySqlCondition(String rptId,int rptSeqno,  String rptDate,int rptVersion,String branch,String apprvStep,String apprvUser){
		return rptContentApprvUserDao.getOneBySqlCondition(rptId,rptSeqno,rptDate,rptVersion,branch,apprvStep, apprvUser);
	}
	
	@Override
	public int updateBySqlCondition(String rptId,int rptSeqno,  String rptDate,int rptVersion,String branch,String apprvStep,String apprvUser){
		return rptContentApprvUserDao.updateBySqlCondition(rptId,rptSeqno,rptDate,rptVersion,branch,apprvStep, apprvUser);
		
	}
	@Override
	public int updateById(Long id ,String apprvStatus,Date updateTime,String updater,String isApprove,String apprvStep){
		return rptContentApprvUserDao.updateById(id,apprvStatus, updateTime, updater,isApprove,apprvStep);
	}
	
	@Override
	public int updateById(Long id ,String apprvStatus,Date updateTime,String updater,String isApprove){
		return rptContentApprvUserDao.updateById(id,apprvStatus, updateTime, updater,isApprove);
	}
	
	@Override
	public  List<RptContentApprvUser> getLastRptContentApprvUser(String rptId,String rptBranch, String userBranch){
		 return rptContentApprvUserDao.getLastRptContentApprvUser(rptId, rptBranch, userBranch);
	}
	
	@Override
	public List<RptContentApprvUser> getLastestByConvertTimeStart(String rptId, String rptVersion, int rptSeqno, String rptDate, 
			String rptBranch,String convertTimeStart){
		 return rptContentApprvUserDao.getLastestByConvertTimeStart( rptId,  rptVersion,  rptSeqno,  rptDate, 
					 rptBranch, convertTimeStart);
	}
	
	@Override
	public int countToApprvUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String currentApprvStep){
		return rptContentApprvUserDao.countToApprvUsers(  rptId, rptSeqno,   rptDate,  rptVersion, rptBranch, currentApprvStep);
	}
	
	@Override
	public int deleteUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String convertTimeStart,List<String> apprvUserIds){
		return rptContentApprvUserDao.deleteUsers(rptId, rptSeqno, rptDate, rptVersion, rptBranch, convertTimeStart, apprvUserIds);
	}
	
	@Override
	public int deleteUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String convertTimeStart){
		return rptContentApprvUserDao.deleteUsers(rptId, rptSeqno, rptDate, rptVersion, rptBranch, convertTimeStart);
	}
	
	
	@Override
	public String getMinApprvStep(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String convertTimeStart){
		return rptContentApprvUserDao.getMinApprvStep(rptId, rptSeqno, rptDate, rptVersion, rptBranch, convertTimeStart);
	}
	
	@Override
	public void update(RptContentApprvUser o){
		rptContentApprvUserDao.saveOrUpdate(o);
	}
	
	@Override
	public int countToApprvByUnitChange(String rptBranch){
		return rptContentApprvUserDao.countToApprvByUnitChange(rptBranch);
	}
	
	/**
	 * 依員編查詢待簽核筆數(含簽核中及退回)
	 * @param apprvUser
	 * @return 待簽核筆數(含簽核中及退回)
	 */
	@Override
	public int countToApprv(String apprvUser){
		return rptContentApprvUserDao.countToApprv(apprvUser);
	}
	
	/**
	 * 依員編查詢目前有代理的待簽核筆數(簽核狀態為2簽核中)
	 * @param apprvUser
	 * @return 代理的待簽核筆數
	 */
	@Override
	public int countToApprvDeputy(String apprvUser){
		return rptContentApprvUserDao.countToApprvDeputy(apprvUser);
	}
	
	/**
	 *  跨單位簽核 - 依第二段流程的經辦的部門depCode找出已設定的簽核人員資料
	 */
	@Override
	public List<RptContentApprvUser> getRptContentApprvUserCrossUnit(String rptId, String rptVersion, int rptSeqno, String rptDate, 
			String rptBranch, List<String> setDivisionIds,String convertTimeStart){
		 return rptContentApprvUserDao.getRptContentApprvUserCrossUnit( rptId,  rptVersion,  rptSeqno,  rptDate, 
				rptBranch, setDivisionIds, convertTimeStart);
	}
	
	/**
	 * 依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
	 * 更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId masterApprvStep
	 * 
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param masterId
	 * @param masterApprvStatus
	 * @param croddDept
	 * @param crossDeptSetUserId
	 * @param masterApprvStep
	 */
	@Override
	public void updateMasterColumnsByKey(String rptId, int rptVersion, String rptDate, int rptSeqno, String rptBranch,
			long masterId, String masterApprvStatus, String croddDept, String crossDeptSetUserId, String masterApprvStep) {
		rptContentApprvUserDao.updateMasterColumnsByKey(rptId, rptVersion, rptDate, rptSeqno, rptBranch, masterId, masterApprvStatus, croddDept, crossDeptSetUserId, masterApprvStep);
	}
	

}
