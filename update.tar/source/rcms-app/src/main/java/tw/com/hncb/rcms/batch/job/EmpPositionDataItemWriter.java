/* 
 * EmpPositionDataItemWriter.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.batch.job;

import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import tw.com.hncb.rcms.batch.core.BahRptConstants;
import tw.com.hncb.rcms.batch.persistence.Employee;
import tw.com.hncb.rcms.batch.service.BahAclUserService;
import tw.com.hncb.rcms.batch.utils.BatchFileUtil;
import tw.com.hncb.rcms.txn.service.CfgSysParmService;

import com.iisigroup.cap.utils.CapDate;

/**<pre>
 * 分析新人事系統 員工資料TXT檔(檔名:EMP20170316.txt) 並且 更新Table:ACL_USER的POSITIONID
 * </pre>
 * @since  2017/4/13
 * @author jeanlin
 * @version <ul>
 *           <li>2017/4/13,jeanlin,new
 *          </ul>
 */
@Component
@Scope("step")
public class EmpPositionDataItemWriter implements ItemWriter<File>, BahRptConstants {
	
	/** 存取系統參數table[CFG_SYSPARM]的Service */
	@Autowired
	private CfgSysParmService paramSrv;
	/** 員工角色資料整檔的Service */
	@Autowired
	private BahAclUserService aclUserService;
	
	private final Logger logger = LoggerFactory.getLogger(EmpPositionDataItemWriter.class);
	
	/**
	 * 取得分析完的CSV資料，將資料新增到DB。並建立備份資料
	 */
	@Override
	public void write(List<? extends File> items) throws Exception {
		for (File file : items) {
			try {
				logger.debug("CSV file path : " + file.getAbsolutePath());
				List<String> fileContent = FileUtils.readLines(file, "Big5");
				List<Employee> empInfoList = parseCsv(fileContent);
				if (!empInfoList.isEmpty()) {
					aclUserService.updatePositionId(empInfoList, getClass().getSimpleName());
				} else {
					logger.info("EMPYYYYMMDD.txt file is empty!");
				}
				
				String backupPath = paramSrv.getSysParmById(empPosDataBackupDir).getParamValue();
				File backupPathFile = new File(backupPath);
				if (!backupPathFile.exists()) {
					if (!backupPathFile.mkdirs()) {
						logger.warn("Can't create backup directory : " + backupPathFile.getAbsolutePath());
					}
				}
				BatchFileUtil.moveFileToDirectory(file.getAbsolutePath(), getBackupFilename(file.getName()), backupPath, true);
			} catch (Exception e) {
				String errorPath = paramSrv.getSysParmById(empPosDataErrorDir).getParamValue();
				File errPathFile = new File(errorPath);
				if (!errPathFile.exists()) {
					if (!errPathFile.mkdirs()) {
						logger.warn("Can't create error directory : " + errPathFile.getAbsolutePath());
					}
				}
				BatchFileUtil.moveFileToDirectory(file.getAbsolutePath(), getBackupFilename(file.getName()), errorPath, true);
				throw e;
			}
		}
	}
	/**取得備份的檔案名稱*/
	private String getBackupFilename(String filename) {
		Timestamp currentTime = CapDate.getCurrentTimestamp();
		String csvParseTime = timestampToStr(currentTime);
		
		return new StringBuffer(filename).append(".").append(csvParseTime).toString();
	}
	/**將時間轉為String*/
	private String timestampToStr(Timestamp ts) {
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");
		
		return 	df.format(ts);
	}
	
	/**
	 * 分析人員資料檔(EMPYYYYMMDD.txt)，儲存成List，
	 * 
	 * 序號	欄位名稱			中文解釋		資料型態			PK	備註				Sample Data
		1	EID				員工編號		varchar(20)		*					HB9999
		2	NAME			員工名稱		nvarchar(50)						黃曉華
		3	PositionId		職稱代碼		varchar(10)			
		4	GroupId			所屬群代碼		int									對照組織資料的DEP_NO	31
		5	DivisionId		部門代碼		int									對照組織資料的DEP_NO	58
		6	DepartmentId	科別代碼		int									對照組織資料的DEP_NO	58111
		7	LawManagerFlag	是否為法遵主管	nvarchar(1)							Y/N	Y
		8	EmpManager		是否為人事管理員	nvarchar(1)							Y/N	N
		9	Email			電子郵件		nvarchar(255)						xxx@hncb.com.tw


	 */
	private List<Employee> parseCsv(List<String> fileContent) throws Exception {
		List<Employee> empInfoList = new ArrayList<Employee>();

		for (int i = 0; i < fileContent.size(); i++) {
			String[] tokens = fileContent.get(i).split(";", -1);
			if (tokens.length > 3) {
				Employee empInfo = new Employee();
				
				empInfo.setEmpId(tokens[0].trim().toUpperCase());
				empInfo.setPositionId(tokens[2].trim());
				logger.error(empInfo.getEmpId().replace("HB", "")+":"+empInfo.getPositionId());
				/*
				empInfo.setDivisionId(tokens[2].trim());
				empInfo.setDeptId(tokens[3].trim());
				empInfo.setStatus(tokens[5].trim());
				empInfo.setPosition(tokens[16].trim());*/

				empInfoList.add(empInfo);					
			} else {
				logger.error("position data line format error: tokens length="+tokens.length+", error:"+fileContent.get(i));
				throw new Exception("檔案格式錯誤!");
			}
		}
		return empInfoList;
	}
}