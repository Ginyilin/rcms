/* 
 * RcmsLoginAuthenticationFilter.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.acl.login;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;

import tw.com.hncb.rcms.acl.core.RcmsUserDetails.UserFromEnum;

/**
 * <pre>
 * 登入設定
 * </pre>
 * 
 * @since 2013/3/25
 * @author iristu
 * @version <ul>
 *          <li>2013/3/25,iristu,new
 *          </ul>
 */
public class RcmsLoginAuthenticationFilter extends
		AbstractAuthenticationProcessingFilter implements InitializingBean {

	private String ssoverifyKey;

	public RcmsLoginAuthenticationFilter() {
		super("/loginCheck");
	}

	@Override
	public void afterPropertiesSet() {
		super.afterPropertiesSet();
	}

	/**
	 * 取得登入帳號、密碼以及登錄來源之資訊
	 * @param userDetails 登入使用者
	 * @param authentication
	 */
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request,
			HttpServletResponse response) {
	    	
	    	//session
	    	HttpSession session = request.getSession();
	    
		boolean fromRCMS = "Y".equals(request.getParameter("fromRCMS"));
		String verifyId, password;
		UserFromEnum from;
		if (fromRCMS) { // 從login畫面來的
			verifyId = request.getParameter("username").toUpperCase();			
			password = request.getParameter("password");
			from = UserFromEnum.AD;
			session.setAttribute("loginFrom", "AD");
		} else {
			verifyId = request.getParameter(ssoverifyKey);
			password = "";
			from = UserFromEnum.SSO;
			session.setAttribute("loginFrom", "SSO");
			logger.error("verify="+verifyId);
		}
		RcmsLoginAuthenticationToken authRequest = new RcmsLoginAuthenticationToken(
				verifyId, password, from);
		authRequest.setDetails(authenticationDetailsSource
				.buildDetails(request));
		return this.getAuthenticationManager().authenticate(authRequest);
	}// ;

	public void setSsoverifyKey(String ssoverifyKey) {
		this.ssoverifyKey = ssoverifyKey;
	}
	

}// ~
