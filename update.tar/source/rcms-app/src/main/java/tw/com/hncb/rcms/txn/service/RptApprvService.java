/* 
 * RptApprvService.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.txn.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.iisigroup.cap.response.AjaxFormResult;

import net.sf.json.JSONObject;
import tw.com.hncb.rcms.model.RptContentApprv;
import tw.com.hncb.rcms.model.RptContentApprvUser;


/**<pre>
 * 簽核作業相關Service
 * </pre>
 * @since  2017/3/31
 * @author jean
 * @version <ul>
 *           <li>2017/3/31,jean,new
 *          </ul>
 */
public interface RptApprvService {
	
	/**
	 * 查詢該報表下一個待簽的簽核層級
	 * @param RptContentApprv 簽核主檔資料
	 * @param convertTimeStart 收檔時間(起)
	 * @return 簽核層級(1...End)
	 */
	String getNextApprvStep(RptContentApprv main,String convertTimeStart);
	
	/**
	 * 修改簽核主檔資料
	 * @param loginUserId 登入人員員編
	 * @param setUserId 預設經辦員編
	 * @param apprvUser 簽核人員員編
	 * @param unitNo 登入人員的單位代號
	 * @param rptContentApprv 簽核主檔
	 * @param currentApprvStep 欲修改的簽核層級
	 * @param sysDate 系統日期
	 * @param apprvStatus 簽核狀態
	 */
	void updateRptContentApprv(String loginUserId,String setUserId,String apprvUser,String unitNo,RptContentApprv rptContentApprv,String currentApprvStep,Date sysDate,String apprvStatus);
	
	/**
	 * 依codetype=apprvStatus 查詢代碼檔CFG_CODETYPE  
	 * @param apprvStatus 簽核狀態代碼
	 * @return codedesc 簽核戕態中文
	 */
	String getApprvStatusDesc(String apprvStatus);
	
	/**
	 * <pre>
	 * 寫入或更新報表簽核人員設定檔
	 * 每一簽核層級有多少人(會簽) 則寫入幾筆
	 * </pre>
	 * @param rptContentApprv 簽核主檔
	 * @param loginUserId 登入人員員編
	 * @param sysDate 系統日期
	 * @param apprvUser 簽核人員
	 * @param apprvUserDepCode 簽核人員所屬單位
	 * @param apprvStep 簽核層級
	 * @param apprvType 簽核種類(目前沒用到)
	 * @param isApprv 是否已簽(Y/N)
	 * @param apprvStatus 0:未設定 , 1:已簽核  2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案
	 * @param setDivisionId 預設經辦(該報表的設定人員)所屬單位代號
	 * @return 修改過的 簽核人員設定資料 RptContentApprvUser
	 */
	RptContentApprvUser saveRptContentApprvUser(RptContentApprv rptContentApprv,String loginUserId,Date sysDate,
			String apprvUser,String apprvUserDepCode,String apprvStep,String apprvType,String isApprv,String apprvStatus,String setDivisionId);
	
	/**
	 * 修改單筆簽核人員設定資料
	 * @param rptContentApprvUser
	 * @return 修改過的 簽核人員設定資料 RptContentApprvUser
	 */
	RptContentApprvUser updateRptContentApprvUser(RptContentApprvUser rptContentApprvUser);

	
	/**
	 * <pre>
	 * 寫入一筆 報表簽核歷程紀錄
	 * </pre>
	 * @param rptContentApprv
	 * @param apprvUserId
	 * @param apprvUserName
	 * @param creatorId
	 * @param apprvStep
	 * @param apprvComment
	 * @param apprvTime
	 */		
	void deleteOrigialUnApprvedUsers(JSONObject originalApprvUserDataObj,RptContentApprv main,String convertTimeStart,String excludeIsApprv);
	
	/**
	 * 寫入一筆簽核歷程
	 * @param rptContentApprvUser
	 * @param rptSeqno
	 * @param rptVersion
	 * @param apprvComment
	 * @param loginUserId
	 * @param sysDate
	 */
	void saveRptContentApprvHistory(RptContentApprvUser rptContentApprvUser,int rptSeqno,int rptVersion,String apprvComment,
			String loginUserId,String loginUserName,Date sysDate,String apprvAction,String apprvStatus);
	
	/**
	 * 檢查下一簽核層級的人是否有單位異動或已退休或已離職  若有email給預設經辦和單位總務
	 * @param rptContentApprvUser 簽核人員資料
	 * @param loginUserId 登入人員員編
	 * @param sysDate 系統日期
	 * @param list 該報表所有簽核人員,依簽核層級排序
	 * @return AjaxFormResult
	 */
	AjaxFormResult doCheckNextApprvUser(RptContentApprvUser rptContentApprvUser,String loginUserId,Date sysDate,List<RptContentApprvUser>  list);
	
	/**
	 * 找出下一關簽核層級的人員
	 * @param currentApprvUser
	 * @return List of RptContentApprvUser
	 */
	List<RptContentApprvUser> getNextApprvUser(RptContentApprvUser currentApprvUser,List<RptContentApprvUser>  list);

	/**
	 *  
	 * <pre>
	 *   於待簽核報表按下[確認送出] - 單筆簽核
	 *   1.更新Table:RPT_CONTENT_APPRV_USER ,APPRVSTATUS= 2(apprvStatus:0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回 ), ISAPPRV=Y,updateTime= 系統時間
	 *   2.更新Table:RPT_CONTENT_APPRV - apprvStep,apprvStatus
	 *   3.依各簽核層級的設定人員寫入[RPT_CONTENT_APPRV_USER](若同一層級有2人,則會簽的註記apprvType=1,並寫入2筆)
	 * </pre>
	 * @param request
	 * @return AjaxFormResult
	 * @ref Txn103011Handler updateRptToApprove
	 */
	AjaxFormResult updateRptToApprove(String rptId,int rptVersion,String rptDate,int rptSeqno,String rptBranch,
			String apprvComment,String convertTimeStart,Date sysDate,String apprvUserId,String loginUserName,String realApprvUserId);
	
	/**
	 * 修改簽核人員設定資料的簽核狀態為已簽核
	 * @param rptContentApprvUser 簽核人員設定資料
	 * @param apprvComment 簽核意見
	 * @param sysDate 系統日期
	 * @param loginUserId 登入人員員編
	 * @param loginUserName 登入人員姓名
	 * @param realApprvUserId 實際簽核人員員編
	 * @return AjaxFormResult
	 */
	AjaxFormResult updateRptToApprove(RptContentApprvUser rptContentApprvUser,
			String apprvComment,Date sysDate,String loginUserId,String loginUserName,String realApprvUserId);
	
	/**
	 * 簽核退回 一律退回第1關的預設經辦
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param apprvComment
	 * @param convertTimeStart
	 * @param sysDate
	 * @param loginUserId
	 * @param loginUserName
	 * @param realApprvUserId
	 * @param realApprvUserUnit
	 * @return AjaxFormResult
	 */
	AjaxFormResult updateRptToReject(String rptId,int rptVersion,String rptDate,int rptSeqno,String rptBranch,
			String apprvComment,String convertTimeStart,Date sysDate,String loginUserId,String loginUserName,String realApprvUserId,String realApprvUserUnit);
	
	/**
	 * 檢查下一層級的人已調動單位或已退休(判斷acl_user的offdate有值) 
	 * 若是的設email給預設經辦和單位總務以進行改派
	 * @param currentRptContentApprvUser
	 * @param loginUserId 登入人員員編
	 * @param sysDate 系統時間
	 * @return AjaxFormResult("error") 異動人員員編
	 */
	AjaxFormResult doCheckSetApprvUser(RptContentApprvUser currentRptContentApprvUser,String loginUserId,Date sysDate);
	
	/**
	 * 單筆退回 - 一律退回第1關
	 * @param rptContentApprvUser
	 * @param apprvComment
	 * @param sysDate
	 * @return AjaxFormResult
	 */
	AjaxFormResult updateRptToReject(RptContentApprvUser rptContentApprvUser,
			String apprvComment,Date sysDate,String loginUserId,String loginUserName,String realApprvUserId,String realApprvUserUnit);
	
	
	/**
	 * 修改簽核主檔資料
	 * 取得下一簽核層級ApprvStep及更新ApprvStatus,以回寫主檔 RptContentApprv
	 * @param rptId 報表代號
	 * @param rptSeqno 報表序號
	 * @param rptDate 報表日期
	 * @param rptVersion 報表版本
	 * @param rptBranch 報表分行別
	 * @param thisApprvStep 目前流程已走到的簽核層級
	 * @param thisApprvUser 目前流程已走到的簽核人員
	 * @param convertTimeStartFull 收檔日期(起)
	 * @param loginUserId 登入人員員編
	 * @param sysDate 系統日期
	 * @return Map<String,String> key:nextApprvStep,nextApprvStatus
	 */
	Map<String,String> updateRptContentApprv(String rptId, int rptSeqno, String rptDate, int rptVersion,String rptBranch,
			String thisApprvStep,String thisApprvUser,String convertTimeStartFull,String loginUserId,Date sysDate);
	
	/**
	 * 報表簽核流程設定
	 * 或報表改派
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param strArrSelStartUserIds
	 * @param strArrSelEndUserIds
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 * @return AjaxFormResult
	 */
	AjaxFormResult updateRptSetting(String rptId,String rptVersion,String rptDate,String rptSeqno,String rptBranch,
			String[] strArrSelStartUserIds,String[] strArrSelEndUserIds,String strConvertTimeStartFull,String[] selDataArr,String strApprvComment,JSONObject apprvUserDataObj);
	
	/**
	 * 移管後的新單位設定(不設跨單位) 模擬status=0
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param strArrSelStartUserIds
	 * @param strArrSelEndUserIds
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 * @return AjaxFormResult
	 */
	AjaxFormResult updateRptSettingByBranchTransfer(String rptId,String rptVersion,String rptDate,String rptSeqno,String rptBranch,
			String[] strArrSelStartUserIds,String[] strArrSelEndUserIds,String strConvertTimeStartFull,String[] selDataArr,String strApprvComment,JSONObject apprvUserDataObj);
		
	/**
	 * 跨單位簽核 - 第一段的經辦進行設定
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param strArrSelStartUserIds
	 * @param strArrSelEndUserIds
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 * @return AjaxFormResult
	 */		
	AjaxFormResult updateForCrossUnit(RptContentApprv master,
			String[] strArrEndUserId,String strEndUserDepCode,String[] selDataArr,
			String strApprvComment);
	
	/**
	 * 跨單位簽核 - 第二段流程退回至第二單位的經辦後於[待簽核報表]功能重新設定後送出
	 * @param master
	 * @param strArrEndUserId
	 * @param strEndUserDepCode
	 * @param selDataArr
	 * @param strApprvComment
	 * @return AjaxFormResult
	 */
	AjaxFormResult updateForCrossUnit2(JSONObject apprvUserDataObj,RptContentApprv master,
			String[] strArrEndUserId,String strEndUserDepCode,String[] selDataArr,
			String strApprvComment);
	
	/**
	 * 跨單位簽核 - 第一段流程退回至第一個單位的經辦後於[待簽核報表]功能重新設定後送出
	 * @param master
	 * @param strArrEndUserId
	 * @param strEndUserDepCode
	 * @param selDataArr
	 * @param strApprvComment
	 * @return AjaxFormResult
	 */
	AjaxFormResult updateForCrossUnit1(JSONObject apprvUserDataObj,RptContentApprv master,
			String[] strArrEndUserId,String strEndUserDepCode,String[] selDataArr,
			String strApprvComment);
	
	/**
	 * 跨單位簽核人員設定 - 第一關的經辦設定寫入RPT_CONTENT_APPRV_USER
	 * @param rptId 報表代號
	 * @param rptVersion 報表版本
	 * @param rptDate 報表日期 
	 * @param rptSeqno 報表序號
	 * @param rptBranch 分行別
	 * @param strArrSelStartUserIds
	 * @param strEndUserId 第1段流程的最後一關(即第2個單位的預設經辦,由其設定第2段的簽核人員)員編
	 * @param strEndUserDepCode 第1段流程的最後一關(即第2個單位的預設經辦,由其設定第2段的簽核人員)單位代號
	 * @param strConvertTimeStartFull 收檔日期(起)
	 * @param selDataArr  第2關~ 決行前一關的簽核人員
	 * @param strApprvComment簽核意見
	 * @param apprvUserDataObj
	 * @return AjaxFormResult
	 */
	AjaxFormResult insertForCrossUnit(String rptId,String rptVersion,String rptDate,String rptSeqno,String rptBranch,
			String[] strArrSelStartUserIds,String strEndUserId,String strEndUserDepCode,String strConvertTimeStartFull,String[] selDataArr,
			String strApprvComment,JSONObject apprvUserDataObj);
	
	/**
	 * 移管後的新單位設定(設跨單位) 模擬status=0
	 * @param rptId 報表代號
	 * @param rptVersion 報表版本
	 * @param rptDate 報表日期 
	 * @param rptSeqno 報表序號
	 * @param rptBranch 分行別
	 * @param strArrSelStartUserIds
	 * @param strEndUserId
	 * @param strEndUserDepCode
	 * @param strConvertTimeStartFull
	 * @param selDataArr
	 * @param strApprvComment
	 * @param apprvUserDataObj
	 * @return AjaxFormResult
	 */
	AjaxFormResult insertForCrossUnitByBranchTransfer(String rptId,String rptVersion,String rptDate,String rptSeqno,String rptBranch,
			String[] strArrSelStartUserIds,String strEndUserId,String strEndUserDepCode,String strConvertTimeStartFull,String[] selDataArr,
			String strApprvComment,JSONObject apprvUserDataObj);
	
	
	/**
	 * 每頁簽核歷程資料筆數
	 * PageSize    PageOrientation
	 * ----------------------------------------------------------------------------
	 *  		    L                
		15x11       L      width: 335.1388mm;height: 282.2222mm;              
		A3          L      width: 420mm;     height: 297mm;           
		A4          L      width: 297mm;     height: 210mm;           
		B4          L      width: 353mm;     height: 250mm;             
		A3          P      width: 297mm;     height: 420mm;            
		A4          P      width: 210mm;     height: 297mm;  
		
		測試環境報表量: A3/L - 3634 A4/L:38, A4/P:44 B4/L:1 
	 */
	int getRptApprvHisPageRows(String pageSize,String pageOrientation);
	
	/**
	 * 查詢待簽核案件件數
	 * @param apprvCaseType 本人案件0或代理案件1
	 * @param loginUserId
	 * @return 待簽核案件件數
	 */
	int getToApprvCnt(String apprvCaseType,String loginUserId);
	
	/**
	 * 經辦已送出作廢待主管放行的筆數
	 * @return 經辦已送出作廢待主管放行的筆數
	 * @ref Txn104121Handler
	 */
	int getToApprvInvalidCnt(String unitNo);
	
	/**
	 * 經辦已送出作廢待主管放行的筆數
	 * @return 經辦已送出作廢待主管放行的筆數
	 * @ref Txn104121Handler
	 */
	int getToApprvInvalidCntByUser(String empId);
	
	
	/**
	 * 待改派(單位異動)報表件數
	 * from Txn104031
	 * @param empId 員編(報表的設定經辦或單位角色為總務R1031)
	 * @return 待改派(單位異動)報表件數
	 */
	int getToReAssignCnt(String empId);
   
	/**
	 * 代理人維護(待簽核) 件數
	 * 代理人維護(退回) 件數
	 * @return 代理人維護(待簽核/退回) 件數
	 */
	int getToApprvDeputyCnt(String loginUserId);
	
	/**
	 * 查詢待設定件數(含跨單位)
	 * @param empId
	 * @return 查詢待設定件數(含跨單位)
	 */
	int getToSettingCnt(String empId);
	
	/**
	 * 依員編查詢是否有任何簽核相關資料
	 * @param empId
	 * @return 依員編查詢是否有任何簽核相關資料件數
	 */
	int getExistApprvDataCnt(String empId);
	
    
}
