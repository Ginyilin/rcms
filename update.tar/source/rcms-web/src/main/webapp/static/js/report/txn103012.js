pageInit(function(){	 
	/*
	if(!deployJava.versionCheck("1.6+")){
		alert("未安裝JAVA Runtime Environment 1.6版本以上!");
		window.close();
	}
	*/
	
	//分段下載的pageData ex:1~10頁
	var pagesData={};
	
	//rcmsApplet = document.rcmsApplet;
	
	window.moveTo(0,0);
	window.resizeTo(window.screen.width	, window.screen.height-29);

	waterMarkWidth = screenWidth = $(document).width();
	waterMarkHeight = screenHeight = $(document).height();
	screenRatio = 1.00;
		
	//紀錄關鍵字查詢找到的頁數
	lastKeyword = "";
	alFindPage=0;
	alFindBranch="";
	
	//取得cookie - JSESSIONID
	JSESSIONID = "sessionNotFound";

	/*
	 * 定義viewer applet
	 * old: var rcmsApplet = document.rcmsApplet; 在txn103012.jsp重覆載入applet
	 * new: var rcmsApplet = window.opener.rcmsApplet; 取得custCommon.js已定義的rcmsApplet
	 */
	var rcmsApplet = window.opener.rcmsApplet;
	isLoadingApplet =true;
	
	//預設首分行的總頁數=1
	pageCnt=1;
	
	//預設簽核歷程(放在各分行資料的最後一頁)的頁數
	pageCntApprvHis = 1;
	
	//初始化分行下拉選單
	rptBranch = "0000";
	
	$(document).ready(function(){
		
		//簽核作業加入 ----------------------------start
		var eform = $("#eform");
		//用以存放登入人員所屬單位的人員清單
		var empData;
		//用以存放登入人員所屬單位的主管清單(決行的人員下拉選單)
		var mgrData;
		var apprvUserData;
		var apprvUserDataCnt;
		
		var existMaxStep = "";
		var apprvHisData;
		//放各簽核層級是否已簽Y/N
		var apprvUserIsApprv;		
		var apprvUser;
		
		//跨單位簽核 - 各層級的單位代號
		var crossUnit = "";  //Y/N 是否為跨單位簽核
		var crossDept = "";  //跨單位簽核第二段流程的簽核單位
		var crossDeptRptBranch = "";//跨單位簽核第一段流程的簽核單位
		var apprvUserDept = "";
		
		//用來判斷目前登入人員是否已簽過
		var flagIsApprv;
		//為了控制退回後預設經辦重覆按下[確認送出] 要disable 
		var flagApprvStatus;
		var myUserId;
		var selStartUserId  ;//= eform.find("#selUserId");//簽核層級=1
		var selEndUserId;// = eform.find("#selEndUserId");//簽核層級=End,決行-須判斷是否為主管
		var selTmpUserId;// = eform.find("#selUserIdTmp");//決行-須判斷是否為主管
		
		//跨單位簽核 - 用以存放第一段流程的單位的人員清單
		var empData1;
		//跨單位簽核 - 用以存放第二段流程的單位的人員清單
		var empData2;
		//跨單位簽核 放第一段流程的最後一關的簽核層級
		var lastStep=0;
		var apprvUserSetUnit;
		//for 跨單位簽核 退回  stage=1 表示第一段流程退回  stage=2 表示第二段流程退回
		var stage;//1 or 2
		var unitData;
		var endUserData;//放第一段流程的決行下拉人員
		var selEndUnitId;//放第一段流程的決行下拉人員
		var selEndUserId1;//放第一段流程的決行人員
		var selEndUserId2;
		var mycnt = 0;
		//簽核作業加入 ----------------------------end
	  
	  var execViewer = function(){
		 
		 //關閉右鍵選單
		 $(document).bind("contextmenu", function(e) {
			  e.preventDefault();
		 });
		 
		//防止選取
		 $(document).live('selectstart dragstart', function(evt){ 
				evt.preventDefault(); 
				return false; 
		 });
		 
		  
	  	$("#appletLoading").hide();
	  	
	  	//簽核作業
	  	$('#td_doApprv').hide();
	  
	  	var rowData = reqJSON;
		var targetPage=1;
		var bgImg;  //背景圖
		var imgWidth=0;
		var formfields; //本業套表所有欄位資料 , 需隨放大縮小重新繪製位置
		var defaultSize = 100;
		
		//最小安全邊界應為0.25英吋  換算成mm
		var safeMargin = 0.25 * 25.4;
	
		//左邊距不小於最小安全邊界
		if(rowData.marginLeft<safeMargin){
			rowData.marginLeft = safeMargin;
		}
		
		//上邊距不小於最小安全邊界
		if(rowData.marginTop<safeMargin){
			rowData.marginTop=safeMargin;
		}
		
		//mm換算成 96dpi的pixel值
		var viewerMarginLeft =rowData.marginLeft * (96/25.4);
		var viewerMarginTop =rowData.marginTop * (96/25.4);
			
		//修改viewer title
		document.title = "報表瀏覽 : "+ rowData.rptId+" - " + rowData.rptName;
		
		//初始化此份報表的所有分行(下拉選單) 與使用者Id
		$.ajax({
			async : false,
			url: '../../txn103011handler/getPageBranchesByCondition' ,
			data:{
	        	rptId : rowData.rptId,
	        	rptVersion : rowData.rptVersion,
	        	indexGrpId : '1', 
	        	rptDate : rowData.rptDate,
	        	rptSeqno : rowData.rptSeqno,
	        	pd : rowData.pd,
	        	rptApprove:rowData.rptApprove, //簽核作業加入[必簽]欄位
	        	crossUnit:rowData.crossUnit,
	        	crossDept:rowData.crossDept,
	        	crossDeptRptBranch:rowData.rptBranch //from txn104051.js
	        } , 
			dataType: "json",
			success: function(data){
				//get branch
				userId = data.userId;
				branchArr =data.rptBranchArr.split(',');
				JSESSIONID = data.jsessionid;
				
				for(var i=0 ; i< branchArr.length ; i++){
					if(i == 0){
						rptBranch = branchArr[i];
					}
					$("#branchSelect").append("<option value='"+branchArr[i]+"'>"+branchArr[i]+"</option>");
				}
				
				//分行下拉選單改變時的動作
				$("#branchSelect").change(function(){
					rptBranch = $("#branchSelect").find(":selected").text();
					
					if (rowData.rptApprove!=undefined && rowData.rptApprove == 'Y'){
						initApprvData();
					}
					
					//還原大小
					//$( "#rptZoomSlider" ).slider( "value" , 100) ;
					//$("#rptZoom").val(100 );
					
					//取得該分行總頁數
					$.ajax({
						url: '../../txn103011handler/getPageCntByCondition' ,
						data:{
				        	rptId : rowData.rptId,
				        	rptVersion : rowData.rptVersion,
				        	rptDate : rowData.rptDate,
				        	rptReceiveDate : rowData.rptReceiveDate,
				        	rptReceiveTime : rowData.rptReceiveTime,
				        	rptSeqno : rowData.rptSeqno,
				        	targetPage: targetPage,
				        	rptBranch : rptBranch,
				        	pd : rowData.pd,
				        	rptApprove:rowData.rptApprove //簽核作業加入 必簽欄位
				        } , 
						dataType: "json",
						success: function(data){
							pageCnt =data.pageCnt;
							//簽核作業修改 加入下行,若為必簽報表每個分行的頁數均固定加1,以放入簽核歷程
							pageCntApprvHis = data.pageCntApprvHis;
							//alert('pageCnt='+pageCnt+",pageCntApprvHis:"+pageCntApprvHis);
							$("#rptPageCnt").val(pageCnt + pageCntApprvHis);
							
						}
					});
					
					alFindPage=0;
					alFindBranch="";
					
					//從該分行第1頁 重繪報表
					 $("#rptPageNow").val("1");
					targetPage=1;
					renderRpt();
				});				
			}
		});
		
	   //簽核作業加入 start --------------------------------------------------------
		var apprvDiag = $("#apprvDiag");
		/*apprvDiag.dialog({ //查詢畫面		    	
	    	buttons:API.createJSON([{
	    		key:i18n.def.close,
	    		value:function(){
	    			apprvDiag.dialog('close');
	    		}
	    	}])
	    });*/
		//alert('rowData.rptApprove='+rowData.rptApprove);
		//必簽為Y才要顯示[簽核]按鈕及簽核歷程資料
		
		function initApprvData(){
			//簽核作業加入-  取得該報表該分行的簽核人員設定資料
			//取得登入人員所屬單位的人員清單
			getUserList();
			getMyUserId();
			
			$.ajax({
				url: '../../txn103011handler/getRptApprvUserAndHisData' ,
				data:{
		        	rptId : rowData.rptId,
		        	rptVersion : rowData.rptVersion,
		        	rptDate : rowData.rptDate,
		        	rptReceiveDate : rowData.rptReceiveDate,
		        	rptReceiveTime : rowData.rptReceiveTime,
		        	rptSeqno : rowData.rptSeqno,
		        	targetPage: targetPage,
		        	rptBranch : rptBranch,
		        	pd : rowData.pd,
		        	rptApprove:rowData.rptApprove, //簽核作業加入 必簽欄位Y/N
		        	convertTimeStartFull:rowData.convertTimeStartFull,
		        	realApprvUserId:rowData.realApprvUserId
		        } , 
				dataType: "json",
				success: function(data){
					apprvUserData = data.apprvUserData;//for 退回 appStep , empId-empName
					apprvUserDataCnt = 0;
				    $.each(apprvUserData,function(key,value){apprvUserDataCnt++;});
					apprvHisData = data.apprvHisData;  
					apprvUserIsApprv = data.apprvUserIsApprv
					apprvUser = data.apprvUser;//for 非退回
					//為了控制已按過[確認送出] / [退出] 後再進來此功能 再重覆按 須再查一次是否已簽過
					flagIsApprv = data.flagIsApprv;
					//為了控制退回後預設經辦重覆按下[確認送出] 要disable 
					flagApprvStatus = data.flagApprvStatus;
					//跨單位簽核加入各簽核層級的單位代號
					apprvUserDept = data.apprvUserDept;
					/*$.each( apprvUserDept, function( apprvStep, userDept ) {
				  		alert( apprvStep + ": " + userDept );
					});*/
					crossUnit = data.crossUnit;
					crossDept = data.crossDept;
					//跨單位簽核時 放第一個單位的員工下拉資料
					empData1 = data.empOps1;
					//跨單位簽核時 放第二個單位的員工下拉資料
					empData2 = data.empOps2;
					apprvUserSetUnit = data.apprvUserSetUnit;
					stage = data.stage;
					//簽核作業加入 -----------------------------------------------------end
				}
			});
		}
		
		  /**
		   * 案件退回到預設經辦由其修改簽核層級的人員後再送出
		   * 按下[確認送出]存檔
		   * 檢查:
		   * 1.第1關須包含本人
		   * 2.各層級人員不能重覆
		   * 3.簽核意見不能超過100個中文字(或200個英文字)
		   * 
		   * */
		  $('#btnSubmit').click(function () {
			  //取出第1關的設定值
			  var arrStartUserIds = $('#selStartUserId').find("option:selected").map(function() {
				    return this.value;
				}).get();
			  
			  if (arrStartUserIds.length == 0){
				  //API.showErrorMessage("請選取第1關的簽核人員");
				  $('#apprvMsg').val("請選取第1關的簽核人員");
				  $('#apprvMsgDiag').show();
			      return;
			  }
			  
			  var arrEndUserIds;
			  if (crossUnit == 'N'){
				  //取出最後1關(決行)的設定值
				arrEndUserIds = $('#selEndUserId').find("option:selected").map(function() {
					    return this.value;
				}).get();
			  } else {
				  //跨單位簽核 第一段流程退回至第1關的經辦時重新設定送出
				  if (flagApprvStatus =='3' && stage == '1'){
				   arrEndUserIds = $('#selEndUserId1').find("option:selected").map(function() {
					    return this.value;
					}).get();
				  }
				   //跨單位簽核 第一段流程退回至第1關的經辦時重新設定送出
				  else if (flagApprvStatus =='3' && stage == '2'){
				   arrEndUserIds = $('#selEndUserId').find("option:selected").map(function() {
					    return this.value;
					}).get();
				  }
			  }
			  
			  if (arrEndUserIds.length==0){
				  //API.showErrorMessage("請選取決行的簽核人員");
				  $('#apprvMsg').val("請選取決行的簽核人員");
				  $('#apprvMsgDiag').show();
			      return;
			  }
			  
			  //檢查各關卡的人員不能重覆
			  var allSelUserArr = [];
			 
			  //檢查第1關的人員必須含登入使用者
			  var valideStartStep = false;
			  for(var t=0;t<arrStartUserIds.length;t++){			  
				  if (arrStartUserIds[t] == myUserId){
					  valideStartStep = true;
					  break;
				  }
			  }
			  
			  for(var t=0;t<arrStartUserIds.length;t++){
				  allSelUserArr.push(arrStartUserIds[t]);
			  }
			  
			  for(var t=0;t<arrEndUserIds.length;t++){
				  allSelUserArr.push(arrEndUserIds[t]);
			  }
			  
			  if (crossUnit != 'Y'){
				  if (valideStartStep == false){
					  //API.showErrorMessage("簽核層級第1關須包含本人");
					  $('#apprvMsg').val("簽核層級第1關須包含本人");
					  $('#apprvMsgDiag').show();
					  return;
			      }
			  }
			   
			  //存放除了第1關及最後一關(決行)以外的被選取人員資料 
			  var selDataArr = [];
			  var k=2;
			  $('select[id*="selUserId"]').each(function(i) {
				 var str = $(this).attr('id').split('_');
				 var id = $(this).attr('id');
				 var empDataArr = $(this).find("option:selected").map(function() {
				    return this.value;
				 }).get();
					
				  
				 var step = str[str.length-1];
					
				  if (empDataArr == null){
					  //API.showErrorMessage("請選擇簽核層級人員");
					  $('#apprvMsg').val("請選擇簽核層級人員");
					  $('#apprvMsgDiag').show();
				      return;
				  }
				  
				  for(var t=0;t<empDataArr.length;t++){
					  allSelUserArr.push(empDataArr[t]);
				  }
				  selDataArr.push(k + '|' + empDataArr);
				  k++;
		      });
		    	
		      if ($('#apprvComment').val() != null && $('#apprvComment').val().length > 100){
		    	  //API.showErrorMessage("簽核意見不得超過100個中文字或200個英文字!");
		    	  //alert("簽核意見不得超過100個中文字或200個英文字!");
		    	  $('#apprvMsg').val("簽核意見不得超過100個中文字或200個英文字!");
				  $('#apprvMsgDiag').show();
		    	  return;
		      }
		    	 
	    	 var tmpArr = findDuplicates(allSelUserArr);
	    	 if (tmpArr != undefined && tmpArr.length>0){
	    		 var dupUserIds ='';
	    		 for (var t=0;t<tmpArr.length;t++){
	    			 dupUserIds = dupUserIds + " " + tmpArr[t];
		    	 }
	    		 //API.showErrorMessage("各簽核層級人員不能重覆選取!"+ dupUserIds +" 已重覆");
	    		 //alert("各簽核層級人員不能重覆選取!"+ dupUserIds +" 已重覆");
	    		 $('#apprvMsg').val("各簽核層級人員不能重覆選取!"+ dupUserIds +" 已重覆");
				 $('#apprvMsgDiag').show();
		    	 return;
	    	 }
		    
	    	 /*
	    	  * test reject resetting
	    	 
	    	 alert(JSON.stringify({
	            	rptId : rowData.rptId,
		        	rptVersion : rowData.rptVersion,
		        	rptDate : rowData.rptDate,			        	
		        	rptSeqno : rowData.rptSeqno,			        	
		        	rptBranch : rptBranch,
		        	rptApprove: rowData.rptApprove, //簽核作業加入 必簽欄位
		        	apprvComment:$('#apprvComment').val(),
	            	selDataArr:selDataArr,
	            	startUserId:arrStartUserIds,
	            	endUserId:arrEndUserIds,
	            	selEndUnitId:$('#selEndUnitId').val(),
	            	//id:$('#id').val(),	            	
	            	convertTimeStartFull:$('#convertTimeStartHidden').val(),
	            	apprvUserData:JSON.stringify(apprvUserData), //傳回原本的各簽核層級的設定值
	            	crossUnit:crossUnit,
	            	stage:stage
	            }));
	    	 return;
	    	  */
	    	 $.ajax({   
		            url:'../../txn103011handler/doRptApprvReSetting',
		            data:{
		            	rptId : rowData.rptId,
			        	rptVersion : rowData.rptVersion,
			        	rptDate : rowData.rptDate,			        	
			        	rptSeqno : rowData.rptSeqno,			        	
			        	rptBranch : rptBranch,
			        	rptApprove: rowData.rptApprove, //簽核作業加入 必簽欄位
			        	apprvComment:$('#apprvComment').val(),
		            	selDataArr:selDataArr,
		            	startUserId:arrStartUserIds,
		            	endUserId:arrEndUserIds,
		            	selEndUnitId:$('#selEndUnitId').val(),
		            	//id:$('#id').val(),	            	
		            	convertTimeStartFull:$('#convertTimeStartHidden').val(),
		            	apprvUserData:JSON.stringify(apprvUserData), //傳回原本的各簽核層級的設定值
		            	crossUnit:crossUnit,
		            	stage:stage
		            },
		            success:function(data){     
		            	if (data.result == 'success'){
			            	initApprvData();
			            	//API.showMessage("報表設定已完成!");
			            	$('#btnSubmit').attr("disabled",true);//[確認送出] 不能再按
			            	$('#btnReject').attr("disabled",true); //[退回] 也不能按
			            	$('#addRow').attr("disabled",true); //[新增簽核層級] 也不能按
			            	$('#btnRemove').attr("disabled",true); //[移除] 也不能按
			            	$('#td_doApprv').hide();
			            	execViewer();
			            	//alert("報表設定已完成!");
			            	$('#apprvMsg').val("報表設定已完成!");
							$('#apprvMsgDiag').show();
							$("#apprvDiag").dialog('close');
		            	} else {
		            		$('#apprvMsg').val(data.resultMsg);
							$('#apprvMsgDiag').show();
		            	}
						 
		   	    	    //return;
		            }
				});
				//eDialog.dialog('close');
				
		    });
		  
		  
		function findDuplicates(arr) {
			  var len=arr.length, out=[],counts={};
			  for (var i=0;i<len;i++) {
			    var item = arr[i];
			    	counts[item] = counts[item] >= 1 ? counts[item] + 1 : 1;
			    if (counts[item] === 2) {
			      out.push(item);
			    }
			  }
			  return out;
	     }
		
		/**
		 * 查詢
		 * 1.單位人員下拉選單
		 * 2.單位主管下拉選單
		 */
		function getUserList() {
			$.ajax({ 
				url : "../../txn103011handler/getAllUser",
				data : {},
				async: false,
				success : function(data) {
					empData = data.empOps;//empId,empName
					mgrData = data.mgrOps;//empId,empName
				}
			});
		}
		
		//取得登入者員編及所屬單位,第1關的人員於下拉選單預設選取為登入者
	    function getMyUserId(){
			
			$.ajax({ 
				url : "../../txn103011handler/getLoginUserId",
				data : {},
				async: false,
				success : function(data) {
					myUserId = data.loginUserId;
					myBranchId = data.loginUserUnitNo;
				}
			});
		}
		
		function mselect(select){
			select.multiselectfilter("destroy");
			select.multiselect2({
		    	selectedList: 4,
		    	multiple: false
		    }).multiselectfilter({
		    	label: "內含",
		    	placeholder: "輸入關鍵字" 
		    });
		}
		
		function mselectMultiple(select){
			select.multiselectfilter("destroy");
			select.multiselect2({
				selectedList: 4,
		    	multiple: true,
		    	searchable: true,		    	
		    	checkAllText : "全選",
		    	uncheckAllText : "取消全選"
		    }).multiselectfilter({
		    	label: "內含",
		    	placeholder: "輸入關鍵字" 
		    });
		}
		
		function ie6Exec(cmd){
			try {
				cmd();
			} catch(ex) {
			    setTimeout(function() {
			    	cmd();
			    },1);
			}
		}
		
		function sleep(milliseconds) {
			  var start = new Date().getTime();
			  for (var i = 0; i < 1e7; i++) {
			    if ((new Date().getTime() - start) > milliseconds){
			      break;
			    }
			  }
		}
		
		
		 //var i = 2;//預設UI上會帶出第1筆和決行,因此簽核層級由2開始編
		 
		 
		 var arrAdd=[];
		    
		 var t;
		
		 /**
	     * 按[新增簽核層級]
	     * 若不是由最後一筆(決行的前一筆)按移除則第1個欄位的序號須重編
	     */
	    $("#addRow").click(function(){
	    	
	    	var t = parseInt(lastStep)+1;
	    	
	    	if (crossUnit =='Y' && stage == '1'){
	         	$("#templateRow").clone().removeAttr("id").attr("id","tr_"+t).insertBefore('#last1');
	    	} else {
	    		$("#templateRow").clone().removeAttr("id").attr("id","tr_"+t).insertBefore('#last');
	    	}
	    	
	         $("#tr_"+t).find("#apprvStep").val(t);//須由現在最大值往下續編
	         $("#tr_"+t).find("#selTmpUserId").removeAttr("id").attr("id","selUserId_"+t);
	         $("#tr_"+t).find("#selUserId_"+t).setOptions({});	   //新增或修改
	         $("#tr_"+t).find("#selUserId_"+t).setOptions(empData);	   //新增或修改
	         mselectMultiple($("#tr_"+t).find("#selUserId_"+t));
	         $("#tr_"+t).find("#selUserId_"+t).multiselect2("uncheckAll");
	         $("#tr_"+t).show();
	         
	         
	         //於array 放入目前已加入的簽核層級
	         arrAdd.push(t);
	         
	         $("#tr_"+t).find("#btnRemove").click(function(){
			     $(this).parent().parent().remove();
			     resetApprvStep();
			  });
	         
	         //t++;	
	         mycnt++;
	         resetApprvStep();
	         
	     });
	    
	    
	    
  //跨單位簽核-第一段流程的決行依選取的單位找出單位內人員清單
		$('#selEndUnitId').change(function(){
			//alert('selEndUnitId.val()='+selEndUnitId.val());
			//getInitGridUsrGrp = true;
			if (selEndUnitId.val()==''){
				ie6Exec(function(){
					selEndUserId1.setOptions({});
				});
				
				mselect(selEndUserId1);
				//grid.clearGridData();
			}else{
				//getInfoGrpList();
				$.ajax({ 
					url : "../../txn104011handler/getUserListByUnit",
					data : {depCode : selEndUnitId.val()},
					success : function(data) {
						//$.each(data.empOps,function(key,value){alert(key);});
						ie6Exec(function(){
							selEndUserId1.setOptions(data.empOps);
						});
						//mselect(selCopyUserId);
						mselect(selEndUserId1);
					}
				});
				//grid.jqGrid('setGridParam',{postData: {userId:q_selUserId.val()}});
	            //grid.trigger("reloadGrid",[{page:1}]);
			}
		});
	   
	    
	/**
	 * 跨單位簽核 - 第一段流程的決行找出所有單位
	 * 查詢
	 * 1.單位下拉選單
	 * 
	 */
	function getUnitList() {
		$.ajax({ 
			url : "../../txn104011handler/getAllUnit",
			data : {},
			async: false,
			success : function(data) {
				//$.each(empData,function(key,value){alert('empId:'+key+",empName="+value)});
				unitData = data.unitOps;//empId,empName
			}
		});
	}
		    
	  //重編簽核層級..2,3..
	  function resetApprvStep() {
		lastStep = 0;		  
		$('span[id="apprvStep"]').each(function(i) {
			$(this).val(i + 1);				
			lastStep = $(this).val();
			$('#lbSelEndUnit').val(parseInt(lastStep)+1);
	    });
	  }
	    
	  function remove(arr, item) {
		  for(var i = arr.length; i--;) {
			  if(arr[i] === item) {
				  arr.splice(i, 1);
	          }
	      }
	  }
		
		//若為必簽報表才會出現
		//TODO 若由報表查詢進來,簽核按鈕先控制不能按
		if (rowData.rptApprove != undefined && rowData.rptApprove == 'Y' && rowData.apprvCaseType != undefined){
		    //簽核對話視窗			
			initApprvData();
			//apprvDiag.show();
			//[簽核]按鈕
			$("#td_doApprv").show();
			$("#doApprv").show();
			//[簽核]按鈕按下
			$("#doApprv").click(function(){
				//apprvDiag.dialog({bottons:API.createJson([{key:i18n.def.close,value:function(){apprvDiag.dialog('close');}}])});
				apprvDiag.css("top", "125px");
				initApprvLevels(apprvUserData);
				apprvDiag.show();
				strConvertTimeStartFull = rowData.convertTimeStartFull;	
		    	$("#convertTimeStartHidden").val(strConvertTimeStartFull);
		    	
			});
			//關鍵字Dialog關閉
			$("#apprvDiagClose").click(function(){
				apprvDiag.hide();
			});
			
			//訊息視窗按下右上角打X關閉
			$("#apprvMsgDiagClose").click(function(){
				$('#apprvMsgDiag').hide();
			});
			
			//關鍵字Dialog關閉
			$("#btnApprvMsgDiagClose").click(function(){
				$('#apprvMsgDiag').hide();
			});
			
			//當按下簽核視窗下方的關閉按鈕時 
			$("#btnApprvDiagClose").click(function(){
				apprvDiag.hide();
				window.location.reload() ;
				window.opener.location.reload();
			});
			
			/**
			 *  初始化 簽核層級 第1關/決行的下拉單位內人員選單資料
			 */
			function initApprvLevels(apprvUsers){
				selStartUserId = eform.find("#selStartUserId");//簽核層級=1
				selEndUserId = eform.find("#selEndUserId");		//簽核層級=End,決行-須判斷是否為主管
				selTmpUserId = eform.find("#selTmpUserId");		//
				
			     //若此報表為跨單位簽核
		    	if (crossUnit == 'Y'){		    		
			    	selEndUnitId = eform.find("#selEndUnitId");	   
			    	selEndUserId1= eform.find("#selEndUserId1");
			    	selEndUserId2= eform.find("#selEndUserId2");	
			    	getUnitList();
		    	} 
				
				$('#rptId').val(rowData.rptId);
				$('#rptName').val(rowData.rptName);
						
				i = 1;
				//若apprvStatus 不是3.簽核中（退回）顯示各簽核層級設定資料
				if (rowData.apprvStatus != '3'){
					
					$("#btnApprove").attr("disabled",false);
					$("#btnApprove").show();
					$('#btnSubmit').hide();
					$("#div_setting").addClass("disabledbutton");
					$("#div_setting").hide();
					
					var data0;
					var data;
					var lastlevel;
					var isApprv;//各簽核層級是否要開放編輯,只有層級內有一人員未簽,則要開放編輯
				
					//顯示上方的簽核層級設定資料
					$.each(apprvUser, function( apprvStep, apprvUserId ) {
						//alert('apprvStep00=' + apprvStep+",apprvUserId=" + apprvUserId+",stage="+stage+",crossUnit="+crossUnit+",apprvUser len="+apprvUserDataCnt+",i="+i);
						
						 if (apprvStep == '1'){
							 eform.find("#startUserId").val(apprvUserId);
						 }
						 else if (apprvStep == 'End' || apprvStep == 'E1' || apprvStep == 'E2'){
							 eform.find("#endUserId").val(apprvUserId);
							 //if (apprvStep  == 'E1')
								 //eform.find("#lbEndUserId1").html("決行(1)");
							 resetApprvStep();
							 if (apprvStep  == 'E2')
								 eform.find("#lbEndUserId1").html("決行(2)");
						 } else {
							 //顯示第2關至決行前一關
							//mselectMultiple($("#selUserIdTmp"));
							 
							 if ((crossUnit!=null && crossUnit =='N') || (crossUnit =='Y' && i!=apprvUserDataCnt)){
						         $("#templateRowShow").clone().removeAttr("id").attr("id","tr_s_"+i).insertBefore('#lastShow');
						         $("#tr_s_"+i).find("#apprvStepShow").val(apprvStep);//須由現在最大值往下續編
						         $("#tr_s_"+i).find("#tmpUserIdShow").removeAttr("id").attr("id","showUserId_"+i);
						         $("#tr_s_"+i).find("#showUserId_"+i).val(apprvUserId);	   //新增或修改
							 }
					         
							 if (crossUnit =='Y' && i==apprvUserDataCnt){
								 var aa = parseInt(apprvStep)+1;
					         	 eform.find("#lbEndUserId1").html(i);
					         	 eform.find("#endUserId").val(apprvUserId);
							 }
					         
					         
					         $("#tr_s_"+i).show();
						 }
						  
						  i++;
						  //resetApprvStep();
					});
					
					//表示已簽過再重覆點進來報表檢視畫面
					if (flagIsApprv == 'Y'){
						$("#btnApprove").attr("disabled",true);
						$("#btnReject").attr("disabled",true);
					}
				
				} else {
					//退回後由經辦重設流程
					//stage=1 退回至第一個單位的經辦
					//stage=2 退回至第二個單位的經辦
					
					if (crossUnit == 'Y'){
						if (stage == '1'){
							$('#last1').show();
							$('#last2').hide();
							$('#last').hide();
							
							//簽核層級 決行(最後一關)
							ie6Exec(function(){
								selEndUnitId.setOptions({});
								selEndUnitId.setOptions(unitData);
							});
							
							mselect(selEndUnitId);
							selEndUnitId.multiselect2("uncheckAll");
							mselect(selEndUserId1);
							
							//帶出上次設定的跨單位
							$("#selEndUnitId").val(crossDept);
							$("#selEndUnitId").multiselect2("refresh");
							$("#selEndUnitId").change();
							
						} else {//stage=2
							//if (apprvStatus != '3'){
								$('#last2').hide();
							//}
							$('#last1').hide();
							$('#last').show();
						}
					} else {//非跨單位簽核
						$('#last2').hide();
						$('#last1').hide();
						$('#last').show();
					}
					
					//todo 簽核退回到經辦可以修改人員再按下送出 ,待確認代理人?
					//若apprvStatus 是3.簽核中（退回）帶出各簽核層級設定資料供修改
					//ref 報表改派 txn104041.js
					//--------------------------------狀態為3.簽核中(退回)則由經辦 重新設定各簽核人員 --------------------------------------Start
					
					//退回案件 - [確認送出]按鈕
					//alert('flagApprvStatus='+flagApprvStatus);
					//0:未設定 , 1:已簽核   2:簽核中 3: 簽核中(已退回) 4: 簽核中(作廢), 5.已作廢  6.已結案  7 已退回  8.已退回(作廢)
					if (flagApprvStatus == '3'){
						$('#btnSubmit').attr("disabled",false);
						$('#btnSubmit').show();
					} else { 
						$('#btnSubmit').attr("disabled",true);
					}
					
					$('#btnReject').hide();
					$('#btnApprove').hide();
					
					$("#div_show").addClass("disabledbutton");
					$("#div_show").hide();
					
					ie6Exec(function(){
						$("#selStartUserId").setOptions({});
						//若為跨單位簽核則第1關一定為第1個單位
						if (crossUnit != undefined && crossUnit =='Y'){
							$("#selStartUserId").setOptions(empData1);
						} else {
							$("#selStartUserId").setOptions(empData);
						}
					});
					
					//簽核層級 決行(最後一關)
					ie6Exec(function(){
						$("#selEndUserId").setOptions({});
						$("#selEndUserId").setOptions(mgrData);
					});
					
					mselectMultiple($("#selStartUserId"));
					mselectMultiple($("#selEndUserId"));
					$("#selStartUserId").multiselect2("uncheckAll");
					$("#selEndUserId").multiselect2("uncheckAll");
					
					/*$('tr[id*="tr_"]').each(function(i) {
	    				$(this).remove()
	    		    });*/
					
					var data0;
					var data;
					var lastlevel;
					var isApprv;//各簽核層級是否要開放編輯,只有層級內有一人員未簽,則要開放編輯
					var thisStepSetUserDept;
					var thisStepUserDept;
					//顯示上方的簽核層級設定資料
					$.each(apprvUserData, function( apprvStep, apprvUserId ) {
						isApprv = apprvUserIsApprv[apprvStep];
						thisStepUserDept = apprvUserDept[apprvStep];
						thisStepSetUserDept = apprvUserSetUnit[apprvStep];
						data = apprvUserId.split(",");
						size = data.length;
						//第1關
						 if (apprvStep == '1'){
							 var isApprv1;
							 for(k=0; k < size; k++){
								 data0 = data[k].split("|")[0];//[0] 員編,[1] isApprv 該人員是否否已簽過
								 isApprv1 = data[k].split("|")[1];
					        	 
								 //alert("isApprv["+k+"]="+data[k].split("|")[1]);
								 $("#selStartUserId").multiselect2("widget").find(":checkbox[value='"+data0+"']").attr("checked","checked");
								 $("#selStartUserId option[value='" + data0 + "']").attr("selected", 1);
								//若該人員已簽核過,變成唯讀
								 if (isApprv1 != undefined && isApprv1 =='Y'){
									 $("#selStartUserId option[value='" + data0 + "']").attr("disabled", 'disabled');
								 }
								 $("#selStartUserId").multiselect2("refresh");
								 mselectMultiple($("#selStartUserId"));
								 //alert('isApprv='+isApprv);
								 
								  if (isApprv != undefined && isApprv =='Y'){
										$("#selStartUserId").multiselect2("disable");
								  }
							 }
						 }
						 //決行
						 else if (apprvStep == 'End' || apprvStep == apprvUserDataCnt){
							
							 var isApprvEnd;
							 for(j=0; j < size; j++){
								 //alert('apprvStep=End xx,data['+j+']=' + data[j]);
								 data0 = data[j].split("|")[0];
								 isApprvEnd = data[j].split("|")[1];
								 
								 if (crossUnit == 'Y' && stage == '1'){
									$("#selEndUserId1").val(data0);
						 			$("#selEndUserId1").multiselect2("refresh");
						 			$("#selEndUserId1").change();
								 } else {
									 $("#selEndUserId").multiselect2("widget").find(":checkbox[value='"+data0+"']").attr("checked","checked");
									 $("#selEndUserId option[value='" + data0 + "']").attr("selected", 1);
									 //若該人員已簽核過,變成唯讀
									 if (isApprvEnd != undefined && isApprvEnd =='Y'){
										 $("#selEndUserId option[value='" + data0 + "']").attr("disabled", 'disabled');
									 }
									 $("#selEndUserId").multiselect2("refresh");
									 mselectMultiple($("#selEndUserId"));
								 }
								 
								 $('#lbSelEndUnit').val(apprvUserDataCnt);
								/* if (isApprv != undefined && isApprv =='Y'){
									 $("#selEndUserId").multiselect2("disable");  有可能原本只選一個人,改派時要再加人
								 }*/
							 }
						 } else {//處理退回流程
							 	 //顯示第2關至決行前一關
							 	 if (crossUnit =='Y' && stage == '1'){
						         	$("#templateRow").clone().removeAttr("id").attr("id","tr_"+i).insertBefore('#last1');
							 	 } else {
							 		 $("#templateRow").clone().removeAttr("id").attr("id","tr_"+i).insertBefore('#last');
							 	 }
							 		 
						         $("#tr_"+i).find("#apprvStep").val(apprvStep);//須由現在最大值往下續編
						         $("#tr_"+i).find("#selTmpUserId").removeAttr("id").attr("id","selUserId_"+i);							         
						         
						         //alert('thisStepUserDept='+thisStepUserDept+",myBranchId="+myBranchId+",thisStepSetUserDept="+thisStepSetUserDept);
						         //跨單位簽核 若第二段被退回時(退至第二單位的經辦,則前面的關卡的單位為第一段流程的單位)
						         if (crossUnit =='Y' && thisStepUserDept != myBranchId){
							 		$("#selUserId_"+i).setOptions(empData1);
							 	 } else {
							 		$("#selUserId_"+i).setOptions(empData);
							 	}
						         
						         $("#tr_"+i).show();
						         
						         //顯示上次設定的2關~倒數第2關的設定值
						         var isApprv2 ;
						         for(t=0; t < size; t ++){
						        	 data0 = data[t].split("|")[0];
						        	 isApprv2 = data[t].split("|")[1];
						        	 $("#selUserId_"+i).multiselect2("widget").find(":checkbox[value='"+data0+"']").attr("checked","checked");
									 $("#selUserId_"+i+" option[value='" + data0 + "']").attr("selected", 1);
									 //若該人員已簽核過,下拉選項裡的值和[移除]按鈕變成唯讀
									 if (isApprv2 != undefined && isApprv2 =='Y'){
										 //簽核過 但已調單位 補上選項
										 if($("#selUserId_"+i+" option[value='" + data0 + "']").length == 0){
											 $("#selUserId_"+i).append($('<option>', {
												    value: data0,
												    text: data0+" - (調離)"
											 }));
											 $("#selUserId_"+i).multiselect2("widget").find(":checkbox[value='"+data0+"']").attr("checked","checked");
											 $("#selUserId_"+i+" option[value='" + data0 + "']").attr("selected", 1);
										 }
										 
										 $("#selUserId_"+i+" option[value='" + data0 + "']").attr("disabled", 'disabled');											 
										 $("#tr_"+i).find("#btnRemove").attr("disabled", 'disabled');
									 }
									 $("#selUserId_"+i).multiselect2("refresh");
									 mselectMultiple($("#selUserId_"+i));
									 
									 if (isApprv != undefined && isApprv =='Y'){
									 	$("#selUserId_"+i).multiselect2("disable");  //有可能原本只選一個人,改派時要再加人
								 	 }
									 
									 //當退回到第二單位的經辦則前面第一段的層級及目前第二單位經辦所在層級不能修改
									 if (crossUnit =='Y' && rptBranch == thisStepSetUserDept){
										 //TODO $("#selUserId_"+i).multiselect2("disable");
									 }
						         }
						         
						         $("#tr_"+i).find("#btnRemove").click(function(){
								     $(this).parent().parent().remove();
								     resetApprvStep();
								     i--;
								     
								  });
						         
						         mycnt = parseInt(i);
						         
						        
						 } //end if 
						  
						  i++;
					});
				} //end else
					
				//--------------------------------狀態為3.簽核中(退回)則由經辦 重新設定各簽核人員 --------------------------------------Start
				
				j=1;
				
				//顯示下方的簽核層歷程資料
				$.each(apprvHisData, function( apprvStep, apprvData ) {
					//alert('apprvHisData apprvStep='+apprvStep+",apprvData.apprvTime="+apprvData.apprvTime);
					 //data = apprvData.split(",");
					
						 //顯示第2關至決行前一關
						//mselectMultiple($("#selUserIdTmp"));
				         $("#templateRowHis").clone().removeAttr("id").attr("id","tr_his_"+j).insertBefore('#templateRowHis');
				         
				         //簽核層級 -須由現在最大值往下續編
				         $("#tr_his_"+j).find("#apprvStepHis").removeAttr("id").attr("id","apprvStepHis_"+i);
				         $("#tr_his_"+j).find("#apprvStepHis_"+i).val(apprvData.apprvStep);	  
				         
				         //簽核時間 
				         $("#tr_his_"+j).find("#apprvTimeHis").removeAttr("id").attr("id","apprvTimeHis_"+i);
				         $("#tr_his_"+j).find("#apprvTimeHis_"+i).val(apprvData.apprvTime);	  
				         
				         //簽核單位
				         $("#tr_his_"+j).find("#apprvUnitHis").removeAttr("id").attr("id","apprvUnitHis_"+i);
				         $("#tr_his_"+j).find("#apprvUnitHis_"+i).val(apprvData.rptBranch);	  
				         
				         //簽核人員
				         $("#tr_his_"+j).find("#apprvUserHis").removeAttr("id").attr("id","apprvUserHis_"+i);
				         $("#tr_his_"+j).find("#apprvUserHis_"+i).val(apprvData.apprvUser);	   
				         
				         //簽核狀態
				         $("#tr_his_"+j).find("#apprvStatusHis").removeAttr("id").attr("id","apprvStatusHis_"+i);
				         $("#tr_his_"+j).find("#apprvStatusHis_"+i).val(apprvData.apprvStatus);	  
				         
				         //簽核意見
				         $("#tr_his_"+j).find("#apprvCommentHis").removeAttr("id").attr("id","apprvCommentHis_"+i);
				         $("#tr_his_"+j).find("#apprvCommentHis_"+i).val(apprvData.apprvComment);	
					  j++;
				});
			}
			
			
			function reloadApprvHist(){
				j=1;
				
				//顯示下方的簽核層歷程資料
				$.each(apprvHisData, function( apprvStep, apprvData ) {
					//alert('apprvHisData apprvStep='+apprvStep+",apprvData.apprvTime="+apprvData.apprvTime);
					 //data = apprvData.split(",");
					
						 //顯示第2關至決行前一關
						//mselectMultiple($("#selUserIdTmp"));
				         $("#templateRowHis").clone().removeAttr("id").attr("id","tr_his_"+j).insertBefore('#templateRowHis');
				         
				         //簽核層級 -須由現在最大值往下續編
				         $("#tr_his_"+j).find("#apprvStepHis").removeAttr("id").attr("id","apprvStepHis_"+i);
				         $("#tr_his_"+j).find("#apprvStepHis_"+i).val(apprvData.apprvStep);	  
				         
				         //簽核時間 
				         $("#tr_his_"+j).find("#apprvTimeHis").removeAttr("id").attr("id","apprvTimeHis_"+i);
				         $("#tr_his_"+j).find("#apprvTimeHis_"+i).val(apprvData.apprvTime);	  
				         
				         //簽核單位
				         $("#tr_his_"+j).find("#apprvUnitHis").removeAttr("id").attr("id","apprvUnitHis_"+i);
				         $("#tr_his_"+j).find("#apprvUnitHis_"+i).val(apprvData.rptBranch);	  
				         
				         //簽核人員
				         $("#tr_his_"+j).find("#apprvUserHis").removeAttr("id").attr("id","apprvUserHis_"+i);
				         $("#tr_his_"+j).find("#apprvUserHis_"+i).val(apprvData.apprvUser);	   
				         
				         //簽核狀態
				         $("#tr_his_"+j).find("#apprvStatusHis").removeAttr("id").attr("id","apprvStatusHis_"+i);
				         $("#tr_his_"+j).find("#apprvStatusHis_"+i).val(apprvData.apprvStatus);	  
				         
				         //簽核意見
				         $("#tr_his_"+j).find("#apprvCommentHis").removeAttr("id").attr("id","apprvCommentHis_"+i);
				         $("#tr_his_"+j).find("#apprvCommentHis_"+i).val(apprvData.apprvComment);	
					  j++;
				});
			}
			
			//簽核 - 按下[確認送出]
		    $("#btnApprove").click(function(){
		    	if ($('#apprvComment').val() != null && $('#apprvComment').val().length > 100){
		    		API.showErrorMessage("簽核意見不得超過100個中文字或200個英文字!");
			    	return;
			    }
		    	
		    	$.ajax({   
		            url:'../../txn103011handler/updateRptToApprove',
		            data:{
			        	rptId : rowData.rptId,
			        	rptVersion : rowData.rptVersion,
			        	rptDate : rowData.rptDate,			        	
			        	rptSeqno : rowData.rptSeqno,			        	
			        	rptBranch : rptBranch,
			        	rptApprove: rowData.rptApprove, //簽核作業加入 必簽欄位
			        	apprvComment:$('#apprvComment').val(),
			        	convertTimeStartFull:rowData.convertTimeStartFull,
			        	apprvCaseType:rowData.apprvCaseType,
			        	realApprvUserId:rowData.realApprvUserId
			        },
		            success:function(data){     
		            	result = data.result;//empId,empName
						resultMsg = data.resultMsg;
						
						CommonAPI.triggerOpener('gridView','reloadGrid');
						
						if (result != "success"){
							//API.showErrorMessage(resultMsg);
							 $('#apprvMsg').val(resultMsg);
							 $('#apprvMsgDiag').show();
						}else {
							//API.showMessage("已簽核!");
							 $("#btnApprove").attr("disabled",true);
							 $("#btnReject").attr("disabled",true);
							 $("#addRow").attr("disabled",true);//[新增簽核層級] 也不能按
				             $('#btnRemove').attr("disabled","disabled"); //[移除] 也不能按
				             
				             initApprvData();
				             //initApprvLevels(apprvUserData);
				             reloadApprvHist();
							 $('#apprvMsg').val("已簽核!");
							 $('#apprvMsgDiag').show();
							 
							 apprvDiag.hide();
							 window.location.reload() ;
							 window.opener.location.reload();
							 
							 //grid.trigger("reloadGrid",[{page:1}]);
							 //location.reload(true);
				 
						}
		            }
				});
		    });
		    
		    //簽核 - 按下[退回]
		    $("#btnReject").click(function(){
		    	//alert('btnReject click');
		    	$.ajax({   
		            url:'../../txn103011handler/updateRptToReject',
		            data:{
			        	rptId : rowData.rptId,
			        	rptVersion : rowData.rptVersion,
			        	rptDate : rowData.rptDate,			        	
			        	rptSeqno : rowData.rptSeqno,			        	
			        	rptBranch : rptBranch,
			        	rptApprove: rowData.rptApprove, //簽核作業加入 必簽欄位
			        	apprvComment:$('#apprvComment').val(),
			        	convertTimeStartFull:rowData.convertTimeStartFull,
			        	apprvCaseType:rowData.apprvCaseType,
			        	realApprvUserId:rowData.realApprvUserId
			        },
		            success:function(data){     
		            	result = data.result;//empId,empName
						resultMsg = data.resultMsg;
						if (result != "success"){
							$('#apprvMsg').val(resultMsg);
						    $('#apprvMsgDiag').show();
						}else {
							$("#btnApprove").attr("disabled",true);
							$("#btnReject").attr("disabled",true);
							$("#addRow").attr("disabled",true);
							$('#apprvMsg').val("已退回!");
						    $('#apprvMsgDiag').show();
						}
		            }
				});
		    });
		
		} else {
			$("#doApprv").hide();
			apprvDiag.hide();
		}
		
		 //載入第一頁時 順便取得該分行總頁數
		$.ajax({
			url: '../../txn103011handler/getPageCntByCondition' ,
			data:{
	        	rptId : rowData.rptId,
	        	rptVersion : rowData.rptVersion,	        
	        	rptDate : rowData.rptDate,
	        	rptReceiveDate : rowData.rptReceiveDate,
	        	rptReceiveTime : rowData.rptReceiveTime,
	        	rptSeqno : rowData.rptSeqno,
	        	targetPage: targetPage,
	        	rptBranch : rptBranch,
	        	pd : rowData.pd,
	        	rptApprove : rowData.rptApprove
	        } , 
			dataType: "json",
			success: function(data){
				pageCnt =data.pageCnt;
				//alert('rowData.rptVersion='+rowData['rptContentMasterPK.rptVersion']);
				//alert('rowData.rptVersion='+rowData['rptContentMasterPK.rptVersion']);
				//alert('rowData.rptVersion='+rptId);
				//alert('pageCnt='+pageCnt+',rptId='+rptId+',rptVersion='+rptVersion+',rptDate='+rptDate+',rptReceiveDate='+rptReceiveDate+',rptReceiveTime='+rptReceiveTime+',rptSeqno='+rptSeqno+',targetPage='+targetPage+',rptBranch='+rptBranch);
				//alert('rptBranch='+rptBranch+',pd='+pd+',rptApprove='+rptApprove);
				//簽核作業修改 加入下行,若為必簽報表每個分行的頁數均固定加1,以放入簽核歷程
				pageCntApprvHis = data.pageCntApprvHis;
				$("#rptPageCnt").val(pageCnt+pageCntApprvHis);
			}
		});
		
		$( "#rptZoomSlider" ).slider(
				{
					max: 200,
				    value: defaultSize,
					change: function(event, ui) {
						//取得比例 (ex: 0.8 0.9 1.0 1.2...)
						var rptZoomRatio = $( "#rptZoomSlider" ).slider( "value" ) / 100;
						$("#rptZoom").val(rptZoomRatio * 100 );
						resizeRpt(rptZoomRatio);
						rptRatio = rptZoomRatio;
					}
				}		
		);
		
		$("#fontSize").keyup(function(){
			//alert(!isNaN($("#fontSize").val()) && $("#fontSize").val()>=8 && $("#fontSize").val()<=72);
			if(!isNaN($("#fontSize").val()) && $("#fontSize").val()>=8 && $("#fontSize").val()<=72){
				rowData.fontSize = $("#fontSize").val();
				
				$("#textArea").css("font-size", rowData.fontSize);
			}
		});
		
		
		$("#rptZoom").keyup(function(){
			//取得比例 (ex: 0.8 0.9 1.0 1.2...)
			var rptZoomRatio = $("#rptZoom").val() / 100;
			$( "#rptZoomSlider" ).slider( "value", $("#rptZoom").val() ) ;
			resizeRpt(rptZoomRatio);
			rptRatio = rptZoomRatio;
		});
		
		
		var resizeRpt=function(rptZoomRatio){
			$("#pageFrame").animate({ 'zoom': rptZoomRatio }, 10);
			$("#rptArea").animate({ 'zoom': rptZoomRatio  }, 10);
		};

		$("#rptZoom").val(defaultSize);
		
		/* 150dpi
		pageSize_P_A3={'width':1753 , 'height':2480 };
		pageSize_P_A4={'width': 1240, 'height': 1753};
		pageSize_P_A5={'width': 877, 'height':1240 };
		pageSize_P_B3={'width':2085 , 'height': 2953};
		pageSize_P_B4={'width': 1476, 'height': 2085};
		pageSize_P_B5={'width': 1029, 'height': 1476};
		pageSize_L_A3={'width':2480 ,'height': 1753};
		pageSize_L_A4={'width':1753 , 'height': 1240};
		pageSize_L_A5={'width': 1240, 'height':877 };
		pageSize_L_B3={'width':2953 , 'height': 2085};
		pageSize_L_B4={'width': 2085, 'height': 1476};
		pageSize_L_B5={'width': 1476, 'height': 1029 };
		*/
		//96dpi
		pageSize_P_A3={'width': 1123 , 'height': 1588};
		pageSize_P_A4={'width': 794, 'height': 1123};
		pageSize_P_A5={'width': 561 , 'height': 794};
		pageSize_P_B3={'width': 1334 , 'height': 1890};
		pageSize_P_B4={'width':945 , 'height': 1334 };
		pageSize_P_B5={'width':  665, 'height': 945};
		pageSize_L_A3={'width': 1588 ,'height':  1123};
		pageSize_L_A4={'width':1123 , 'height': 794};
		pageSize_L_A5={'width': 794 , 'height': 561 };
		pageSize_L_B3={'width': 1890 , 'height': 1334};
		pageSize_L_B4={'width':  1334, 'height':  945};
		pageSize_L_B5={'width': 945, 'height':  665 };
		
		/*
		 * 繪製報表
		 */
		rptRatio = 1.00;
		var renderRpt = function(){
			
			//紙張大小=報表定義的大小
			$('#pageFrame').addClass('pageSize-' + rowData.pageOrientation + '-' + rowData.pageSize);

			//定義form-report-viewer 畫布寬度 = 左邊距16 + 紙張pageFrame + 右邊距16 ,若仍小於螢幕寬 則等於螢幕寬  
			if(screenWidth>$('#pageFrame').width()+32){
				$("#form-report-viewer").css("width", screenWidth);
			}else{
				$("#form-report-viewer").css("width", $('#pageFrame').width()+32);
			}
			
			//定義form-report-viewer 畫布高度= 上邊距16 + 紙張pageFrame + 下邊距16 ,若仍小於螢幕高 則等於螢幕高  
			if(screenHeight > $('#pageFrame').height()+32 + $("#toolbar").height()*1.4){
				$("#form-report-viewer").css("height", screenHeight);
			}else{
				$("#form-report-viewer").css("height", $('#pageFrame').height()+32 + $("#toolbar").height()*1.4);
			}
			
			//定義套表內容距紙張的邊界
			$("#formImgArea").css("margin-left",viewerMarginLeft);
			$("#formImgArea").css("margin-top", viewerMarginTop);
			//定義套表內容距紙張的邊界
			$("#formArea").css("margin-left",viewerMarginLeft);
			$("#formArea").css("margin-top", viewerMarginTop);

			//浮水印大小 = 紙張大小 - 上下左右邊距
			$("#watermarkDiv").css("width", ($('#pageFrame').width()-viewerMarginLeft));
			$("#watermarkDiv").css("height", ($('#pageFrame').height()-viewerMarginTop));
			
			//定義紙張距螢幕的上邊界
			$("#pageFrame").css("margin-top",  $("#toolbar").height()*1.4 +16);
			$("#rptArea").css("margin-top",  $("#toolbar").height()*1.4+ 17);

			//定義白表內容距紙張的邊界
			$("#textArea").css("margin-left",viewerMarginLeft);
			$("#textArea").css("margin-top", viewerMarginTop);
			
			//定義浮水印距紙張的邊界
			$("#watermarkDiv").css("margin-left", viewerMarginLeft);
			$("#watermarkDiv").css("margin-top",viewerMarginTop);
			
	    	if(rowData.rptType=='B'){
	    		//白表
	    		
				/*disable fontSize調整
				$("#fontSizeDiv").show();
				*/
				$("#fontSizeDiv").hide();
				$("#fontSize").val(rowData.fontSize);
				var plains;
				if(pagesData[rptBranch+"_"+targetPage]==undefined ){
					//若分段下載cache中不存在此頁資料 
					//重新取得
					//簽核作業加入: 於每個分行的最後一頁加入簽核歷程
					$.ajax({
		    			async : false,
		    			url: '../../txn103011handler/getPlainRptDataPages' ,
		    			data:{
			            	rptId : rowData.rptId,
			            	rptVersion : rowData.rptVersion,
			            	rptDate : rowData.rptDate,
			            	rptReceiveDate : rowData.rptReceiveDate,
			            	rptReceiveTime : rowData.rptReceiveTime,
			            	rptSeqno : rowData.rptSeqno,
			            	targetPage: targetPage,
			            	rptBranch : rptBranch,
							pd : rowData.pd,
							rptApprove:rowData.rptApprove //簽核作業加入必簽欄位
			            } , 
		    			dataType: "json",
		    			success: function(data){
		    				pagesData = data.plainsPages;
		    			}
					});
					plains = pagesData[rptBranch+"_"+targetPage];
				}else{
					plains = pagesData[rptBranch+"_"+targetPage];
				}
				
				//alert('test='+pagesData[rptBranch+"_"+(targetPage+1)]);
	    		//貼上資料
				var plainRpt="";
				
				//若為必簽報表,各分行的最後一頁均放入簽核歷程
				//if (targetPage == (pageCnt+pageCntApprvHis) && (rowData.rptApprove!=undefined && rowData.rptApprove =='Y')){
					//plainRpt = plainRpt + plains;
				//} else {
					if (plains && plains.length != null){
						for(var i=0;i<plains.length;i++){
							plainRpt = plainRpt + plains[i]+" \n";
						}
					}
				//}
				
				
				$("#textArea").html("<plaintext id='plaintext' >"+plainRpt);
				$("#textArea").css("font-size", rowData.fontSize);
				$("#textArea").show();

				//貼上浮水印
				waterMarkWidth = Math.ceil($('#pageFrame').width()-viewerMarginLeft);
				waterMarkHeight = Math.ceil($('#pageFrame').height()-viewerMarginTop);
				if(rowData.waterMark == 'Y'){
					initWaterMark();
				}
	            
	    		/*
	    		$.ajax({
	    			async : true,
	    			url: '../../txn103011handler/getPlainRptData' ,
	    			data:{
		            	rptId : rowData.rptId,
		            	rptVersion : rowData.rptVersion,
		            	rptDate : rowData.rptDate,
		            	rptReceiveDate : rowData.rptReceiveDate,
		            	rptReceiveTime : rowData.rptReceiveTime,
		            	rptSeqno : rowData.rptSeqno,
		            	targetPage: targetPage,
		            	rptBranch : rptBranch,
						pd : rowData.pd
		            } , 
	    			dataType: "json",
	    			success: function(data){
	    				plains = data.plains;
						
						//貼上資料
	    				var plainRpt="";
	    				for(var i=0;i<plains.length;i++){
	    					plainRpt = plainRpt + plains[i]+"\n";
	    				}
	    				$("#textArea").html("<plaintext id='plaintext' >"+plainRpt);
						$("#textArea").css("font-size", rowData.fontSize);
						$("#textArea").show();

						//貼上浮水印
						waterMarkWidth = Math.ceil($('#pageFrame').width()-viewerMarginLeft);
						waterMarkHeight = Math.ceil($('#pageFrame').height()-viewerMarginTop);
						if(rowData.waterMark == 'Y'){
							initWaterMark();
						}
						
						

	    			}
	    		}); 
	    		*/
	    	}else if(rowData.rptType=='F'){
				$("#fontSizeDiv").hide();
				formfields=[];
				selFormPage = 0;
	    		//套表
				if(pagesData[rptBranch+"_"+targetPage+"_formfields"]==undefined ){
					//若分段下載cache中不存在此頁資料 
					//簽核作業加入: 於每個分行的最後一頁加入簽核歷程
					$.ajax({
						async:false,
			            url:'../../txn103011handler/getFormRptDataPages' ,
			            data:{
			            	rptId : rowData.rptId,
			            	rptVersion : rowData.rptVersion,
			            	rptDate : rowData.rptDate,
			            	rptReceiveDate : rowData.rptReceiveDate,
			            	rptReceiveTime :rowData.rptReceiveTime,
			            	rptSeqno : rowData.rptSeqno,
			            	targetPage: targetPage,
			            	rptBranch : rptBranch,
							pd : rowData.pd
			            } ,                            
			            dataType: "json",
			            success:function(data){  
			            	pagesData = data.formPages;
			            }
					});
					
					formfields = pagesData[rptBranch+"_"+targetPage+"_formfields"];
					selFormPage = pagesData[rptBranch+"_"+targetPage+"_selFormPage"];
				}else{
					//若分段下載cache中存在此頁資料 
					formfields = pagesData[rptBranch+"_"+targetPage+"_formfields"];
					selFormPage = pagesData[rptBranch+"_"+targetPage+"_selFormPage"];
				}
				
				//開始會製套表
				$("#formArea div").remove();
				
	        	var nocache = new Date();
				
				$("#formImgArea").show();
				$("#formArea").show();
				
				//背景圖片載入完成後才縮放
				if(selFormPage != undefined){
					
				}
	        	$('#formImgArea').html("<img id='formImg' src='../../fileDownloadhandler/formImageDownload?"+nocache.getTime()+"&rptId="+rowData.rptId+"&rptVersion="+rowData.rptVersion+"&item="+selFormPage+"' />");
				$("#formImg").bind('load', function() {	

						//原圖縮放成紙張所需的比例, 取比例小的為符合紙張pageFrame大小的比率
						var imgToPageFrameWidthRate = ($("#pageFrame").width()-viewerMarginLeft*2)/$("#formImg").width();
						var imgToPageFrameHeightRate = ($("#pageFrame").height()-viewerMarginTop*2)/$("#formImg").height();
						if(imgToPageFrameWidthRate < imgToPageFrameHeightRate){
							screenRatio = imgToPageFrameWidthRate;
						}else{
							screenRatio = imgToPageFrameHeightRate;
						}
						
						if(screenRatio > 1){
							screenRatio = 1;
						}
						$("#formImgArea").animate({ 'zoom':  screenRatio }, 10);
						$("#formArea").animate({ 'zoom':  screenRatio }, 10);

						//貼上浮水印
						waterMarkWidth = Math.ceil($('#pageFrame').width()-viewerMarginLeft);
						waterMarkHeight = Math.ceil($('#pageFrame').height()-viewerMarginTop);
						//alert('waterMarkWidth='+waterMarkWidth+", waterMarkHeight="+waterMarkHeight);
						if(rowData.waterMark == 'Y'){
							initWaterMark();
						}
			 	});

				//alert(formfields.length);
				//console.log(formfields[0].fieldData);
	        	for ( var i = 0; i < formfields.length; i++) {
	        		createFieldData(formfields[i], 1, null, 100/100 );
	        	}
				
				/*
	    		$.ajax({   
		            url:'../../txn103011handler/getFormRptData' ,
		            data:{
		            	rptId : rowData.rptId,
		            	rptVersion : rowData.rptVersion,
		            	rptDate : rowData.rptDate,
		            	rptReceiveDate : rowData.rptReceiveDate,
		            	rptReceiveTime :rowData.rptReceiveTime,
		            	rptSeqno : rowData.rptSeqno,
		            	targetPage: targetPage,
		            	rptBranch : rptBranch,
						pd : rowData.pd
		            } ,                            
		            dataType: "json",
		            success:function(data){  
						formfields = data.formfields;
			        	$("#formArea div").remove();
						
			        	var nocache = new Date();
						
						$("#formImgArea").show();
						$("#formArea").show();
						
						//背景圖片載入完成後才縮放
			        	$('#formImgArea').html("<img id='formImg' src='../../fileDownloadhandler/formImageDownload?"+nocache.getTime()+"&rptId="+rowData.rptId+"&rptVersion="+rowData.rptVersion+"&item="+data.selFormPage+"' />");
						$("#formImg").bind('load', function() {	

								//原圖縮放成紙張所需的比例, 取比例小的為符合紙張pageFrame大小的比率
								var imgToPageFrameWidthRate = ($("#pageFrame").width()-viewerMarginLeft*2)/$("#formImg").width();
								var imgToPageFrameHeightRate = ($("#pageFrame").height()-viewerMarginTop*2)/$("#formImg").height();
								if(imgToPageFrameWidthRate < imgToPageFrameHeightRate){
									screenRatio = imgToPageFrameWidthRate;
								}else{
									screenRatio = imgToPageFrameHeightRate;
								}
								$("#formImgArea").animate({ 'zoom':  screenRatio }, 10);
								$("#formArea").animate({ 'zoom':  screenRatio }, 10);

								//貼上浮水印
								waterMarkWidth = Math.ceil($('#pageFrame').width()-viewerMarginLeft);
								waterMarkHeight = Math.ceil($('#pageFrame').height()-viewerMarginTop);
								//alert('waterMarkWidth='+waterMarkWidth+", waterMarkHeight="+waterMarkHeight);
								if(rowData.waterMark == 'Y'){
									initWaterMark();
								}
						
								
					 	});

			        	for ( var i = 0; i < formfields.length; i++) {
			        		createFieldData(formfields[i], 1, null, 100/100 );
			        	}
			        	
			            }//ajax success end
		        }); //ajax end
	    		*/
	    		
	    		
	    	}//套表End
			
			
			
			
	    }; //renderRpt End
	    
	   
	    
	    
	    //上一頁
	    $("#lastPage").click(function(){
	    	if(targetPage >1 ){
				alFindPage=0;
				alFindBranch="";
		    	targetPage--;
				$("#rptPageNow").val(targetPage);
		    	renderRpt();
	    	}
	    });
		
		//指定頁數
		$("#rptPageNow").keyup(function(event){
			var pNow = $("#rptPageNow").val();
			var branchTotalPageCnt = parseInt($("#rptPageCnt").val()); 
			if(event.which==13 && !isNaN(pNow) && parseInt(pNow)>0 && parseInt(pNow)<=branchTotalPageCnt){ 
				alFindPage=0;
				alFindBranch="";
				targetPage = pNow;
				renderRpt();
			}
		});
	    
	    //下一頁
	    $("#nextPage").click(function(){
	    	if(targetPage < pageCnt + pageCntApprvHis){
				alFindPage=0;
				alFindBranch="";
	    		targetPage++;
				$("#rptPageNow").val(targetPage);
	    		renderRpt();
	    	}
	    });

		//關鍵字查詢
		var searchDiag = $("#searchDiag");
		//關鍵字查詢按鈕按下
		$("#queryKeyword").click(function(){
			searchDiag.css("top", "125px");
			searchDiag.show();
			//清空查詢結果列
			$("#searchResult").html("");
			//alert(searchDialog.css("z-index")+", width="+searchDialog.css("width")+",height="+searchDialog.css("height")+", left="+searchDialog.css("left")+", top="+searchDialog.css("top"));
		});
		//關鍵字Dialog關閉
		$("#searchDiagClose").click(function(){
			searchDiag.hide();
		});
		
		
		/*
		//在開啟狀態下直接按Enter
		searchDiag.keyup(function(event){
			if(event.which==13){
					if ($("#keyword").val()== '') {
							$("#searchResult").html("請輸入欲查詢的關鍵字!");
						}
					else {
						if (rowData.rptType == 'B') {
							searchKwByPlain("next");
						}else if (rowData.rptType == 'F') {
							searchKwByForm("next");
						}
					}
			}
			});
		*/	
		
		//尋找上一個
		$("#findLast").click(function(){
            if ($("#keyword").val() == '') {
                $("#searchResult").html("請輸入欲查詢的關鍵字!");
            }
            else {
                if (rowData.rptType == 'B') {
                    searchKwByPlain("back");
                    $("#searchResult").html("");
                }
                else 
                    if (rowData.rptType == 'F') {
                        searchKwByForm("back");
                        $("#searchResult").html("");
                    }
            }
		});
		//尋找下一個
		$("#findNext").click(function(){
            if ($("#keyword").val() == '') {
                $("#searchResult").html("請輸入欲查詢的關鍵字!");
            }
            else {
                if (rowData.rptType == 'B') {
                    searchKwByPlain("next");
                    $("#searchResult").html("");
                }
                else 
                    if (rowData.rptType == 'F') {
                        searchKwByForm("next");
                        $("#searchResult").html("");
                    }
            }
		});
		
		/**
		 * scroll到最下面
		 */
		var scrollDown = function(textAreaId){
			var textArea = $('#'+textAreaId);
			textArea.scrollTop(
				textArea[0].scrollHeight - textArea.height() +20
		    );
		}
		
		/**
		 * 白表關鍵字查詢
		 * @param {Object} queryType
		 */
		var alFound=false;
		var searchKwByPlain = function(queryType){
			$("#queryKeyword").attr("disabled",true);
			$("#findLast").attr("disabled",true);
			$("#findNext").attr("disabled",true);
			
			if(alFound){
				$("#searchResult").html("查詢狀態 :\n");
			}
			//alert("search:"+targetPage+","+rptBranch);
			$.ajax({
						url: '../../txn103011handler/searchKwByPlain' ,
						data:{
				        	rptId : rowData.rptId,
			            	rptVersion : rowData.rptVersion,
			            	rptDate : rowData.rptDate,
			            	rptReceiveDate : rowData.rptReceiveDate,
			            	rptReceiveTime :rowData.rptReceiveTime,
			            	rptSeqno : rowData.rptSeqno,
			            	targetPage: targetPage,
			            	rptBranch : rptBranch,
			            	branchArr : JSON.stringify(branchArr),
							queryType : queryType,
							keyword : $("#keyword").val(),
							lastKeyword : lastKeyword,
							alFindPage : alFindPage,
							alFindBranch : alFindBranch,
							pd : rowData.pd
				        } , 
						dataType: "json",
						timeout : 1800000,
						success: function(data){
							if(data.status=="fail"){
								alFound = false;
								$("#searchResult").html("未尋找到符合關鍵字 : "+ $("#keyword").val() +" 的內容!");
								
								$("#queryKeyword").attr("disabled",false);
								$("#findLast").attr("disabled",false);
								$("#findNext").attr("disabled",false);
							}else if(data.status=="continue"){
								alFound = false;
								//alert(JSON.stringify(data));
								//跳至下一頁繼續搜尋
								rptBrange = data.nextBranch;
								$("#branchSelect").val(rptBrange);
								$("#branchSelect").change();
								targetPage=data.nextPage;
								$("#rptPageNow").val(targetPage);
								renderRpt();
								$("#searchResult").append("已查詢至["+data.findBranch+"]分行, 第"+data.findPage+"頁..\r");
								scrollDown("searchResult");
								
								searchKwByPlain(data.queryType);
							}else{
								$("#queryKeyword").attr("disabled",false);
								$("#findLast").attr("disabled",false);
								$("#findNext").attr("disabled",false);
								
								//查詢成功
								alFound = true;
								//=======重新載入找到的那一頁報表內容===============
								plains = data.plains;
						
			    				//貼上資料
			    				var plainRpt="";
			    				for(var i=0;i<plains.length;i++){
			    					plainRpt = plainRpt + plains[i]+"\n";
			    				}
			    				$("#textArea").html("<plaintext id='plaintext' >"+plainRpt);
								$("#textArea").css("font-size", rowData.fontSize);
								$("#textArea").show();
								
								//貼上浮水印
								waterMarkWidth = Math.ceil($('#pageFrame').width()-viewerMarginLeft);
								waterMarkHeight = Math.ceil($('#pageFrame').height()-viewerMarginTop);
								if(rowData.waterMark == 'Y'){
									initWaterMark();
								}
								
								resizeRpt(rptRatio);
								
								//取得找到的分行與頁數 並更新
								var findBranch = data.findBranch;
								var findPage = data.findPage;
								var branchPageCnt = data.branchPageCnt;
								$("#searchResult").append("關鍵字[ "+$("#keyword").val()+" ] , 在["+findBranch+"]分行 , 第"+findPage+"頁找到.");
								scrollDown("searchResult");
								
								rptBranch = findBranch;
								targetPage = findPage;
								//更新分行
								$("#branchSelect").val(rptBranch);
								//更新分行總頁數
								$("#rptPageCnt").val(branchPageCnt);
								//更新目前分行
								$("#rptPageNow").val(targetPage);
								
								//紀錄上一次查詢的關鍵字以及找到的分行頁數(以防止找到同樣結果)
								lastKeyword = $("#keyword").val();
								alFindPage = findPage;
								alFindBranch = findBranch;

								//取得找到的關鍵字位置
								var findArr = data.findArr;
								var pageCharCnt = data.pageCharCnt;
								for(var i=0; i<findArr.length ; i++){
									var findKw = findArr[i];
									//查詢結果以反光筆呈現
										var range  = document.body.createTextRange ();
										range.moveToElementText(document.getElementById("plaintext"));
										range.moveStart("character", findKw.posStart);
										range.moveEnd("character", (findKw.posEnd-pageCharCnt-1));
										range.execCommand("backColor",false,"#FCFF00");
								}
								
							}//End of 查詢成功
						}
					});
			
			 $('.blockUI').css("z-index", 1012).css("position", "absolute");
		}
		
		/**
		 * 套表關鍵字查詢
		 * @param {Object} queryType
		 */
		var searchKwByForm = function(queryType){
			$("#queryKeyword").attr("disabled",true);
			$("#findLast").attr("disabled",true);
			$("#findNext").attr("disabled",true);
			$.ajax({
						url: '../../txn103011handler/searchKwByForm' ,
						data:{
				        	rptId : rowData.rptId,
			            	rptVersion : rowData.rptVersion,
			            	rptDate : rowData.rptDate,
			            	rptReceiveDate : rowData.rptReceiveDate,
			            	rptReceiveTime :rowData.rptReceiveTime,
			            	rptSeqno : rowData.rptSeqno,
			            	targetPage: targetPage,
			            	rptBranch : rptBranch,
			            	branchArr : JSON.stringify(branchArr),
							queryType : queryType,
							keyword : $("#keyword").val(),
							lastKeyword : lastKeyword,
							alFindPage : alFindPage,
							alFindBranch : alFindBranch,
							pd : rowData.pd
				        } , 
						dataType: "json",
						timeout : 1800000,
						success: function(data){
							
							if(data.status=="fail"){
								$("#queryKeyword").attr("disabled",false);
								$("#findLast").attr("disabled",false);
								$("#findNext").attr("disabled",false);
								$("#searchResult").html("未尋找到符合關鍵字 : "+ $("#keyword").val() +" 的內容!");
							}else if(data.status=="continue"){
								alFound = false;
								//alert(JSON.stringify(data));
								//跳至下一頁繼續搜尋
								rptBrange = data.nextBranch;
								$("#branchSelect").val(rptBrange);
								$("#branchSelect").change();
								targetPage=data.nextPage;
								$("#rptPageNow").val(targetPage);
								renderRpt();
								$("#searchResult").append("已查詢至["+data.findBranch+"]分行, 第"+data.findPage+"頁..\r");
								scrollDown("searchResult");
								
								searchKwByForm(data.queryType);
							}else{
								//查詢成功
								//=======重新載入找到的那一頁報表內容===============
								formfields = data.formfields;
					        	$("#formArea div").remove();
								
					        	var nocache = new Date();
								
								$("#formImgArea").show();
								$("#formArea").show();
								
								//背景圖片載入完成後才縮放
					        	$('#formImgArea').html("<img id='formImg' src='../../fileDownloadhandler/formImageDownload?"+nocache.getTime()+"&rptId="+rowData.rptId+"&rptVersion="+rowData.rptVersion+"&item="+data.selFormPage+"' />");
								$("#formImg").bind('load', function() {	
		
										//原圖縮放成紙張所需的比例, 取比例小的為符合紙張pageFrame大小的比率
										var imgToPageFrameWidthRate = ($("#pageFrame").width()-viewerMarginLeft*2)/$("#formImg").width();
										var imgToPageFrameHeightRate = ($("#pageFrame").height()-viewerMarginTop*2)/$("#formImg").height();
										if(imgToPageFrameWidthRate < imgToPageFrameHeightRate){
											screenRatio = imgToPageFrameWidthRate;
										}else{
											screenRatio = imgToPageFrameHeightRate;
										}
										$("#formImgArea").animate({ 'zoom':  screenRatio }, 10);
										$("#formArea").animate({ 'zoom':  screenRatio }, 10);
		
										//貼上浮水印
										waterMarkWidth = Math.ceil($('#pageFrame').width()-viewerMarginLeft);
										waterMarkHeight = Math.ceil($('#pageFrame').height()-viewerMarginTop);
										//alert('waterMarkWidth='+waterMarkWidth+", waterMarkHeight="+waterMarkHeight);
										if(rowData.waterMark == 'Y'){
											initWaterMark();
										}
							 	});

					        	for ( var i = 0; i < formfields.length; i++) {
					        		createFieldDataWithKeyword(formfields[i], 1, null, 100/100 );
					        	}
					        	
								//取得找到的分行與頁數 並更新
								var findBranch = data.findBranch;
								
								var findPage = data.findPage;
								var branchPageCnt = data.branchPageCnt;
								$("#searchResult").append("關鍵字[ "+$("#keyword").val()+" ] , 在分行 : "+findBranch+", 第"+findPage+"頁找到.");
								scrollDown("searchResult");
								
								//查詢按鈕開啟
								$("#queryKeyword").attr("disabled",false);
								$("#findLast").attr("disabled",false);
								$("#findNext").attr("disabled",false);
								
								rptBranch = findBranch;
								targetPage = findPage;
								//更新分行
								$("#branchSelect").val(rptBranch);
								//更新分行總頁數
								$("#rptPageCnt").val(branchPageCnt);
								//更新目前分行
								$("#rptPageNow").val(targetPage);
								
								//紀錄上一次查詢的關鍵字以及找到的分行頁數(以防止找到同樣結果)
								lastKeyword = $("#keyword").val();
								alFindPage = findPage;
								alFindBranch = findBranch;
								
							}//End of 查詢成功
						}
					});
			$('.blockUI').css("z-index", 1012).css("position", "absolute");
		}
	    
	    //下載PDF
	    * $("#dlPdf").click(function(){
			var rptData = {
				            	rptId : rowData.rptId,
				            	rptVersion : rowData.rptVersion,
				            	rptDate : rowData.rptDate,
				            	rptReceiveDate :rowData.rptReceiveDate,
				            	rptReceiveTime :rowData.rptReceiveTime,
				            	rptSeqno : rowData.rptSeqno,
								pd : rowData.pd,
								//簽核作業加入 必簽 若為必簽
								rptApprove:rowData.rptApprove,
								pageCntApprvHis:pageCntApprvHis
				            } ;  
			//alert('JSON.stringify(rptData)=' + JSON.stringify(rptData));
			rcmsApplet.exePdfJob(JSESSIONID, JSON.stringify(rptData), JSON.stringify(branchArr), rowData.rptType, rowData.fontSize);
	    });
		
		//下載Txt
	    $("#dlTxt").click(function(){
			if(rowData.rptType=='B'){
				var rptData = {
				            	rptId : rowData.rptId,
				            	rptVersion : rowData.rptVersion,
				            	rptDate : rowData.rptDate,
				            	rptReceiveDate :rowData.rptReceiveDate,
				            	rptReceiveTime :rowData.rptReceiveTime,
				            	rptSeqno : rowData.rptSeqno,
								pd : rowData.pd,
								rptApprove:rowData.rptApprove,
								pageCntApprvHis:pageCntApprvHis
				            } ; 
				rcmsApplet.exeTXTJob(JSESSIONID, JSON.stringify(rptData), JSON.stringify(branchArr));
			}else{
				alert("TXT僅供白表下載!");
			}
			
		});
		
	    var to2dig = function(n){
	    	if(n<10){
	    		return "0"+n;
	    	}else{
	    		return n;
	    	}
	    };
	    
	    var isIE = function() {
	    	  var myNav = navigator.userAgent.toLowerCase();
	    	  if(myNav.indexOf('msie') != -1){
	    		  return parseInt(myNav.split('msie')[1]);
	    	  }else if(myNav.indexOf('rv:11') != -1){
	    		  return 11.0;
	    	  }else if(myNav.indexOf('rv:12') != -1){
	    		  return 12.0;
	    	  }else if(myNav.indexOf('rv:13') != -1){
	    		  return 13.0;
	    	  }else{
	    		  false;
	    	  }
	    }
	    
		/**
		 * 下載filedownload watermark
		 */
		var initWaterMark = function() {
			
			
			//報表ID
			var waterMark2 = $('#watermarkDiv2');
			waterMark2.css("margin-top", "40px");
			waterMark2.css("font-size", "40px");
			//IE6 透明度
			waterMark2.css("filter", "progid:DXImageTransform.Microsoft.Alpha(opacity=30)");
			waterMark2.css("left", 120);
			waterMark2.html(rowData.rptId);
			waterMark2.show();
			
			
			//旋轉
			var waterMark = $('#watermarkDiv');
			
			var markLogo ="<img id='markLogoImg' src='../../static/images/system/hncb_water.gif' />"
			
			//日期字串
			var now = new Date();
			var markYear = now.getFullYear();
			var markMonth = to2dig(now.getMonth()+1);
			var markDate = to2dig(now.getDate());
			var markHour = to2dig(now.getHours());
			var markMin = to2dig(now.getMinutes());
			var markSec = to2dig(now.getSeconds());
			var markTimeStamp = markYear.toString() + markMonth.toString() + markDate.toString() + markHour.toString() + markMin.toString() + markSec.toString();
			
			
			
			var markContext = "";
			for(var i=0; i<3; i++){
				markContext = markContext + markLogo +userId + " " + markTimeStamp+" ";
			}
			
			waterMark.html(markContext);
			
			//根據紙張大小取得角度
			var deg = -Math.atan2( waterMarkHeight, waterMarkWidth) * (180/Math.PI);
			
			//計算IE radians = deg * ( Math.PI * 2 / 360);
			var rad = deg * (Math.PI * 2 / 360);
			
			if(isIE() == 9.0){
				//IE9旋轉
				waterMark.css("-ms-transform-origin", "left top");
				waterMark.css("-ms-transform", "rotate("+deg+"deg)");
			}
			
			if(isIE() >= 10.0){
				//IE9旋轉
				waterMark.css("top", waterMarkHeight - $("#markLogoImg").height() - viewerMarginTop);
				waterMark.css("-ms-transform-origin", "left top");
				waterMark.css("-ms-transform", "rotate("+deg+"deg)");
			}
			
			//設定符水印寬 應等於旋轉後的寬
			var rotateWidth  = ($('#pageFrame').width()-viewerMarginLeft)/Math.cos(rad) - (60 /Math.cos(rad)) ;
			//alert(rotateWidth);
			waterMark.css('width', rotateWidth);
			
			//IE6,7 旋轉
			//filter:DXImageTransform.Microsoft.Alpha(opacity=30) progid:DXImageTransform.Microsoft.Matrix(M11=cos(roation),M12=-sin(roation),M21=sin(roation),M22=cos(roation),SizingMethod='auto expand');
			waterMark.css("filter", "progid:DXImageTransform.Microsoft.Alpha(opacity=30) progid:DXImageTransform.Microsoft.Matrix(M11="+Math.cos(rad)+",M12="+(-Math.sin(rad))+",M21="+Math.sin(rad)+",M22="+Math.cos(rad)+",SizingMethod='auto expand')");
			
			//IE8  旋轉
			//-ms-filter: "progid:DXImageTransform.Microsoft.Matrix(SizingMethod='auto expand', M11=cos(roation), M12=-sin(roation), M21=sin(roation), M22=cos(roation)"; 
			waterMark.css("-ms-filter", "progid:DXImageTransform.Microsoft.Matrix(M11="+Math.cos(rad)+",M12="+(-Math.sin(rad))+",M21="+Math.sin(rad)+",M22="+Math.cos(rad)+",SizingMethod='auto expand')");
			
			waterMark.css("overflow", "hidden");
			waterMark.css("text-overflow", "clip");
			
			/*
			 * 左上右下才需要
			//IE filter旋轉時原點錯位
			if(isIE() < 9.0){
				//旋轉錯位往左移
				waterMark.css("left", -(Math.ceil($('#pageFrame').height()-viewerMarginTop) * Math.sin(rad))+viewerMarginLeft);
			}else{
				waterMark.css("left", viewerMarginLeft);
			}
			*/
			waterMark.css("left", viewerMarginLeft);
			
			waterMark.show();
		};
		
		/**
		 * js watermark
		
		var getWaterMark = function() {
			var waterMark = $('#watermarkDiv');
			var waterMarkContext ="<img src='../../static/images/system/hncb_water.gif' />"+userId;
			waterMark.html(waterMarkContext);
			waterMark.rotate(30);
			waterMark.show();
		};
		 */
	    
		//IE列印
		//列印
	    $("#ie_print").click(function(){
	    	window.open("../../viewpage/report/txn103015.jsp");
	    	/*
	    	CommonAPI.formSubmit({
	    		url:"./txn103015",target:"_blank",
	    		data:{}
	    	});
	    	*/
	    	
	    });
		
	    //列印
	    $("#print").click(function(){
			var rptData = {
				            	rptId : rowData.rptId,
				            	rptVersion : rowData.rptVersion,
				            	rptDate : rowData.rptDate,
				            	rptReceiveDate :rowData.rptReceiveDate,
				            	rptReceiveTime :rowData.rptReceiveTime,
				            	rptSeqno : rowData.rptSeqno,
								pd : rowData.pd,
								marginLeft : rowData.marginLeft,
								marginTop : rowData.marginTop,
								pageSize : rowData.pageSize,
								pageOrientation : rowData.pageOrientation,
								//簽核作業加入是否必簽 Y/N
								rptApprove:rowData.rptApprove,
								pageCntApprvHis:pageCntApprvHis
				            } ;   
			//console.log(JSESSIONID+","+ JSON.stringify(rptData)+","+ JSON.stringify(branchArr)+","+  rowData.rptType+","+  rptBranch+","+  targetPage);
	    	rcmsApplet.exePrintJob(JSESSIONID, JSON.stringify(rptData), JSON.stringify(branchArr), rowData.rptType, rptBranch, targetPage, rowData.fontSize);
	    });
	    
		//根據RDM定義將pdf/txt/浮水印/列印設定開關
		//if(rowData.dlPdf == 'N'){
			$("#dlPdf").hide();
		//}
		
		if(rowData.dlTxt == 'N'){
			$("#dlTxt").hide();
		}
		
		//20170509 PRD 版本先mark
		/*if(rowData.print == 'N'){
			$("#print").attr("disabled", true);
		}*/
		
		//若有符合使用者權限的分行, 則開啟第一個分行第一頁
	   if(branchArr != ""){
			 renderRpt(targetPage);
		}else{
			//2013-12-24 #255 修改用字
			$("#toolbar").attr("disabled", "disabled").off('click').hide();
			$("button").attr("disabled", "disabled").off('click').hide();
			$("a").attr("disabled", "disabled").off('click').hide();
			alert("此報表無資料!");
			window.close();
		}
	  };
		
		$("#appletLoading").css("margin", "auto auto");
		$("#appletLoading").css("width", "50%");
		$("#appletLoading").css("width", "50%");
		$("#appletLoading").show();
		
		//waituntilok();
		execViewer();
		
	});
});


