/**
 * 代理人維護-查詢/新增/修改/刪除
 *  - 新增/修改/刪除 須主管放行
 */
pageInit(function(){
	$(document).ready(function(){
		var grid = $("#gridview").jqGrid({
		    url:'../txn104061handler/query',
		    localFirst:true,
		    multiselect:true,
		    height:450,
		    sortname:'id.userId',
		    sortorder:"asc",
		    toppager: true,
		    height:"auto",
		    colModel:[
		        {header:'申請日',name:'applyDate',index:'applyDate',width:18},
		        {header:'被代理人',name:'userName',index:'userName',width:24},
		      	{header:'代理人',name:'deputyUserName',index:'deputyUserName',width:24}, 
		      	{header:'代理期間(起)',name:'deputyTimeStart',index:'deputyTimeStart',width:28}, 
		      	{header:'代理期間(迄)',name:'deputyTimeEnd',index:'deputyTimeEnd',width:28}, 
		        {header:'報表群組',name:'grpId',index:'grpId',width:36},
				{header:'備註',name:'dataStateNM',index:'dataState',width:8,
					formatter:function(val,obj,ret){
						return (val=='01') ? "新增" : (val=='02') ? "修改" : (val=='03') ? "刪除" : "";
		            }
				},
				{header:'狀態',name:'action',index:'action',width:10,
					formatter:function(val,obj,ret){
						return (val=='01') ? "待簽核" : (val=='02') ? "退回" : (val=='03') ? "已生效" : "";
		            }
				},
				{name:'dataState',hidden:true},
				{name:'deputyUserId',index:'deputyUserId',hidden:true},
				{name:'id',index:'id',hidden:true},
		        {name:'userId',index:'userId',hidden:true}],
				loadComplete : function(data){
					//若動作為 : 選取使用者 reloadGrid之後
					if(getInitGridUsrGrp){
						initGridUsrGrpArr = grid.getRowData();
						getInitGridUsrGrp = false;
					}
				}
		});
		
		function showRptNamesDialog(){
			qDialogShowRptNames.dialog({title:'報表資料'}).dialog('open');
		}
		
		//查詢條件form
		var mform = $("#mform");
		//查詢條件 - 被代理人
		var selLeaveUserIdQry = mform.find("#selLeaveUserIdQry");
		//查詢條件 - 代理人
		var selDeputyIdQry = mform.find("#selDeputyIdQry");
		
		//新增或修改主要輸入內容的form
		var aform = $("#aform");
		var selRptGrpId = aform.find('#selRptGrpId');
		//新增或修改 - 被代理人
		var selLeaveUserId = aform.find("#selLeaveUserId");
		//新增或修改 - 代理人
		var selDeputyId = aform.find("#selDeputyId");
		
		//查詢宣告
		var qDialog = $("#qDialog");
		qDialog.dialog({ //維護畫面
	    	height:260,width:460,modal:true,
	    	buttons:API.createJSON([{
	    		key:i18n.def.sure,
	    		value:function(){
	    			//被代理人 代理人 至少須有一個有輸入
	    			if (selLeaveUserIdQry.val()=='' && selDeputyIdQry.val()==''){
   					 	API.showErrorMessage("請選擇被代理人或被代理人!");
	    				return;
	    			}
	    			
	    			grid.jqGrid('setGridParam',{postData:mform.serializeData()});
	        		grid.trigger("reloadGrid",[{page:1}]);
	    			qDialog.dialog('close');
	    		}
	    	},{
	    		key:i18n.def.close,
	    		value:function(){
	    			qDialog.dialog('close');
	    		}
	    	}])
	    });
		
		//顯示報表群組內的報表名稱
		var qDialogShowRptNames = $("#qDialogShowRptNames");
		qDialogShowRptNames.dialog({ //維護畫面
	    	height:260,width:460,modal:true,
	    	buttons:API.createJSON([{
	    		key:i18n.def.sure,
	    		value:function(){
	    			grid.jqGrid('setGridParam',{postData:mform.serializeData()});
	        		grid.trigger("reloadGrid",[{page:1}]);
	    			qDialog.dialog('close');
	    		}
	    	},{
	    		key:i18n.def.close,
	    		value:function(){
	    			qDialog.dialog('close');
	    		}
	    	}])
	    });

		/**
		 * 查詢按鈕
		 */
		$("#qry").click(function(){
			qDialog.dialog({title:'查詢'}).dialog('open');
	    });
		
		//預設被代理人選項為本登入人員
		getLoginUserId();
		
		//帶入被代理人的所有報表群組
		var initGridUsrGrpArr=[];
		var getInitGridUsrGrp = false;
		
		//下拉選單init
		var initSelect = function(){
			mselect(selLeaveUserId);
			mselect(selDeputyId);
			mselect(selLeaveUserIdQry);
			mselect(selDeputyIdQry);
			mselectMultiple(selRptGrpId);
			
			//獲取被代理人下拉框
			$.ajax({ 
				url : "../txn104061handler/getAllUserByDivisionId",
				async: false,
				success : function(data) {
					ie6Exec(function(){
						selLeaveUserId.setOptions(data);	   //新增或修改
						selLeaveUserIdQry.setOptions(data); //查詢
						getLoginUserId();//預設被代理人選項為本登入人員
					});
					mselect(selLeaveUserId);
					mselect(selLeaveUserIdQry);
				}
			});
			
			//獲取代理人下拉框
			$.ajax({ 
				url : "../txn104061handler/getAllDeputyByDivisionId",
				async: false,
				success : function(data) {
					ie6Exec(function(){
						selDeputyId.setOptions(data);
						selDeputyIdQry.setOptions(data)
					});
					mselect(selDeputyId);
					mselect(selDeputyIdQry);
				}
			});
			
			
			//選擇被代理人下拉框 
			selLeaveUserId.change(function(){
				getInitGridUsrGrp = true;
				
				if (selLeaveUserId.val()==''){
					ie6Exec(function(){
						selRptGrpId.setOptions({});
					});
					mselectMultiple(selRptGrpId);
					grid.clearGridData();
				}else{
					getInfoGrpList();
					grid.jqGrid('setGridParam',{postData: {userId:selLeaveUserId.val()}});
		            grid.trigger("reloadGrid",[{page:1}]);
				}
			});
		};
		initSelect();
		
		//======================================
		//新增或修改的跳出視窗宣告
		var aDialog = $("#aDialog");
			aDialog.dialog({ //新增畫面
	    	height:360,
	    	width:550,
	    	modal:true,
	    	buttons:API.createJSON([{
	    		key:i18n.def.sure,
	    		value:function(){
	    			
	    			var id = aform.find('#id').val();
	    			
	    			if (selLeaveUserId.val()==''){
    					 API.showErrorMessage("請選擇被代理人!");
	    				return;
    				}
	    			
	    			if (selDeputyId.val()==''){
   					 	API.showErrorMessage("請選擇代理人!");
	    				return;
   				    }
	    			
	    			if (selLeaveUserId.val() == selDeputyId.val()){
	    				API.showErrorMessage("被代理人與代理人不能相同!");
	    				return;
	    			}
	    			
	    			if ($("#selRptGrpId").val() == null){
   					 	API.showErrorMessage("請選擇報表群組!");
	    				return;
   				    }
	    			
	    			if ($("#deputyDateStartAdd").val()=='' ||$("#deputyTimeStartHHAdd").val()=='' 
	    				||$("#deputyTimeStartMMAdd").val()=='' ||$("#deputyTimeStartSSAdd").val()==''){
   					 	API.showErrorMessage("請輸入代理期間(起)!");
	    				return;
   				    }
	    			
	    			if ($("#deputyDateEndAdd").val()=='' ||$("#deputyTimeEndHHAdd").val()=='' 
	    				||$("#deputyTimeEndMMAdd").val()=='' ||$("#deputyTimeEndSSAdd").val()==''){
   					 	API.showErrorMessage("請輸入代理期間(迄)!");
	    				return;
   				    }
	    			
	    			/*
	    			//id為空時表示為新增 須檢查:
	    			if (id=='' && $("#deputyDateStartAdd").val() < CommonAPI.getToday()){//若為新增要檢查起日
	    				API.showErrorMessage("代理期間起日須大於或等於本日!");
	    				return;
	    			}
	                
	    			//新增或修改時均須檢查:
	    			//<代理期間迄日>須大於或等於本日
	                //<代理期間迄日>須大或等於<代理期間起日期>
	    			 if ($("#deputyDateEndAdd").val() < CommonAPI.getToday()){
	    					API.showErrorMessage("代理期間迄日須大於或等於本日!");
	    					return;
	    			 } else if ($("#deputyDateStartAdd").val() > $("#deputyDateEndAdd").val()){
	    					API.showErrorMessage("代理期間迄日須大於或等於代理期間起日!");
	    					return;
	    			 } else {
	    				 
	    					$.ajax({   
		    		            url:'../txn104061handler/saveOrUpdate',
		    		            data:aform.serializeData(),
		    		            success:function(data){    
		    		            	if (data.result!=undefined && data.result == 'success'){
		    		            		API.showMessage("已送出!");
		    		            	} else {
		    		            		API.showErrorMessage(data.result);
		    		            	}
		    		            	grid.trigger("reloadGrid",[{page:1}]);
		    		            }
		    				});
		    				aDialog.dialog('close');
		    				$(this).find('form')[0].reset();
	    			}
	    			*/
	    			
	    			
	    			var deputyNewDateStart = $("#deputyDateStartAdd").val() + " " +
										$("#deputyTimeStartHHAdd").val() + ":" +
										$("#deputyTimeStartMMAdd").val();
					var deputyNewDateEnd = $("#deputyDateEndAdd").val() + " " +
										$("#deputyTimeEndHHAdd").val() + ":" +
										$("#deputyTimeEndMMAdd").val();
					var nowTimeInMin = CommonAPI.getTimeToMin();
					//alert(deputyNewDateStart+", "+deputyNewDateEnd+", "+nowTimeInMin);
	    			if (deputySetType == "add"){
	    				//新增
	    				if(deputyNewDateStart >= nowTimeInMin){
	    					if (deputyNewDateEnd >= deputyNewDateStart){
	    						//日期檢核成功
	    					}else{
	    						API.showErrorMessage("代理迄日("+deputyNewDateEnd+")不可小於代理起日("+deputyNewDateStart+")");
		    					return;
	    					}
	    				}else{
	    					API.showErrorMessage("代理起日("+deputyNewDateStart+")需大於等於本日("+nowTimeInMin+")");
		    				return;
	    				}
	    			}else if (deputySetType =="edit"){
	    				//修改
	    				if(deputyOriDateStart >= nowTimeInMin){
	    					//(原代理起日) >= (現在時間) --- 代理期間未開始
	    					
	    					//由於代理期間未開始  起日仍可以修改 因此判斷同[新增]
	    					if(deputyNewDateStart >= nowTimeInMin){
		    					if (deputyNewDateEnd >= deputyNewDateStart){
		    						//日期檢核成功
		    					}else{
		    						API.showErrorMessage("代理迄日("+deputyNewDateEnd+")不可小於代理起日("+deputyNewDateStart+")");
			    					return;
		    					}
		    				}else{
		    					API.showErrorMessage("代理起日("+deputyNewDateStart+")需大於等於本日("+nowTimeInMin+")");
			    				return;
		    				}
	    				}else{
	    					//(原代理起日) < (現在時間) 
	    					if(deputyNewDateStart != deputyOriDateStart){
	    						API.showErrorMessage("已逾代理起日("+deputyOriDateStart+")，不可修改代理起日");
		    					return;
	    					}else{
	    						if(deputyOriDateEnd >= nowTimeInMin){
		    						//(原代理起日)< (現在時間) <=(原代理迄日) --- 代理期間
	    							
	    							//由於期間已開始 起日一定會小於目前時間 所以只判斷迄日要大於今日且要大於等於起日
	    							if(deputyNewDateEnd >= nowTimeInMin){
	    		    					if (deputyNewDateEnd >= deputyNewDateStart){
	    		    						//日期檢核成功
	    		    					}else{
	    		    						API.showErrorMessage("代理迄日("+deputyNewDateEnd+")不可小於代理起日("+deputyNewDateStart+")");
	    			    					return;
	    		    					}
	    		    				}else{
	    		    					API.showErrorMessage("代理迄日("+deputyNewDateEnd+")需大於等於本日("+nowTimeInMin+")");
	    			    				return;
	    		    				}
		    					}else{
		    						//(原代理起日) <=(原代理迄日) < (現在時間) --- 代理期間已結束
		    						API.showErrorMessage("已逾代理迄日("+deputyOriDateEnd+")，不可修改代理迄日");
		    						return;
		    					}
	    					}
	    				}
	    			}else{
	    				if(console !=undefined){
	    					console.log("deputySetType="+deputySetType);
	    				}
	    				return;
	    			}
	    			//修改時
	    			$.ajax({   
    		            url:'../txn104061handler/saveOrUpdate',
    		            data:aform.serializeData(),
    		            success:function(data){    
    		            	if (data.result!=undefined && data.result == 'success'){
    		            		API.showMessage("已送出!");
    		            	} else {
    		            		API.showErrorMessage(data.result);
    		            	}
    		            	grid.trigger("reloadGrid",[{page:1}]);
    		            }
    				});
    				aDialog.dialog('close');
    				$(this).find('form')[0].reset();
	    			
	    		}
	    	},{
	    		key:i18n.def.close,
	    		value:function(){
	    			aDialog.dialog('close');
	    			$(this).find('form')[0].reset();
	    			getLoginUserId();
	    		}
	    	}])
	    });
		
		//代理人編輯類型 add/edit/del
		var deputySetType = "add";
		//前次的代理起日
		var deputyOriDateStart;
		//前次的代理迄日
		var deputyOriDateEnd;
		
	    //新增
	    $("#add").click(function(e){
	    	deputySetType = "add";
	    	//aDialog
	    	$("#deputyDateStartAdd").removeAttr("disabled");
			$("#deputyTimeStartHHAdd").removeAttr("disabled");
			$("#deputyTimeStartMMAdd").removeAttr("disabled");
			$("#deputyTimeStartSSAdd").removeAttr("disabled");
			
	    	$("#deputyTimeStartHHAdd").val("09").change();
	    	$("#deputyTimeStartMMAdd").val("00").change();
	    	$("#deputyTimeStartSSAdd").val("00").change();
	    	$("#deputyTimeEndHHAdd").val("17").change();
	    	$("#deputyTimeEndMMAdd").val("00").change();
	    	$("#deputyTimeEndSSAdd").val("00").change();
	    	
	    	initSelect();
	    	aDialog.dialog({
	    		title:'新增',
	    		open:function(){
	    		}
	    	}).dialog('open');
	    });
	    
		/**
		 * 修改
		 * 狀態為”已生效”的才能選取並進行修改
			<代理期間起日>須大於或等於本日才能修改, 只能修改<代理期間起日> 、<代理期間迄日> 欄位
		    原<代理期間起日> 若是今日就不能改, 若是今天以後日期則可以改
		    <代理期間迄日>須大於或等於本日
            <代理期間迄日>須大或等於<代理期間起日期>
		 */
	    
		$("#edit").click(function(){
			var deputySetDateStart = false;
			var selRowIds = grid.jqGrid ('getGridParam', 'selarrrow');
			if(selRowIds.length==0){
				API.showErrorMessage("請至少選一筆資料");
				return;
			}
			
			var row=oneSelect(grid);
			if (row != undefined && row !=null){
				deputySetType = "edit";
				deputyOriDateStart = row['deputyTimeStart'].substring(0,16);
				deputyOriDateEnd = row['deputyTimeEnd'].substring(0,16);
				var nowTimeInMin = CommonAPI.getTimeToMin();
				//alert(deputyOriDateStart+", "+deputyOriDateEnd+", "+nowTimeInMin);
				
				if(row['action'] =='已生效'){
					if(deputyOriDateEnd < nowTimeInMin){
						//(原代理起日) <=(原代理迄日) < (現在時間) --- 代理期間已結束
						API.showErrorMessage("已逾代理迄日("+deputyOriDateEnd+")，不可修改代理迄日");
						return;
					}else if(deputyOriDateStart >= nowTimeInMin){
						//原代理起日(oy) >= 本日(X) 到(yyyy-MM-dd HH:mm) 
						//目前時間未超過起日設定: 於dialog 送出時同新增add的日期檢查
					}else{
						deputySetDateStart = true;
						//目前時間已超過起日設定: 於dialog 送出時執行超過起日之日期檢查
					}
				}else{
					API.showErrorMessage("本筆設定尚未生效，請簽核人員退回重設");
					return;
				}
			}else{
				return;
			}
			initSelect();
			aDialog.dialog({
				title:'修改',
				open:function(){
					aform.find('#id').val(row['id']);
					aDialog
					.find("#selLeaveUserId").val(row['userId']).end()
					.find("#selDeputyId").val(row['deputyUserId']).end()
					.find("#deputyDateStartAdd").val(row['deputyTimeStart'].substring(0,10)).end()
					.find("#deputyDateEndAdd").val(row['deputyTimeEnd'].substring(0,10)).end();
					mselect(selLeaveUserId);
					mselect(selDeputyId);
					getInfoGrpList();
					mselectMultiple(selRptGrpId);
					
					$("#deputyTimeStartHHAdd").val(row['deputyTimeStart'].substring(11,13)).end();
					$("#deputyTimeStartMMAdd").val(row['deputyTimeStart'].substring(14,16)).end();
					$("#deputyTimeStartSSAdd").val(row['deputyTimeStart'].substring(17,19)).end();
					
					//原<代理期間起日> 若是超過目前時間(yyyy-MM-dd HH:mm)就不能改
					//alert(deputySetDateStart);
					if (deputySetDateStart){
						$("#deputyDateStartAdd").attr("disabled", "disabled");
						$("#deputyTimeStartHHAdd").attr("disabled", "disabled");
						$("#deputyTimeStartMMAdd").attr("disabled", "disabled");
						$("#deputyTimeStartSSAdd").attr("disabled", "disabled");
					}else{
						$("#deputyDateStartAdd").removeAttr("disabled");
						$("#deputyTimeStartHHAdd").removeAttr("disabled");
						$("#deputyTimeStartMMAdd").removeAttr("disabled");
						$("#deputyTimeStartSSAdd").removeAttr("disabled");
					}
							
					 $("#deputyTimeEndHHAdd").val(row['deputyTimeEnd'].substring(11,13)).end();
					 $("#deputyTimeEndMMAdd").val(row['deputyTimeEnd'].substring(14,16)).end();
					 $("#deputyTimeEndSSAdd").val(row['deputyTimeEnd'].substring(17,19)).end();
					 
					//參考txn201041.js
					//https://anilkumarlive.wordpress.com/jquery-multiselect-set-a-value-as-selected-in-the-multiselect-dropdown/
					//sleep(2500);
					var valArr = row['grpId'].split(',');
					
					i = 0, size = valArr.length;
					for(i; i < size; i++){
					  $("#selRptGrpId").multiselect2("widget").find(":checkbox[value='"+valArr[i]+"']").attr("checked","checked");
					  $("#selRptGrpId option[value='" + valArr[i] + "']").attr("selected", 1);
					  $("#selRptGrpId").multiselect2("refresh");
					  mselectMultiple($("#selRptGrpId"));
					}
				}
			}).dialog('open');
			
			/*
			if (row != undefined && row !=null && row['action'] !='已生效'){
				API.showErrorMessage("已生效的資料才能修改");
			} else if (row != undefined && row !=null && row['deputyTimeStart'].substring(0,10) < CommonAPI.getToday()){
				API.showErrorMessage("代理期間起日須大於或等於本日才能修改");
			} else{
				aDialog.dialog({
					title:'修改',
					open:function(){
						aform.find('#id').val(row['id']);
						aDialog
						.find("#selLeaveUserId").val(row['userId']).end()
						.find("#selDeputyId").val(row['deputyUserId']).end()
						.find("#deputyDateStartAdd").val(row['deputyTimeStart'].substring(0,10)).end()
						.find("#deputyDateEndAdd").val(row['deputyTimeEnd'].substring(0,10)).end();
						mselect(selLeaveUserId);
						mselect(selDeputyId);
						getInfoGrpList();
						mselectMultiple(selRptGrpId);
						
						$("#deputyTimeStartHHAdd").val(row['deputyTimeStart'].substring(11,13)).end();
						$("#deputyTimeStartMMAdd").val(row['deputyTimeStart'].substring(14,16)).end();
						$("#deputyTimeStartSSAdd").val(row['deputyTimeStart'].substring(17,19)).end();
						
						//原<代理期間起日> 若是今日就不能改, 若是今天以後日期則可以改
						if (row['deputyTimeStart'].substring(11,13) == CommonAPI.getToday()){
							$("#deputyTimeStartHHAdd").attr("disabled", "disabled");
							$("#deputyTimeStartMMAdd").attr("disabled", "disabled");
							$("#deputyTimeStartSSAdd").attr("disabled", "disabled");
						} 
								
						 $("#deputyTimeEndHHAdd").val(row['deputyTimeEnd'].substring(11,13)).end();
						 $("#deputyTimeEndMMAdd").val(row['deputyTimeEnd'].substring(14,16)).end();
						 $("#deputyTimeEndSSAdd").val(row['deputyTimeEnd'].substring(17,19)).end();
						 
						//參考txn201041.js
						//https://anilkumarlive.wordpress.com/jquery-multiselect-set-a-value-as-selected-in-the-multiselect-dropdown/
						//sleep(2500);
						var valArr = row['grpId'].split(',');
						
						i = 0, size = valArr.length;
						for(i; i < size; i++){
						  $("#selRptGrpId").multiselect2("widget").find(":checkbox[value='"+valArr[i]+"']").attr("checked","checked");
						  $("#selRptGrpId option[value='" + valArr[i] + "']").attr("selected", 1);
						  $("#selRptGrpId").multiselect2("refresh");
						  mselectMultiple($("#selRptGrpId"));
						}
					}
				}).dialog('open');
			}
			*/
			
		});	
		
		function sleep(milliseconds) {
			  var start = new Date().getTime();
			  for (var i = 0; i < 1e7; i++) {
			    if ((new Date().getTime() - start) > milliseconds){
			      break;
			    }
			  }
			}

		//刪除 刪除狀態須為已生效且<代理期間起日>大於本日的資料才能刪除
		$("#delete").click(function(){
			deputySetType = "del";
			var selRowIds = grid.jqGrid ('getGridParam', 'selarrrow');
			if(selRowIds.length==0){
				API.showErrorMessage("請至少選一筆資料");
			}else{
				var row,i,rstString="";
				var nowTimeInMin = CommonAPI.getTimeToMin();
				for(i=0; i<selRowIds.length; i++ ){	
					row=grid.getRowData(selRowIds[i]);
					
					deputySetType = "del";
					var deputyDelDateStart = row['deputyTimeStart'].substring(0,16);
					
					rstString = rstString + row['id'] + "," ;
					if (row['action'] != '已生效'){
						API.showErrorMessage("狀態為已生效的資料才能刪除!");
						return;
					}
					if (deputyDelDateStart <= nowTimeInMin ){
						API.showErrorMessage("代理期間起日("+deputyDelDateStart+")大於本日("+nowTimeInMin+")的資料才能刪除!");
						return;
					}
				}
				API.showConfirmMessage("確定要刪除?  \n",function(yes){
					$.ajax({   
    		            url:'../txn104061handler/deleteToApprv',
    		            data:{rstString:rstString},
    		            success:function(data){     
    		            	grid.trigger("reloadGrid",[{page:1}]);
    		            }
    				});
				});
			}		
	    });	

		var grpPms = {} , grpNames = {};
		function getLoginUserId(){
			
			$.ajax({ 
				url : "../txn104061handler/getLoginUserId",
				data : {},
				async: false,
				success : function(data) {
					//新增/修改視窗的被代理人預設為登入人員
					selLeaveUserId.val(data.loginUserId);
					//查詢視窗的被代理人預設為登入人員
					selLeaveUserIdQry.val(data.loginUserId);
					getInfoGrpList();
				}
			});
		}
		
		/**
		 * 依被代理人顯示該人員有權限的報表群組下拉框
		 */
		function getInfoGrpList() {
			$.ajax({ 
				url : "../txn104061handler/getInfoGrpList2",
				data : {userId : selLeaveUserId.val()},
				async: false,
				success : function(data) {
					grpNames = data.grpOps;
					grpPms = data.grpPms;
					
					ie6Exec(function(){
						selRptGrpId.setOptions(data.grpOps)
					});
					mselectMultiple(selRptGrpId);
					selRptGrpId.multiselect2("uncheckAll");
				}
			});
		}
		
		function mselect(select){
			select.multiselectfilter("destroy");
			select.multiselect2({
		    	selectedList: 4,
		    	multiple: false
		    }).multiselectfilter({
		    	label: "內含",
		    	placeholder: "輸入關鍵字" 
		    });
		}
		
		function mselectMultiple(select){
			select.multiselectfilter("destroy");
			select.multiselect2({
				selectedList: 4,
		    	multiple: true,
		    	checkAllText : "全選",
		    	uncheckAllText : "取消全選"
		    }).multiselectfilter({
		    	label: "內含",
		    	placeholder: "輸入關鍵字" 
		    });
		}
		
		function ie6Exec(cmd){
			try {
				cmd();
			} catch(ex) {
			    setTimeout(function() {
			    	cmd();
			    },1);
			}
		}
	});
});