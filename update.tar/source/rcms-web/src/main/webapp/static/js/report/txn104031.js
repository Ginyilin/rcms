/**
 * 簽核作業 - 整批改派(依單位異動人員)-  
 * 使用者按下[查詢]按鈕進入查詢彈跳視窗:選取<簽核人員>(系統會自動帶出仍有未改派報表人員的清單供選擇)、<報表群組>查詢條件以查詢出目前簽核中的報表，
 * 再勾選單一或多張報表以改派給其它簽核人員(同一簽核人員身上的報表可以改派給多位人員)。
 * 使用人員:第一關經辦或總務的人員
 */
pageInit(function(){
	$(document).ready(function(){
	    var grid, eform = $("#eform"),qform = $("#qform");
	    //紀錄"跨頁取消勾選"
		//var selectdata = {};
	    //var selectdata =new Array();
	    //var selectdata = [];
	    grid = $("#gridview").jqGrid({
	    	url: '../txn104031handler/query',
	    	multiselect: false,
	    	localFirst:true,//預設值為false 當設為 true 時，畫面開啟不會查詢資料
	    	height: 450,
	    	sortname: 'rptContentMasterPK.rptId',
	    	sortorder: "desc",
	    	multiselect : true,
	    	toppager: true,
	        colModel: [
	        {header: '預設經辦',name: 'setUserId',width: 16,align: "center"} ,
	        {header: '報表代號',name: 'rptContentMasterPK.rptId',width: 12,align: "center"} , 
	        //{header: '版本',name: 'rptContentMasterPK.rptVersion',width: 8,align: "center"} ,
	        {header: '報表名稱',name: 'rptName',index:'rptName',width: 25},
	        {header: '報表日期', name: 'rptContentMasterPK.rptDate',width: 10,align: "center"},
	        {header: '序號',name: 'rptContentMasterPK.rptSeqno',width: 6,align: "center"}, 
	        //{header: '業管單位',name: 'governingUnit',sortable:false ,width: 20, align: "center"}, 
	        {header:'報表週期',name:'rptCycle',width:6,align:"center"},
	        {header: '必印註記',name: 'mustPrint',width: 6,align: "center"},
	        //{header: '必簽註記',name: 'rptApprove',sortable:false,width: 10,align: "center"},
	        {header:'個資註記',name:'pd',sortable:false,width:6,align:"center"},
	        {header:'收檔日期',name:'convertTimeStart',sortable:false,width:16,align:"center"},
	        {header:'逾期天數',name:'overdueDays',sortable:false,width:8,align:"center"},
	        {header:'簽核狀況',name:'apprvStatus',sortable:false,width:8,align:"center"},
	        //{header: '收檔日期時間',name: 'convertTimeStart',width:25,align: "center"},
	        {header: '頁數',name: 'pageCnt',width:10,align: "center", hidden:true},
	        {name: 'rptReceiveDate', hidden:true},
	        {name: 'rptReceiveTime', hidden:true},
	        {name: 'rptType', hidden:true},
	        {name: 'id', index:'id',hidden:true},
	        {name: 'branchArr',hidden:true},
	        {name: 'marginLeft', hidden:true},
	        {name: 'marginTop',hidden:true},
	        {name: 'rptPageSize', hidden:true},
	        {name: 'rptPageOrientation',hidden:true},
	        {name: 'dlPdf', hidden:true},
	        {name: 'dlTxt',  hidden:true},
	        {name: 'waterMark',  hidden:true},
	        {name: 'pd',  hidden:true},
	        {name: 'print',  hidden:true},
	        {name: 'fontSize',  hidden:true},
	        {name: 'rptContentMasterPK.rptVersion', hidden:true},
	        {name: 'convertTimeStartFull', hidden:true}
	        ],	       
	        loadComplete : function(data){
	        	//default select all
				var ids = $("#gridview").getDataIDs();
				//若動作為 : 選取使用者 reloadGrid之後
				if(getInitGridUsrGrp){
					initGridUsrGrpArr = grid.getRowData();
					getInitGridUsrGrp = false;
				}
	        },
	        loadComplete : function(data){
	        	//default select all
				var ids = $("#gridview").getDataIDs();
				//若動作為 : 選取使用者 reloadGrid之後
				if(getInitGridUsrGrp){
					initGridUsrGrpArr = grid.getRowData();
					getInitGridUsrGrp = false;
				}
	        }
    }).jqGrid('navGrid','#pager',{cloneToTop:true}).setGridWidth(840);
	    
	    //請求查詢
		//grid.jqGrid('setGridParam',{postData:eform.serializeData()});
		//grid.trigger("reloadGrid",[{page:1}]);
		
		//查詢條件:簽核人員/報表群組
		q_selUserId = qform.find("#q_selUserId");
		q_selRptGrpId = qform.find('#q_selRptGrpId');
		
		var q_selUserIdValue;
		
		//改派後人員
		selUserId = eform.find("#selUserId");
		
		mselect(q_selUserId);
		mselectMultiple(q_selRptGrpId);
		
		//查詢條件 獲取待改派使用者下拉框
		$.ajax({ 
			url : "../txn104031handler/getToReAssignUserList",
			success : function(data) {
				ie6Exec(function(){
					q_selUserId.setOptions(data)
				});
				//selUserId.setOptions(data);
				mselect(q_selUserId);
			}
		});
		
	    
		//帶入user的原有群組
		var initGridUsrGrpArr=[];
		var getInitGridUsrGrp = false;
		//選擇user下拉框  查詢用戶的組群權限
		q_selUserId.change(function(){
			getInitGridUsrGrp = true;
			getInfoGrpList();
			if (q_selUserId.val()==''){
				ie6Exec(function(){
					q_selRptGrpId.setOptions({});
				});
				
				mselectMultiple(q_selRptGrpId);
				grid.clearGridData();
			}else{
				
				$.ajax({ 
					url : "../txn104031handler/getToReAssignUserList",
					//data : {userId : q_selUserId.val()},
					success : function(data) {
						ie6Exec(function(){
							q_selUserId.setOptions(data)
						});
						//mselect(selCopyUserId);
					}
				});
				q_selUserIdValue = q_selUserId.val();			
				//grid.jqGrid('setGridParam',{postData: {userId:q_selUserId.val()}});
	            //grid.trigger("reloadGrid",[{page:1}]);
			}
		});
		
		//查詢
		var qDialog = $("#qryDailog");
		qDialog.dialog({ //查詢畫面
			
	    	height:200,width:500,modal:true,
	    	buttons:API.createJSON([{
	    		key:i18n.def.sure,
	    		value:function(){
	    			//清除已勾選
	    			//selectdata = {};
	    	        //請求查詢
	    			var q_selRptGrpIds = $("#q_selRptGrpId").val()
	    			if(q_selRptGrpIds == null){
	    				q_selRptGrpIds=[];
	    				API.showErrorMessage("請選擇報表群組!");
	    				return;
	    			}	    			
	    			grid.jqGrid('setGridParam',{postData:{q_selUserId:q_selUserIdValue, q_selRptGrpIds: q_selRptGrpIds}});
	    		    grid.trigger("reloadGrid",[{page:1}]);
	    		    qDialog.dialog('close');
	    		}
	    	},{
	    		key:i18n.def.close,
	    		value:function(){
	    			qDialog.dialog('close');
	    		}
	    	}])
	    });
		
	//按下[查詢] 按鈕
	$("#query").click(function(){
		qDialog.dialog('open');
    }).trigger('click');
	
	
	
	//按下[改派] 按鈕
	$("#resetting").click(function(){
		
		var selIds = $("#gridview").jqGrid("getGridParam", "selarrrow"), i, n, selectdata = [];
		for (i = 0, n = selIds.length; i < n; i++) {
		    selectdata.push(grid.jqGrid("getCell", selIds[i], "id"));
		}
		
    	var selectdataCnt = selectdata.length;
    	
    	if(grid.jqGrid('getGridParam', 'records') == 0){
			API.showErrorMessage("無報表資料!");
			return;
		}
    	
    	if(selectdataCnt == 0){
    		API.showErrorMessage("請選擇一筆資料");
    		return;
    	}
    	
		if(selectdata!= null && selectdata.length!=0){
			eform.reset();
	    	selUserId = eform.find("#selUserId");
	    	getUserList();
			mselect(selUserId);
			
			//獲取使用者下拉框
			$.ajax({ 
				url : "../txn104031handler/getAclUserList",
				data : {q_selUserId : q_selUserId.val()},
				success : function(data) {
					ie6Exec(function(){
						selUserId.setOptions(data)
					});
					mselect(selUserId);
				}
			});
			eDialog.dialog({
				title:'整批改派(依單位異動人員)',
				height:180,
		    	width:500,
		    	modal:true,
		    	buttons:API.createJSON([
				{
					key:i18n.def.sure,
					value:function(){
						
						//alert("原簽核人員:"+q_selUserId.val());
						$.ajax({ 
							url : "../txn104031handler/doResetting",
							data : {
								selectdata:selectdata,
								//selectdata:selectdata,
								selUserId:selUserId.val(),
								oriSelUserId:q_selUserId.val()
								},
							async: false,
							success : function(data) {
								if (data.result == 'success'){
									API.showMessage("整批改派成功!");
									grid.jqGrid('setGridParam',{postData:qform.serializeData()});
						    		grid.trigger("reloadGrid",[{page:1}]);
								} else {
									API.showErrorMessage(data.resultMsg);
								}
								//rptData = data.rptOps;//empId,empName
								//$.each(deptData,function(key,value){alert('depNo:'+key+",depName="+value)});
							}
						});
						
					}
				},
		    	{
		    		key:i18n.def.close,
		    		value:function(){
		    			eDialog.dialog('close');
		    			$(this).find('form')[0].reset();
		    			eform.reset();
		    			$("#eform").trigger( "reset" );
		    		}
		    	}
		    	]),
				open:function(){
					//ie6Exec(function(){
					//	selUserId.setOptions({});
						//selUserId.setOptions(empData);
					//});
				}
			}).dialog('open');
			
		}else{
			API.showErrorMessage("請至少選擇一筆資料!");
		}
	});
	
	//起迄日期預設值
	/*var today = new Date();
	$("#rptDateBegin").val(CommonAPI.getShiftDate((today.getDay()==1) ? -3 : -1));
	$("#rptDateEnd").val(CommonAPI.getToday());
	*/
		
		//進行設定的彈跳視窗
		var eDialog = $("#editDailog");
		
		//進行設定的form
		var eform = $("#eform");
		
		//用以存放登入人員所屬單位的人員清單
		var empData;
		//用以存放登入人員所屬單位的主管清單(決行的人員下拉選單)
		var mgrData;
		
		var myUserId;
		var myBranchId;
		
		//取得登入人員所屬單位的人員清單
		getUserList();
		getMyUserId();
		
		
	    
	/**
	 * 查詢
	 * 1.單位人員下拉選單
	 * 2.單位主管下拉選單
	 * 3.
	 * 
	 */
	function getUserList() {
		$.ajax({ 
			url : "../txn104031handler/getAllUser",
			data : {},
			async: false,
			success : function(data) {
				empData = data.empOps; //empId,empName
				//$.each(empData,function(key,value){alert('empId:'+key+",empName="+value)});
				mgrData = data.mgrOps; //empId,empName
			}
		});
	}
    
    var i = 2;//預設UI上會帶出第1筆和決行,因此簽核層級由2開始編
    var arrAdd=[];
    
    var t;
    
	  /**按下[確認送出]存檔
	   * 檢查:
	   * 1.第1關須包含本人
	   * 2.各層級人員不能重覆
	   * 3.簽核意見不能超過100個中文字(或200個英文字)
	   * 
	   * */
	  $('#btnSubmit').click(function () {
		 
		  //取出第1關的設定值
		  var arrStartUserIds = $('#selStartUserId').find("option:selected").map(function() {
			    return this.value;
			}).get();
		  
		  if (arrStartUserIds.length==0){
			  API.showErrorMessage("請選取第1關的簽核人員");
		      return;
		  }
		  
		  //取出最後1關(決行)的設定值
		  var arrEndUserIds = $('#selEndUserId').find("option:selected").map(function() {
			    return this.value;
			}).get();
		  
		  if (arrEndUserIds.length==0){
			  API.showErrorMessage("請選取決行的簽核人員");
		      return;
		  }
		  
		  //檢查各關卡的人員不能重覆
		  var allSelUserArr = [];
		 
		  //檢查第1關的人員必須含登入使用者
		  var valideStartStep = false;
		  for(var t=0;t<arrStartUserIds.length;t++){			  
			  if (arrStartUserIds[t] == myUserId){
				  valideStartStep = true;
				  break;
			  }
		  }
		  
		  for(var t=0;t<arrStartUserIds.length;t++){
			  allSelUserArr.push(arrStartUserIds[t]);
		  }
		  
		  for(var t=0;t<arrEndUserIds.length;t++){
			  allSelUserArr.push(arrEndUserIds[t]);
		  }
		  
		  if (valideStartStep == false){
			  API.showErrorMessage("簽核層級第1關須包含本人");
			  return;
	      }
		  
		  //存放除了第1關及最後一關(決行)以外的被選取人員資料
		  var selDataArr = [];
		  $('select[id*="selUserId"]').each(function(i) {
			  var empDataArr = $(this).val();
			  //alert('empDataArr='+empDataArr);
			  if (empDataArr == null){
				  API.showErrorMessage("請選擇簽核層級人員");
			      return;
			  }
			  for(var t=0;t<empDataArr.length;t++){
				  allSelUserArr.push(empDataArr[t]);
			  }
			  selDataArr.push(empDataArr);
	      });
	    	
	      if ($('#apprvComment').val() != null && $('#apprvComment').val().length > 100){
	    	  API.showErrorMessage("簽核意見不得超過100個中文字或200個英文字!");
	    	  return;
	      }
	    	 
    	 var tmpArr = findDuplicates(allSelUserArr);
    	 if (tmpArr != undefined && tmpArr.length>0){
    		 var dupUserIds ='';
    		 for (var t=0;t<tmpArr.length;t++){
    			 dupUserIds = dupUserIds + " " + tmpArr[t];
	    	 }
    		 API.showErrorMessage("各簽核層級人員不能重覆選取!"+ dupUserIds +" 已重覆");
	    	 return;
    	 }
	    
    	 return;
	    	$.ajax({   
	            url:'../txn104031handler/save',
	            data:{
	            	selDataArr:selDataArr,
	            	startUserId:arrStartUserIds,
	            	endUserId:arrEndUserIds,
	            	id:$('#id').val(),	            	
	            	convertTimeStartFull:$('#convertTimeStartHidden').val(),
	            	apprvUserData:JSON.stringify(apprvUserData) //傳回原本的各簽核層級的設定值
	            },
	            success:function(data){     
	            	grid.trigger("reloadGrid",[{page:1}]);
	            	API.showMessage("報表改派已完成!");
	   	    	    //return;
	            }
			});
			//eDialog.dialog('close');
			
	    });
	  
	  
		function findDuplicates(arr) {
			  var len=arr.length, out=[],counts={};
			  for (var i=0;i<len;i++) {
			    var item = arr[i];
			    	counts[item] = counts[item] >= 1 ? counts[item] + 1 : 1;
			    if (counts[item] === 2) {
			      out.push(item);
			    }
			  }
	
			  return out;
	     }
	  
	  	//取得登入者員編及所屬單位,第1關的人員於下拉選單預設選取為登入者
	    function getMyUserId(){
			
			$.ajax({ 
				url : "../txn104031handler/getLoginUserId",
				data : {},
				async: false,
				success : function(data) {
					myUserId = data.loginUserId;
					myBranchId = data.loginUserUnitNo;
				}
			});
		}
	    
		/**
		 * 獲取群組下拉框
		 */
		function getInfoGrpList() {
			$.ajax({ 
				url : "../txn104031handler/getInfoGrpList",
				data : {userId : q_selUserId.val()},
				success : function(data) {
					//alert(JSON.stringify(data));
					grpNames = data.grpOps;
					grpPms = data.grpPms;
					
					ie6Exec(function(){
						q_selRptGrpId.setOptions(data.grpOps)
					});
					mselectMultiple(q_selRptGrpId);
					q_selRptGrpId.multiselect2("uncheckAll");
				}
			});
		}
		
		function mselect(select){
			select.multiselectfilter("destroy");
			select.multiselect2({
		    	selectedList: 4,
		    	multiple: false
		    }).multiselectfilter({
		    	label: "內含",
		    	placeholder: "輸入關鍵字" 
		    });
		}
		
		function mselectMultiple(select){
			select.multiselectfilter("destroy");
			select.multiselect2({
				selectedList: 4,
		    	multiple: true,
		    	searchable: true,		    	
		    	checkAllText : "全選",
		    	uncheckAllText : "取消全選"
		    }).multiselectfilter({
		    	label: "內含",
		    	placeholder: "輸入關鍵字" 
		    });
		}
		
		function ie6Exec(cmd){
			try {
				cmd();
			} catch(ex) {
			    setTimeout(function() {
			    	cmd();
			    },1);
			}
		}
		
		function sleep(milliseconds) {
			  var start = new Date().getTime();
			  for (var i = 0; i < 1e7; i++) {
			    if ((new Date().getTime() - start) > milliseconds){
			      break;
			    }
			  }
		}
		
	});
});