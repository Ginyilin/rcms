/* 
 * RptContentApprvDaoImpl.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.dao.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

import com.iisigroup.cap.dao.utils.ISearch;
import com.iisigroup.cap.model.Page;

import tw.com.hncb.rcms.dao.RcmsJpaDao;
import tw.com.hncb.rcms.dao.RptContentApprvDao;
import tw.com.hncb.rcms.jdbc.RcmsNamedJdbcTemplate;
import tw.com.hncb.rcms.model.RptContentApprv;
import tw.com.hncb.rcms.model.RptContentMasterPK;
import tw.com.hncb.rcms.model.VwRptContentApprvPDData;

/**
 * <pre>
 * 報表簽核設定檔(Table:RPT_CONTENT_APPRV)的DAO實作
 * </pre>
 * 
 * @since 2017-3-13
 * @author jeanlin
 * @version <ul>
 *          <li>2017-3-13,jeanlin,new
 *          </ul>
 */

@Repository
public class RptContentApprvDaoImpl extends RcmsJpaDao<RptContentApprv> implements
	RptContentApprvDao {

	private Log log = LogFactory.getLog(RptContentApprvDaoImpl.class);
	
	@Resource(name = "rcmsJdbcTemplate")
	private RcmsNamedJdbcTemplate jdbc;
	
	/**
	 * 依報表週期取得日期查詢參數值
	 * 
	 * @param dateStr
	 * @param rptCycle
	 * @return result
	 */
	public String getDateQueryParmsByRptCycle(String dateStr, String rptCycle) {
		if (dateStr == null) {
			return null;
		}
		String result = dateStr;
		if ("D".equals(rptCycle) || "T".equals(rptCycle)
				|| "W".equals(rptCycle) || "N".equals(rptCycle)) {
			// 日報D, 旬報T, 週報W
			result = dateStr;
		} else if ("S".equals(rptCycle) || "M".equals(rptCycle)
				|| "H".equals(rptCycle)) {
			// 季報S, 月報M, 半年報H
			logger.debug("季報S, 月報M, 半年報H : dateStr=" + dateStr);
			if (dateStr.length() >= 6) {
				result = dateStr.substring(0, 6);
			}
		} else if ("Y".equals(rptCycle)) {
			// 月報Y
			if (dateStr.length() >= 4) {
				result = dateStr.substring(0, 4);
			}

		}
		logger.debug("rptCycle=" + rptCycle + ", dateStr=" + dateStr
				+ " , getDateQueryParmsByRptCycle result dateStr=" + result);
		return result;
	}

	/**
	 * 取得結束日期
	 * 
	 * @param dateStr
	 * @return dateStr
	 */
	public String getDateEnd(String dateStr) {
		try {
			if (dateStr != null) {
				dateStr = String.valueOf(Integer.parseInt(dateStr) + 1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dateStr;
	}

	@Override
	public List<RptContentApprv> getBySqlCondition(List<String> infoGrpRptIds, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd, String sortColName, String sortOrder) {
		return null;
	}

	@Override
	public List<RptContentApprv> getBySqlCondition(List<String> infoGrpRptIds, String rptBranch, List<String> apprvStatus) {
		Map<String, Object> args = new HashMap<String, Object>();
		// 無任何報表權限 join table至少加一筆row 使得SQL與法成立
		if (infoGrpRptIds.isEmpty()) {
			infoGrpRptIds.add("");
		}
		args.put("infoGrpRptIdsArr", infoGrpRptIds);
		args.put("rptBranch", rptBranch);
		
		if (apprvStatus == null || apprvStatus.isEmpty()){
			apprvStatus = new ArrayList();
			apprvStatus.add("");
		}
		
		args.put("apprvStatus", apprvStatus);
		
		List<Map<String, Object>> rptList = jdbc.query("rptContentApprv.findRptData", args);
		List<RptContentApprv> vwRptList = new ArrayList<RptContentApprv>();
		for (Map<String, Object> row : rptList) {
			RptContentApprv r = new RptContentApprv();
			r.setId(((Long) row.get("id")).longValue());
			r.setRptId((String) row.get("rptId"));
			r.setRptName((String) row.get("rptName"));
			vwRptList.add(r);
		}
		return vwRptList;
	}
	
	
	/**
	 * 報表簽核流程設定
	 */
	@Override
	public Page<VwRptContentApprvPDData> getBySqlConditionSetting(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch, List<String> oldBranchIds, List<String> apprvStatus) {
		
		if (search == null) search = createSearchTemplete();
		int firstResult = search.getFirstResult();
		int maxResult = search.getMaxResults();
		logger.debug("firstResult=" + firstResult);
		logger.debug("maxResult=" + maxResult);
		
		String convertDS = null;
		String convertDE = null;
		try { // 日期格式轉換
			SimpleDateFormat formatterCSI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterESI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterCSO = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat formatterESO = new SimpleDateFormat("yyyy-MM-dd");
			if (convertTimeStart != null) {
				Date CS = formatterCSI.parse(convertTimeStart);
				convertDS = formatterCSO.format(CS) + " 00:00:00";
			}
			if (convertTimeEnd != null) {
				Date CE = formatterESI.parse(convertTimeEnd);
				convertDE = formatterESO.format(CE) + " 23:59:59";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}


		// 若報表週期未定義 則必須取得所有可能的日期參數
		String parmDdateS = getDateQueryParmsByRptCycle(rptDateBegin, "D");
		String parmMdateS = getDateQueryParmsByRptCycle(rptDateBegin, "M");
		String parmYdateS = getDateQueryParmsByRptCycle(rptDateBegin, "Y");
		String parmDdateE = getDateQueryParmsByRptCycle(rptDateEnd, "D");
		String parmMdateE = getDateQueryParmsByRptCycle(rptDateEnd, "M");
		String parmYdateE = getDateQueryParmsByRptCycle(rptDateEnd, "Y");
		Map<String, Object> args = new HashMap<String, Object>();

		logger.debug("infoGrpRptIds cnt=" + infoGrpRptIds.size());
		logger.debug("rptSeqno=" + rptSeqno);
		logger.debug("parmDdateS=" + parmDdateS);
		logger.debug("parmMdateS=" + parmMdateS);
		logger.debug("parmYdateS=" + parmYdateS);
		logger.debug("parmDdateE=" + parmDdateE);
		logger.debug("parmMdateE=" + parmMdateE);
		logger.debug("parmYdateE=" + parmYdateE);

		// 無任何報表權限 join table至少加一筆row 使得SQL與法成立
		if (infoGrpRptIds.isEmpty()) {
			infoGrpRptIds.add("");
		}
		args.put("infoGrpRptIdsArr", infoGrpRptIds);
		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptIdLike", "%" + rptId + "%");
		args.put("rptName", rptName);
		args.put("rptNameLike", "%" + rptName + "%");
		args.put("rptSeqno", rptSeqno);
		args.put("mustPrint", mustPrint);
		args.put("pd", pd);
		args.put("rptCycle", rptCycle);
		args.put("parmdateS", rptDateBegin);
		args.put("parmdateE", getDateEnd(rptDateEnd));
		args.put("parmDdateS", parmDdateS);
		args.put("parmMdateS", parmMdateS);
		args.put("parmYdateS", parmYdateS);
		args.put("parmDdateE", getDateEnd(parmDdateE));
		args.put("parmMdateE", getDateEnd(parmMdateE));
		args.put("parmYdateE", getDateEnd(parmYdateE));
		args.put("setUserId", setUserId);
		args.put("rptBranch", rptBranch);
		
		//被移管的舊單位清單
		args.put("oldBranchIds", oldBranchIds);
		
		args.put("convertTimeStart", convertDS);
		args.put("convertTimeEnd", convertDE);
		
		if (apprvStatus == null || apprvStatus.isEmpty()){
			apprvStatus = new ArrayList();
			apprvStatus.add("");
		}
		
		for(String s: apprvStatus){
			log.debug("getBySqlConditionSetting apprvStatus==="+s);
		}
		args.put("apprvStatus", apprvStatus);

		StringBuffer orderByCondition = new StringBuffer();
		Map<String, Boolean> orderMap = search.getOrderBy();
		if(orderMap != null) {
			Set<String> orderKeys = orderMap.keySet();
			//只取一個sidx
			for (String orderKey : orderKeys) {
				//key不包含.之前的
				String[] orderKeySplitArr = orderKey.split("\\.");
				String sidx = orderKeySplitArr[orderKeySplitArr.length - 1];
				orderByCondition.append(sidx);
				if (orderMap.get(orderKey)) {
					orderByCondition.append(" DESC");
				} else {
					orderByCondition.append(" ASC");
				}
				break;
			}
		}else {
			orderByCondition.append("case when v.SETUSERID=:setUserId then 1 when v.SETUSERID is null then 9999 else 2 end,v.SETUSERID, (days(current date) - days(date(v.CONVERTTIMESTART))-v.APPRVDAYS) desc ,v.CONVERTTIMESTART desc");
		}
		
		logger.debug("qry orderByCondition="+orderByCondition.toString());
		 

		logger.debug("104011 qry args="+args);
		//long ts = System.currentTimeMillis();
		List<Map<String, Object>> rptList = jdbc.queryPagingWithSorting("vwRptContentApprvPDData.findPDDataSetting", args, firstResult, 10, orderByCondition.toString());
		//
		//log.error("queryPagingWithSorting spent:"+(System.currentTimeMillis() - ts)+"ms");
		//ts = System.currentTimeMillis();
		
		List<VwRptContentApprvPDData> vwRptList = new ArrayList<VwRptContentApprvPDData>();
		for (Map<String, Object> row : rptList) {
			VwRptContentApprvPDData vwRpt = new VwRptContentApprvPDData();
			RptContentMasterPK vwPK = new RptContentMasterPK();
			vwRpt.setId(((Long) row.get("id")).longValue());
			vwPK.setRptId((String) row.get("rptId"));
			vwPK.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			vwPK.setIndexGrpId("1");
			vwPK.setRptDate((String) row.get("rptDate"));
			vwPK.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			vwRpt.setRptContentMasterPK(vwPK);
			vwRpt.setRptName((String) row.get("rptName"));
			vwRpt.setRptBranch((String)row.get("rptBranch"));
			vwRpt.setRptCycle((String) row.get("rptCycle"));
			vwRpt.setKeepYear(row.get("keepYear") !=null ? (Integer) row.get("keepYear") :0);//因本機測試資料有Null?
			vwRpt.setMustPrint((String) row.get("mustPrint"));
			vwRpt.setPd((String) row.get("pd"));
			vwRpt.setCrossUnit((String) row.get("crossUnit"));	   		//是否跨單位簽核
			vwRpt.setCrossDept((String) row.get("CROSSDEPT"));			//是否跨單位簽核Y時的跨單位depCode
			vwRpt.setGoverningDept((String) row.get("governingDept"));	//業管科別
			vwRpt.setApprvDays((Integer) row.get("apprvDays"));			//簽核期限天數
			vwRpt.setConvertTimeStart((Date) row.get("convertTimeStart"));
			vwRpt.setSetUserId((String) row.get("setUserId"));
			vwRpt.setApprvStatus((String) row.get("apprvStatus"));
			vwRpt.setApprvStep((String) row.get("apprvStep"));
			vwRpt.setApprvUser((String) row.get("apprvUser"));
			vwRpt.setOverdueDays((Integer)row.get("overdueDays"));
			vwRpt.setRptBranchName((String)row.get("RPTBRANCHNAME"));//簽核單位
			vwRpt.setCrossDeptName((String) row.get("CROSSDEPTNAME"));		
			
			//log.debug("getBySqlCondition vwRpt========================"+vwRpt.toString());
			vwRptList.add(vwRpt);
		}
		//
		//log.error("map to obj list spent:"+(System.currentTimeMillis() - ts)+"ms");
		//ts = System.currentTimeMillis();

		Page<VwRptContentApprvPDData> pageData = new Page<VwRptContentApprvPDData>(vwRptList,
				jdbc.queryForInt("vwRptContentApprvPDData.countPDDataSetting", args),
				search.getMaxResults(), search.getFirstResult());
		
		
		//
		//log.error("page spent:"+(System.currentTimeMillis() - ts)+"ms");
		//ts = System.currentTimeMillis();
		
		logger.debug("getBySqlConditionSetting rptList query cnt=" + rptList.size());
		return pageData;
	}
	

	/**
	 * 作廢重簽放行 - 查詢
	 * 簽核狀況查詢
	 */
	@Override
	public Page<VwRptContentApprvPDData> getBySqlCondition(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch, List<String> apprvStatus) {
		
		if (search == null) search = createSearchTemplete();
		int firstResult = search.getFirstResult();
		int maxResult = search.getMaxResults();
		logger.debug("firstResult=" + firstResult);
		logger.debug("maxResult=" + maxResult);
		
		String convertDS = null;
		String convertDE = null;
		try { // 日期格式轉換
			SimpleDateFormat formatterCSI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterESI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterCSO = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat formatterESO = new SimpleDateFormat("yyyy-MM-dd");
			if (convertTimeStart != null) {
				Date CS = formatterCSI.parse(convertTimeStart);
				convertDS = formatterCSO.format(CS) + " 00:00:00";
			}
			if (convertTimeEnd != null) {
				Date CE = formatterESI.parse(convertTimeEnd);
				convertDE = formatterESO.format(CE) + " 23:59:59";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		log.debug("convertDS=="+convertDS);
		log.debug("convertDE=="+convertDE);

		// 若報表週期未定義 則必須取得所有可能的日期參數
		String parmDdateS = getDateQueryParmsByRptCycle(rptDateBegin, "D");
		String parmMdateS = getDateQueryParmsByRptCycle(rptDateBegin, "M");
		String parmYdateS = getDateQueryParmsByRptCycle(rptDateBegin, "Y");
		String parmDdateE = getDateQueryParmsByRptCycle(rptDateEnd, "D");
		String parmMdateE = getDateQueryParmsByRptCycle(rptDateEnd, "M");
		String parmYdateE = getDateQueryParmsByRptCycle(rptDateEnd, "Y");
		Map<String, Object> args = new HashMap<String, Object>();

		logger.debug("infoGrpRptIds cnt=" + infoGrpRptIds.size());
		logger.debug("rptSeqno=" + rptSeqno);
		logger.debug("parmDdateS=" + parmDdateS);
		logger.debug("parmMdateS=" + parmMdateS);
		logger.debug("parmYdateS=" + parmYdateS);
		logger.debug("parmDdateE=" + parmDdateE);
		logger.debug("parmMdateE=" + parmMdateE);
		logger.debug("parmYdateE=" + parmYdateE);

		// 無任何報表權限 join table至少加一筆row 使得SQL與法成立
		if (infoGrpRptIds.isEmpty()) {
			infoGrpRptIds.add("");
		}
		args.put("infoGrpRptIdsArr", infoGrpRptIds);
		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptIdLike", "%" + rptId + "%");
		args.put("rptName", rptName);
		args.put("rptNameLike", "%" + rptName + "%");
		args.put("rptSeqno", rptSeqno);
		args.put("mustPrint", mustPrint);
		args.put("pd", pd);
		args.put("rptCycle", rptCycle);
		args.put("parmdateS", rptDateBegin);
		args.put("parmdateE", getDateEnd(rptDateEnd));
		args.put("parmDdateS", parmDdateS);
		args.put("parmMdateS", parmMdateS);
		args.put("parmYdateS", parmYdateS);
		args.put("parmDdateE", getDateEnd(parmDdateE));
		args.put("parmMdateE", getDateEnd(parmMdateE));
		args.put("parmYdateE", getDateEnd(parmYdateE));
		args.put("setUserId", setUserId);
		args.put("rptBranch", rptBranch);
		
		args.put("convertTimeStart", convertDS);
		args.put("convertTimeEnd", convertDE);
		
		log.debug("convertDS="+convertDS);
		log.debug("convertDE="+convertDE);
		
		if (apprvStatus == null || apprvStatus.isEmpty()){
			apprvStatus = new ArrayList();
			apprvStatus.add("");
		}
		
		for(String s: apprvStatus){
			log.debug("getBySqlCondition apprvStatus==="+s);
		}
		args.put("apprvStatus", apprvStatus);

		/*
		Map<String, Boolean> orderMap = search.getOrderBy();
		Set<String> orderKeys = orderMap.keySet();
		for (String orderKey : orderKeys) {
			// logger.debug("key ="+orderKey+", order="+orderMap.get(orderKey));
			String[] orderKeySplitArr = orderKey.split("\\.");
			String sidx = orderKeySplitArr[orderKeySplitArr.length - 1];
			// logger.debug("sidx="+sidx);
			args.put("sidx", "vwrptindex." + sidx);
			if (orderMap.get(orderKey)) {
				args.put("sord", "DESC");
			} else {
				args.put("sord", "ASC");
			}

			// logger.debug("query ====== sord ="+args.get("sord"));

			break;

		} */

		List<Map<String, Object>> rptList = jdbc.queryPaging("vwRptContentApprvPDData.findPDData", args, firstResult, 10);
		List<VwRptContentApprvPDData> vwRptList = new ArrayList<VwRptContentApprvPDData>();
		for (Map<String, Object> row : rptList) {
			VwRptContentApprvPDData vwRpt = new VwRptContentApprvPDData();
			RptContentMasterPK vwPK = new RptContentMasterPK();
			vwRpt.setId(((Long) row.get("id")).longValue());
			vwPK.setRptId((String) row.get("rptId"));
			vwPK.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			vwPK.setIndexGrpId("1");
			vwPK.setRptDate((String) row.get("rptDate"));
			vwPK.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			vwRpt.setRptContentMasterPK(vwPK);
			vwRpt.setRptName((String) row.get("rptName"));
			vwRpt.setRptBranch((String)row.get("rptBranch"));
			vwRpt.setRptCycle((String) row.get("rptCycle"));
			vwRpt.setKeepYear(row.get("keepYear") !=null ? (Integer) row.get("keepYear") :0);//因本機測試資料有Null?
			vwRpt.setMustPrint((String) row.get("mustPrint"));
			vwRpt.setPd((String) row.get("pd"));
			vwRpt.setCrossUnit((String) row.get("crossUnit"));	   		//是否跨單位簽核
			vwRpt.setCrossDept((String) row.get("CROSSDEPT"));			//是否跨單位簽核Y時的跨單位depCode
			vwRpt.setGoverningDept((String) row.get("governingDept"));	//業管科別
			vwRpt.setApprvDays((Integer) row.get("apprvDays"));			//簽核期限天數
			vwRpt.setConvertTimeStart((Date) row.get("convertTimeStart"));
			vwRpt.setSetUserId((String) row.get("setUserId"));
			vwRpt.setApprvStatus((String) row.get("apprvStatus"));
			vwRpt.setApprvStep((String) row.get("apprvStep"));
			vwRpt.setApprvUser((String) row.get("apprvUser"));
			vwRpt.setOverdueDays((Integer)row.get("overdueDays"));
			vwRpt.setRptBranchName((String)row.get("RPTBRANCHNAME"));//簽核單位
			
			if (vwRpt.getCrossDept()!=null && !vwRpt.getCrossDept().equals(""))
			vwRpt.setCrossDeptName(getDepName((String) row.get("CROSSDEPT")));
			vwRptList.add(vwRpt);
		}

		logger.debug("getBySqlCondition vwRptList query 0000000 cnt=" + vwRptList.size());
		
		Page<VwRptContentApprvPDData> pageData = new Page<VwRptContentApprvPDData>(vwRptList,
				jdbc.queryForInt("vwRptContentApprvPDData.countPDData", args),
				search.getMaxResults(), search.getFirstResult());
		logger.debug("getBySqlCondition rptList query cnt=" + rptList.size());
		return pageData;
	}
	
	
	private String getDepName(String depCode){
		String strDepName = "";
		Map args = new HashMap();
		args.put("depCode", depCode);
		Map<String, Object> result = jdbc.queryForMap("InfoDep.findDepNameByDepCode", args);
		if (result.get("depName") != null)
			strDepName = (String)result.get("depName");
		
		return strDepName;
		
		
		
	}
	

	/**
	 * 報表改派 - 查詢
	 */
	@Override
	public Page<VwRptContentApprvPDData> getBySqlCondition2(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch,List<String> apprvStatus) {
		
		if (search == null) search = createSearchTemplete();
		int firstResult = search.getFirstResult();
		int maxResult = search.getMaxResults();
		logger.debug("firstResult=" + firstResult);
		logger.debug("maxResult=" + maxResult);
		
		String convertDS = null;
		String convertDE = null;
		try { // 日期格式轉換
			SimpleDateFormat formatterCSI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterESI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterCSO = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat formatterESO = new SimpleDateFormat("yyyy-MM-dd");
			if (convertTimeStart != null) {
				Date CS = formatterCSI.parse(convertTimeStart);
				convertDS = formatterCSO.format(CS) + " 00:00:00";
			}
			if (convertTimeEnd != null) {
				Date CE = formatterESI.parse(convertTimeEnd);
				convertDE = formatterESO.format(CE) + " 23:59:59";
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("getBySqlCondition2 error:"+ e);
		}

		// 若報表週期未定義 則必須取得所有可能的日期參數
		String parmDdateS = getDateQueryParmsByRptCycle(rptDateBegin, "D");
		String parmMdateS = getDateQueryParmsByRptCycle(rptDateBegin, "M");
		String parmYdateS = getDateQueryParmsByRptCycle(rptDateBegin, "Y");
		String parmDdateE = getDateQueryParmsByRptCycle(rptDateEnd, "D");
		String parmMdateE = getDateQueryParmsByRptCycle(rptDateEnd, "M");
		String parmYdateE = getDateQueryParmsByRptCycle(rptDateEnd, "Y");
		Map<String, Object> args = new HashMap<String, Object>();

		logger.debug("infoGrpRptIds cnt=" + infoGrpRptIds.size());
		logger.debug("rptSeqno=" + rptSeqno);
		logger.debug("parmDdateS=" + parmDdateS);
		logger.debug("parmMdateS=" + parmMdateS);
		logger.debug("parmYdateS=" + parmYdateS);
		logger.debug("parmDdateE=" + parmDdateE);
		logger.debug("parmMdateE=" + parmMdateE);
		logger.debug("parmYdateE=" + parmYdateE);

		// 無任何報表權限 join table至少加一筆row 使得SQL與法成立
		if (infoGrpRptIds.isEmpty()) {
			infoGrpRptIds.add("");
		}
		args.put("infoGrpRptIdsArr", infoGrpRptIds);
		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptIdLike", "%" + rptId + "%");
		args.put("rptName", rptName);
		args.put("rptNameLike", "%" + rptName + "%");
		args.put("rptSeqno", rptSeqno);
		args.put("mustPrint", mustPrint);
		args.put("pd", pd);
		args.put("rptCycle", rptCycle);
		args.put("parmdateS", rptDateBegin);
		args.put("parmdateE", getDateEnd(rptDateEnd));
		args.put("parmDdateS", parmDdateS);
		args.put("parmMdateS", parmMdateS);
		args.put("parmYdateS", parmYdateS);
		args.put("parmDdateE", getDateEnd(parmDdateE));
		args.put("parmMdateE", getDateEnd(parmMdateE));
		args.put("parmYdateE", getDateEnd(parmYdateE));
		args.put("setUserId", setUserId);
		args.put("setDivisionId", rptBranch);
		args.put("rptBranch", rptBranch);
		
		args.put("convertTimeStart", convertDS);
		args.put("convertTimeEnd", convertDE);
		
		if (apprvStatus == null || apprvStatus.isEmpty()){
			apprvStatus = new ArrayList();
			apprvStatus.add("");
		}
		
		for(String s: apprvStatus){
			log.debug("getBySqlCondition apprvStatus==="+s);
		}
		args.put("apprvStatus", apprvStatus);

		/*
		Map<String, Boolean> orderMap = search.getOrderBy();
		Set<String> orderKeys = orderMap.keySet();
		for (String orderKey : orderKeys) {
			// logger.debug("key ="+orderKey+", order="+orderMap.get(orderKey));
			String[] orderKeySplitArr = orderKey.split("\\.");
			String sidx = orderKeySplitArr[orderKeySplitArr.length - 1];
			// logger.debug("sidx="+sidx);
			args.put("sidx", "vwrptindex." + sidx);
			if (orderMap.get(orderKey)) {
				args.put("sord", "DESC");
			} else {
				args.put("sord", "ASC");
			}

			// logger.debug("query ====== sord ="+args.get("sord"));

			break;

		} */

		List<Map<String, Object>> rptList = jdbc.queryPaging(
				"vwRptContentApprvPDData.findPDData2", args, firstResult, 10);
		List<VwRptContentApprvPDData> vwRptList = new ArrayList<VwRptContentApprvPDData>();
		for (Map<String, Object> row : rptList) {
			VwRptContentApprvPDData vwRpt = new VwRptContentApprvPDData();
			RptContentMasterPK vwPK = new RptContentMasterPK();
			vwRpt.setId(((Long) row.get("id")).longValue());
			vwPK.setRptId((String) row.get("rptId"));
			vwPK.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			vwPK.setIndexGrpId("1");
			vwPK.setRptDate((String) row.get("rptDate"));
			vwPK.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			vwRpt.setRptContentMasterPK(vwPK);
			vwRpt.setRptName((String) row.get("rptName"));
			vwRpt.setRptBranch((String)row.get("rptBranch"));
			vwRpt.setRptCycle((String) row.get("rptCycle"));
			vwRpt.setKeepYear(row.get("keepYear") !=null ? (Integer) row.get("keepYear") :0);//因本機測試資料有Null?
			vwRpt.setMustPrint((String) row.get("mustPrint"));
			vwRpt.setPd((String) row.get("pd"));
			vwRpt.setCrossUnit((String) row.get("crossUnit"));	   		//是否跨單位簽核
			vwRpt.setGoverningDept((String) row.get("governingDept"));	//業管科別
			vwRpt.setApprvDays((Integer) row.get("apprvDays"));			//簽核期限天數
			vwRpt.setConvertTimeStart((Date) row.get("convertTimeStart"));
			vwRpt.setSetUserId((String) row.get("setUserId"));
			vwRpt.setApprvStatus((String) row.get("apprvStatus"));
			vwRpt.setApprvStep((String) row.get("apprvStep"));
			vwRpt.setApprvUser((String) row.get("apprvUser"));
			vwRpt.setOverdueDays((Integer)row.get("overdueDays"));
			vwRpt.setRptBranchName((String)row.get("RPTBRANCHNAME"));//簽核單位
			log.debug("getBySqlCondition vwRpt========================"+vwRpt.toString());
			vwRptList.add(vwRpt);
		}

		Page<VwRptContentApprvPDData> pageData = new Page<VwRptContentApprvPDData>(vwRptList,
				jdbc.queryForInt("vwRptContentApprvPDData.countPDData", args),
				search.getMaxResults(), search.getFirstResult());
		logger.debug("getBySqlCondition rptList query cnt=" + rptList.size());
		return pageData;
	}
	
	/**
	 * 簽核狀況查詢(報表管理單位)
	 */
	@Override
	public Page<VwRptContentApprvPDData> getByGoverningDept(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch,List<String> apprvStatus,List<String> governingDept) {
		
		int firstResult = search.getFirstResult();
		int maxResult = search.getMaxResults();
		logger.debug("firstResult=" + firstResult);
		logger.debug("maxResult=" + maxResult);
		
		String convertDS = null;
		String convertDE = null;
		try { // 日期格式轉換
			SimpleDateFormat formatterCSI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterESI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterCSO = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat formatterESO = new SimpleDateFormat("yyyy-MM-dd");
			if (convertTimeStart != null) {
				Date CS = formatterCSI.parse(convertTimeStart);
				convertDS = formatterCSO.format(CS) + " 00:00:00";
			}
			if (convertTimeEnd != null) {
				Date CE = formatterESI.parse(convertTimeEnd);
				convertDE = formatterESO.format(CE) + " 23:59:59";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}


		// 若報表週期未定義 則必須取得所有可能的日期參數
		String parmDdateS = getDateQueryParmsByRptCycle(rptDateBegin, "D");
		String parmMdateS = getDateQueryParmsByRptCycle(rptDateBegin, "M");
		String parmYdateS = getDateQueryParmsByRptCycle(rptDateBegin, "Y");
		String parmDdateE = getDateQueryParmsByRptCycle(rptDateEnd, "D");
		String parmMdateE = getDateQueryParmsByRptCycle(rptDateEnd, "M");
		String parmYdateE = getDateQueryParmsByRptCycle(rptDateEnd, "Y");
		Map<String, Object> args = new HashMap<String, Object>();

		logger.debug("infoGrpRptIds cnt=" + infoGrpRptIds.size());
		logger.debug("rptSeqno=" + rptSeqno);
		logger.debug("parmDdateS=" + parmDdateS);
		logger.debug("parmMdateS=" + parmMdateS);
		logger.debug("parmYdateS=" + parmYdateS);
		logger.debug("parmDdateE=" + parmDdateE);
		logger.debug("parmMdateE=" + parmMdateE);
		logger.debug("parmYdateE=" + parmYdateE);

		// 無任何報表權限 join table至少加一筆row 使得SQL與法成立
		if (infoGrpRptIds.isEmpty()) {
			infoGrpRptIds.add("");
		}
		args.put("infoGrpRptIdsArr", infoGrpRptIds);
		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptIdLike", "%" + rptId + "%");
		args.put("rptName", rptName);
		args.put("rptNameLike", "%" + rptName + "%");
		args.put("rptSeqno", rptSeqno);
		args.put("mustPrint", mustPrint);
		args.put("pd", pd);
		args.put("rptCycle", rptCycle);
		args.put("parmdateS", rptDateBegin);
		args.put("parmdateE", getDateEnd(rptDateEnd));
		args.put("parmDdateS", parmDdateS);
		args.put("parmMdateS", parmMdateS);
		args.put("parmYdateS", parmYdateS);
		args.put("parmDdateE", getDateEnd(parmDdateE));
		args.put("parmMdateE", getDateEnd(parmMdateE));
		args.put("parmYdateE", getDateEnd(parmYdateE));
		args.put("setUserId", setUserId);
		args.put("rptBranch", rptBranch);
		
		args.put("convertTimeStart", convertDS);
		args.put("convertTimeEnd", convertDE);
		
		if (governingDept == null || governingDept.size()==0){
			governingDept = new ArrayList();
			governingDept.add("");
		} 
		
		args.put("governingDept", governingDept);
		
		/*for(String s: governingDept){
			log.debug("getBySqlCondition governingDept==="+s);
		}*/
		
		
		if (apprvStatus == null || apprvStatus.isEmpty()){
			apprvStatus = new ArrayList();
			apprvStatus.add("");
		}
		
		for(String s: apprvStatus){
			log.debug("getBySqlCondition apprvStatus==="+s);
		}
		args.put("apprvStatus", apprvStatus);

		/*
		Map<String, Boolean> orderMap = search.getOrderBy();
		Set<String> orderKeys = orderMap.keySet();
		for (String orderKey : orderKeys) {
			// logger.debug("key ="+orderKey+", order="+orderMap.get(orderKey));
			String[] orderKeySplitArr = orderKey.split("\\.");
			String sidx = orderKeySplitArr[orderKeySplitArr.length - 1];
			// logger.debug("sidx="+sidx);
			args.put("sidx", "vwrptindex." + sidx);
			if (orderMap.get(orderKey)) {
				args.put("sord", "DESC");
			} else {
				args.put("sord", "ASC");
			}

			// logger.debug("query ====== sord ="+args.get("sord"));

			break;

		} */

		List<Map<String, Object>> rptList = jdbc.queryPaging(
				"vwRptContentApprvPDData.findPDDataByGoverningDept", args, firstResult, 10);
		List<VwRptContentApprvPDData> vwRptList = new ArrayList<VwRptContentApprvPDData>();
		for (Map<String, Object> row : rptList) {
			VwRptContentApprvPDData vwRpt = new VwRptContentApprvPDData();
			RptContentMasterPK vwPK = new RptContentMasterPK();
			vwRpt.setId(((Long) row.get("id")).longValue());
			vwPK.setRptId((String) row.get("rptId"));
			vwPK.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			vwPK.setIndexGrpId("1");
			vwPK.setRptDate((String) row.get("rptDate"));
			vwPK.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			vwRpt.setRptContentMasterPK(vwPK);
			vwRpt.setRptName((String) row.get("rptName"));
			vwRpt.setRptBranch((String)row.get("rptBranch"));
			vwRpt.setRptCycle((String) row.get("rptCycle"));
			vwRpt.setKeepYear(row.get("keepYear") !=null ? (Integer) row.get("keepYear") :0);//因本機測試資料有Null?
			vwRpt.setMustPrint((String) row.get("mustPrint"));
			vwRpt.setPd((String) row.get("pd"));
			vwRpt.setCrossUnit((String) row.get("crossUnit"));	   		//是否跨單位簽核
			vwRpt.setGoverningDept((String) row.get("governingDept"));	//業管科別
			vwRpt.setApprvDays((Integer) row.get("apprvDays"));			//簽核期限天數
			vwRpt.setConvertTimeStart((Date) row.get("convertTimeStart"));
			vwRpt.setSetUserId((String) row.get("setUserId"));
			vwRpt.setApprvStatus((String) row.get("apprvStatus"));
			vwRpt.setApprvStep((String) row.get("apprvStep"));
			vwRpt.setApprvUser((String) row.get("apprvUser"));
			vwRpt.setOverdueDays((Integer)row.get("overdueDays"));
			vwRpt.setRptBranchName((String)row.get("RPTBRANCHNAME"));//簽核單位
			
			if (vwRpt.getCrossDept()!=null && !vwRpt.getCrossDept().equals(""))
				vwRpt.setCrossDeptName(getDepName((String) row.get("CROSSDEPT")));
			
			//vwRpt.setCrossDeptName((String)row.get("crossDeptName"));//跨單位簽核的第二段流程的單位名稱
			vwRptList.add(vwRpt);
		}

		Page<VwRptContentApprvPDData> pageData = new Page<VwRptContentApprvPDData>(vwRptList,
				jdbc.queryForInt("vwRptContentApprvPDData.countPDDataByGoverningDept", args),
				search.getMaxResults(), search.getFirstResult());
		logger.debug("rptList query cnt=" + rptList.size());
		return pageData;
	}
	
	/**
	 * 儲存或更新RptContentApprvUser
	 * 
	 * @param o 報表簽核人員設定檔
	 * 			 
	 */
	@Override
	public void saveOrUpdate(RptContentApprv o){
		merge(o);
	}
	
	@Override
	public RptContentApprv getOneBySqlCondition(String rptId,int rptSeqno,String rptDate,int rptVersion,String rptBranch,String convertTimeStart){
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("rptId", rptId);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptVersion", rptVersion);
		args.put("rptBranch", rptBranch);
		args.put("convertTimeStart", convertTimeStart);

		List<Map<String, Object>> rptList = jdbc.query("rptContentApprv.getOneBySqlCondition", args);
		log.debug("getOneBySqlCondition rptList cnt="+rptList.size());
		for (Map<String, Object> row : rptList) {
			RptContentApprv o = new RptContentApprv();
			o.setId(((Long) row.get("id")).longValue());
			o.setRptId((String) row.get("rptId"));
			o.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			o.setIndexGrpId("1");
			o.setRptDate((String) row.get("rptDate"));
			o.setRptSeqno(((BigDecimal) row.get("rptSeqno")));
			o.setApprvStatus((String) row.get("apprvStatus"));
			o.setApprvStep((String) row.get("apprvStep"));
			o.setConvertTimeStart((Date) row.get("convertTimeStart"));
			o.setConvertTimeEnd((Date) row.get("convertTimeEnd"));
			o.setRptBranch((String) row.get("rptBranch"));
			o.setCreateTime((Date)row.get("createTime"));
			o.setRptCycle((String)row.get("rptCycle"));
			o.setMustPrint((String)row.get("mustPrint"));
			o.setIndexGrpId((String)row.get("indexGrpId"));
			o.setSetUserId((String)row.get("setUserId"));
			o.setSetDivisionId((String)row.get("setDivisionId"));		
			o.setRptName((String)row.get("rptName"));
			o.setCreator((String)row.get("creator"));
			o.setCreateTime((Date)row.get("createTime"));
			o.setApprvUser((String)row.get("apprvUser"));
			o.setCrossDept((String)row.get("crossDept"));					//跨單位簽核的第二段流程的單位代號
			o.setCrossDeptSetUserId((String)row.get("crossDeptSetUserId")); //跨單位簽核的第二段流程的設定經辦員編(即第一段流程的最後一關)
			return o;
		}
		return null;
	}
	
	/**
	 * 查詢作廢待簽核status=4的資料筆數
	 * @param unitNo
	 * @return 筆數
	 */
	@Override
	public int countInvalid(String rptBranch){
		int cnt = 0;
		try {
			Map<String, Object> args = new HashMap<String, Object>();
			args.put("rptBranch", rptBranch);
			args.put("apprvStatus", "4");
			cnt = jdbc.queryForInt("RptContentApprv.countInvalid", args);
			
		} catch (EmptyResultDataAccessException e1) {
			log.error("countInvalid EmptyResultDataAccessException:" + e1.getMessage());
			return cnt;
		} catch (Exception e) {
			log.error("countInvalid Exception:" + e.getMessage());
		}
		
		return cnt;

	}
	
	/**
	 * 依員編查詢作廢待簽核status=4的資料筆數,須為單位主管RoldId in ('R004','R009','R010','R111')
	 * @param unitNo
	 * @return 筆數
	 */
	@Override
	public int countInvalidByUser(String empId){
		int cnt = 0;
		try {
			Map<String, Object> args = new HashMap<String, Object>();
			args.put("empId", empId);
			cnt = jdbc.queryForInt("RptContentApprv.countInvalidByUser", args);
		} catch (EmptyResultDataAccessException e1) {
			log.error("countInvalidByUser EmptyResultDataAccessException empId:" + empId +",error:" + e1.getMessage());
			cnt = 0;
		} catch (Exception e) {
			log.error("countInvalidByUser Exception:" + e.getMessage());
			cnt = 0;
		}
		
		log.debug("countInvalidByUser empId="+empId+",cnt="+cnt);

		return cnt;

	}

	/**
	 * 跨單位簽核 - 找出設定的單位和跨單位的單位代號
	 * @return 設定的單位和跨單位的單位代號
	 */
	@Override
	public String getSetDivisionIdByCrossDept(String rptId,int rptSeqno,String rptDate,int rptVersion,String crossDept,String convertTimeStart){
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("rptId", rptId);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptVersion", rptVersion);
		args.put("crossDept", crossDept);
		args.put("convertTimeStart", convertTimeStart);

		List<Map<String, Object>> rptList = jdbc.query("rptContentApprv.getSetDivisionIdByCrossDept", args);
		log.debug("getSetDivisionIdByCrossDept rptList cnt="+rptList.size());
		String strSetDivisonId = "";
		for (Map<String, Object> row : rptList) {
			RptContentApprv o = new RptContentApprv();
			o.setId(((Long) row.get("id")).longValue());
			strSetDivisonId = (String)row.get("setDivisionId");
			log.debug("getSetDivisionIdByCrossDept strSetDivisonId:"+strSetDivisonId);
		}
		return strSetDivisonId;
	}
	
	/**
	 * 依員工編號查詢待設定(報表簽核流程設定,含非跨單位及跨單位)件數
	 * @param empId
	 * @return 件數
	 */
	@Override
	public int getToSettingCnt(String empId){
		int cntAll = 0;
		int cnt = 0;
		int cntCrossUnit = 0;
		try {
			Map<String, Object> args = new HashMap<String, Object>();
			args.put("empId", empId);

			try {
				cnt = jdbc.queryForInt("RptContentApprv.qry0", args);
			} catch (EmptyResultDataAccessException e1) {
				logger.error("getToSettingCnt EmptyResultDataAccessException e1:" + e1.getMessage());
				cnt = 0;
			}
			try {
				cntCrossUnit = jdbc.queryForInt("RptContentApprv.qry5", args);
			} catch (EmptyResultDataAccessException e2) {
				logger.error("getToSettingCnt EmptyResultDataAccessException e2:" + e2.getMessage());
				cntCrossUnit = 0;
			}

			log.error("getToSettingCnt empId:" + empId + "cnt=" + cnt + ",cntCrossUnit=" + cntCrossUnit);
			cntAll = cnt + cntCrossUnit;

		} catch (Exception e) {
			log.error("getToSettingCnt Exception:" + e.getMessage());
		}

		return cntAll;
		
	}

	/**
	 * 依員編查詢是否有任何簽核相關資料
	 * @param empId
	 * @return 件數
	 */
	@Override 
	public int getExistApprvDataCnt(String empId){
		int cnt = 0;
		try {
			Map<String, Object> args = new HashMap<String, Object>();
			args.put("empId", empId);
			cnt = jdbc.queryForInt("RptContentApprv.countByUser", args);
		} catch (EmptyResultDataAccessException e1) {
			logger.error("getExistApprvDataCnt EmptyResultDataAccessException e1:" + e1.getMessage());
			cnt = 0;
		} catch (Exception e) {
			log.error("getExistApprvDataCnt Exception:" + e.getMessage());
			cnt = 0;
		}
		
		return cnt;
	}
	
	/**
	 * 查詢簽核單狀態
	 * @param search ISearch
	 * @param rptId
	 * @param rptBranch
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param qryType
	 * @return Page<VwRptContentApprvPDData>
	 */
	@Override
	public Page<VwRptContentApprvPDData> getCaseListBySqlCondition(ISearch search, String rptId, String rptBranch, String rptDateBegin,
			String rptDateEnd, String qryType){
		Map<String, Object> args = new HashMap<String, Object>();
		List<Map<String, Object>> rptList = new ArrayList<Map<String, Object>>();
		if("ERR_USER".equalsIgnoreCase(qryType)) {
			//find the error type master
			rptList = jdbc.queryPaging("vwRptContentApprvPDData.findErrorCaseList", args, search.getFirstResult(), search.getMaxResults());
			
		}else if("ERR_HIS".equalsIgnoreCase(qryType)) {
			//find the error type master
			rptList = jdbc.queryPaging("vwRptContentApprvPDData.findErrorCaseList", args, search.getFirstResult(), search.getMaxResults());
			
		}else if("ERR_M".equalsIgnoreCase(qryType)) {
			//find the error type master
			rptList = jdbc.queryPaging("vwRptContentApprvPDData.findErrorCaseList", args, search.getFirstResult(), search.getMaxResults());
			
		}
		return null;
	}
	
}
