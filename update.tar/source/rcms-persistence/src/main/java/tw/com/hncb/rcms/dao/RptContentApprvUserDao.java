/* 
 * RptContentApprvUserDao.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.dao;

import java.util.Date;
import java.util.List;

import com.iisigroup.cap.dao.IGenericDao;
import com.iisigroup.cap.dao.utils.ISearch;
import com.iisigroup.cap.model.Page;

import tw.com.hncb.rcms.model.RptContentApprvUser;
import tw.com.hncb.rcms.model.VwRptContentApprvUserPDData;

/**
 * <pre>
 * 報表簽核人員設定檔[TABLE:RPT_CONTENT_APPRV_USER]之Dao 介面
 * </pre>
 * 
 * @since 2017/3/13
 * @author jeanlin
 * @version <ul>
 *          <li>2017/3/13,jeanlin,new
 *          </ul>
 */
public interface RptContentApprvUserDao extends IGenericDao<RptContentApprvUser> {
	
	/**
	 * 儲存或更新RptContentApprvUser
	 * 
	 * @param o 報表簽核人員設定檔
	 * 			 
	 */
	void saveOrUpdate(RptContentApprvUser o);

	/**
	 * 刪除RptContentApprvUser
	 * 
	 * @param o 報表簽核人員設定檔
	 */
	void delete(RptContentApprvUser o);
	
	
	/**
	 * 儲存RptContentApprvUser
	 * 
	 * @param o 報表簽核人員設定檔
	 * 			 
	 */
	void insert(RptContentApprvUser o);
	
	/**
	 * 根據SQL的搜尋條件查詢RptContentApprv
	 * 
	 * @param search
	 * 			ISearch
	 * @param rptId
	 * 			報表代號
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptName
	 * 			報表名稱
	 * @param rptSeqno
	 * 			報表序號
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @return Page<VwRptContentApprvUserPDData>
	 */
	Page<VwRptContentApprvUserPDData> getBySqlCondition(ISearch search,
			String rptId, List<String> infoGrpRptIds, String rptName,
			int rptSeqno, String rptCycle, String mustPrint, String pd,
			String rptDateBegin, String rptDateEnd,String setUserId,String isApprv,String rptBranch, List<String> oldBranchIds, String convertDateStart,String convertDateEnd);
	
	/**
	 * 計算待簽核件數
	 * @param search
	 * @param rptId
	 * @param infoGrpRptIds
	 * @param rptName
	 * @param rptSeqno
	 * @param rptCycle
	 * @param mustPrint
	 * @param pd
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param apprvUserId
	 * @param isApprv
	 * @param rptBranch
	 * @param oldBranchIds
	 * @param convertDateStart
	 * @param convertDateEnd
	 * @return 待簽核件數
	 */
	int countBySqlCondition(String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String rptDateBegin,
			String rptDateEnd,String apprvUserId,String isApprv,String rptBranch, List<String> oldBranchIds,String convertDateStart,String convertDateEnd);
	
	/**
	 * 根據SQL的搜尋條件查詢View:VW_RPT_CONTENT_APPRV_PDDATA 
	 * 
	 * @param search
	 * 			ISearch
	 * @param rptId
	 * 			報表代號
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptName
	 * 			報表名稱
	 * @param rptSeqno
	 * 			報表序號
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @return List<VwRptContentApprvUserPDData>
	 */
	List<VwRptContentApprvUserPDData> getAllBySqlCondition(ISearch search,
			String rptId, List<String> infoGrpRptIds, String rptName,
			int rptSeqno, String rptCycle, String mustPrint, String pd,
			String rptDateBegin, String rptDateEnd,String setUserId);
	
	/**
	 * 根據SQL的搜尋條件查詢RptContentApprv
	 * @param rptId
	 * @param rptSeqno
	 * @param rptDate
	 * @param rptVersion
	 * @param branch
	 * @return List<RptContentApprvUser>
	 */
	List<RptContentApprvUser> getBySqlCondition(String rptId,int rptSeqno,  String rptDate ,int rptVersion,String branch);
	
	/**
	 * 根據SQL的搜尋條件查詢單筆 RptContentApprv
	 * @param rptId
	 * @param rptSeqno
	 * @param rptDate
	 * @param rptVersion
	 * @param branch
	 * @param apprvStep
	 * @param apprvUser
	 * @return RptContentApprvUser
	 */
	RptContentApprvUser getOneBySqlCondition(String rptId,int rptSeqno,  String rptDate ,int rptVersion,String branch,String apprvStep,String apprvUser);
	
	/**
	 * 根據SQL 更新單筆 RptContentApprv
	 * @param rptId
	 * @param rptSeqno
	 * @param rptDate
	 * @param rptVersion
	 * @param branch
	 * @param apprvStep
	 * @param apprvUser
	 * @return 異動筆數
	 */
	int updateBySqlCondition(String rptId, int rptSeqno, String rptDate, int rptVersion, String branch,String apprvStep, String apprvUser);
	
	/**
	 * 依pk修改單筆簽核人員設定資料 
	 * @param id table RptContentApprvUser's pk
	 * @param apprvStatus 簽核狀態
	 * @param updateTime 修改時間
	 * @param updater 修改人員員編
	 * @param isApprove Y/N
	 * @return 資料異動筆數
	 */
	int updateById(Long id ,String apprvStatus,Date updateTime,String updater,String isApprove);
	
	/**
	 * 依pk修改單筆簽核人員設定資料 
	 * @param id table RptContentApprvUser's pk
	 * @param apprvStatus 簽核狀態
	 * @param updateTime 修改時間
	 * @param updater 修改人員員編
	 * @param isApprove Y/N
	 * @param apprvStep 簽核層級(1...End)
	 * @return 資料異動筆數
	 */
	int updateById(Long id ,String apprvStatus,Date updateTime,String updater,String isApprv,String apprvStep);
	
	/** 
	 * 依報表的收檔日期(起)desc排序查出多筆簽核人員設定資料
	 * 用以查詢出該報表的最近收檔起日
	 * @param rptId 報表代號
	 * @param rptBranch 分行別
	 * @param userBranch 查詢人員所屬單位代號	
	 * @return List<RptContentApprvUser>
	 */
	List<RptContentApprvUser> getLastRptContentApprvUser(String rptId, String rptBranch, String userBranch);
	
	/**
	 * 依報表最近收檔日期(起)查出的簽核人員設定資料
	 * for 報表簽核人員設定功能須帶山上一次的簽核人員設定資料
	 * @param rptId 報表代號
	 * @param rptVersion 報表版本
	 * @param rptSeqno 報表序號
	 * @param rptDate 報表日期
	 * @param rptBranch 分行表
	 * @param convertTimeStart 收檔日期(起)
	 * @return List<RptContentApprvUser>
	 */
	List<RptContentApprvUser> getLastestByConvertTimeStart(String rptId, String rptVersion, int rptSeqno, String rptDate, String rptBranch,String convertTimeStart);
	
	/**
	 *  跨單位簽核 - 依第二段流程的經辦的部門depCode找出已設定的簽核人員資料
	 * @param rptId
	 * @param rptVersion
	 * @param rptSeqno
	 * @param rptDate
	 * @param crossDept
	 * @param convertTimeStart
	 * @return List<RptContentApprvUser>
	 */
	List<RptContentApprvUser> getRptContentApprvUserCrossUnit(String rptId, String rptVersion, int rptSeqno, String rptDate, 
			String rptBranch, List<String> rptBranches,String convertTimeStart);
		
	/**
	 * 整批改派(依簽核人員) 若查詢人員為預設經辦或總務,依簽核人員查出未簽核資料
	 * @param search
	 * @param rptId
	 * @param infoGrpRptIds
	 * @param rptName
	 * @param rptSeqno
	 * @param rptCycle
	 * @param mustPrint
	 * @param pd
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param apprvUserId 欲查詢的下拉選單選取的簽核人員
	 * @param isApprv
	 * @param empId 登入人員的員編
	 * @return Page<VwRptContentApprvUserPDData>
	 */
	Page<VwRptContentApprvUserPDData> getBySqlConditionAllApprvUser(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String apprvUserId,String isApprv,String empId);
	
	/**
	 * 整批改派(依單位異動人員) 查詢
	 * @param search
	 * @param rptId 報表代號
	 * @param infoGrpRptIds
	 * @param rptName 報表名稱
	 * @param rptSeqno 報表序號
	 * @param rptCycle 報表周期
	 * @param mustPrint 是否必印 (Y/N)
	 * @param pd 含個資資料 (Y/N)
	 * @param rptDateBegin 報表日期(起)
	 * @param rptDateEnd 報表日期(迄)
	 * @param apprvUserId 簽核人員員編
	 * @param isApprv 是否已簽(Y/N)
	 * @param unitNo 查詢人員所屬單位
	 * @return Page<VwRptContentApprvUserPDData>
	 */
	Page<VwRptContentApprvUserPDData> getBySqlConditionAllApprvUserByUnitNo(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String apprvUserId,String isApprv, String unitNo);
	
	/**
	 * 簽核狀況查詢 - 查該報表之待簽人員
	 * @param rptId 報表代號
	 * @param rptSeqno 報表序號
	 * @param rptDate 報表日期
	 * @param rptVersion 報表版本
	 * @param rptBranch 分行別
	 * @param currentApprvStep 欲查詢的簽核層級(1...End)
	 * @return List<RptContentApprvUser> 簽核人員設定資料
	 */
	List<RptContentApprvUser> getToApprvUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String currentApprvStep);
	
	/**
	 * 整批改派(依單位異動人員) - 查詢人員若為預設經辦或總務,查出單位有異動或離職日有值的人員資料
	 * @param rptBranch 查詢人員的單位代號
	 * @param empId 查詢人員的員編
	 * @return List<RptContentApprvUser>
	 */
	List<RptContentApprvUser> getToApprvUsersByUnit(String rptBranch,String empId);
	
	/**
	 * 依SQL查詢條件查詢待簽核人數
	 * @param rptId
	 * @param rptSeqno
	 * @param rptDate
	 * @param rptVersion
	 * @param rptBranch
	 * @param currentApprvStep
	 * @return 待簽核人數
	 */
	int countToApprvUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String currentApprvStep);
	
	/**
	 * 依SQL查詢條件查詢刪除Table:RPT_CONTENT_APPRV_USER
	 * @param rptId
	 * @param rptSeqno
	 * @param rptDate
	 * @param rptVersion
	 * @param rptBranch
	 * @param convertTimeStart
	 * @param apprvUserIds
	 * @return 資料刪除筆數
	 */
	int deleteUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String convertTimeStart,List<String> apprvUserIds);
	
	/**
	 * 刪除原本於RptContentApprvUser 未簽核(isApprv=N)的設定資料
	 * @param rptId 報表代號
	 * @param rptSeqno 報表序號
	 * @param rptDate 報表日期
	 * @param rptVersion 報表版本
	 * @param rptBranch 報表分行
	 * @param convertTimeStart 收檔日期(起)
	 * @return 資料刪除筆數
	 */
	int deleteUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String convertTimeStart);
	
	/**
	 * 查詢該報表下一個待簽的簽核層級
	 * @param rptId 報表代號
	 * @param rptSeqno 報表序號
	 * @param rptDate 報表日期
	 * @param rptVersion 報表版本
	 * @param rptBranch 報表分行
	 * @param convertTimeStart 收檔日期(起)
	 * @return 簽核層級
	 */
	String getMinApprvStep(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String convertTimeStart);
	

	/**
	 * 查詢RptContentApprvUser裡設定的人員(isApprv=N)單位有異動的筆數
	 * @param empId 登入人員員編
	 * @return 筆數
	 */
	int countToApprvByUnitChange(String empId);
	
	/**
	 * 依員編查詢待簽核筆數(含簽核狀態為簽核中2及退回3)
	 * @param apprvUser
	 * @return 筆數
	 */
	int countToApprv(String apprvUser);
	
	/**
	 * 依員編查詢目前有代理的待簽核筆數(簽核狀態為2簽核中)
	 * @param apprvUser
	 * @return 代理的待簽核筆數
	 */
	int countToApprvDeputy(String deputyUserId);
	
	/**
	 * 依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
	 * 更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId masterApprvStep
	 * 
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param masterId
	 * @param masterApprvStatus
	 * @param croddDept
	 * @param crossDeptSetUserId
	 * @param masterApprvStep
	 */
	void updateMasterColumnsByKey(String rptId, int rptVersion, String rptDate, int rptSeqno, String rptBranch, long masterId, String masterApprvStatus, String croddDept, String crossDeptSetUserId, String masterApprvStep);
}
