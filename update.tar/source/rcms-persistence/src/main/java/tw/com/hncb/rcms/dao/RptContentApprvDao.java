/* 
 * RptContentApprvDao.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.dao;

import java.util.List;

import com.iisigroup.cap.dao.IGenericDao;
import com.iisigroup.cap.dao.utils.ISearch;
import com.iisigroup.cap.model.Page;

import tw.com.hncb.rcms.model.RptContentApprv;
import tw.com.hncb.rcms.model.VwRptContentApprvPDData;

/**
 * <pre>
 * 報表簽核設定檔之Dao介面
 * </pre>
 * 
 * @since 2017/3/13
 * @author jeanlin
 * @version <ul>
 *          <li>2017/3/13,jeanlin,new
 *          </ul>
 */
public interface RptContentApprvDao extends IGenericDao<RptContentApprv> {

	/**
	 * 根據SQL的搜尋條件查詢RptContentApprv
	 * 
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @param sortColName
	 * 			列數名稱
	 * @param sortOrder
	 * 			排序
	 * @return List<VwRptIndexPDData>
	 */
	List<RptContentApprv> getBySqlCondition(
			List<String> infoGrpRptIds, String rptCycle, String mustPrint,
			String pd, String rptDateBegin, String rptDateEnd,
			String sortColName, String sortOrder);
	/**
	 * 根據SQL的搜尋條件查詢VwRptIndexPDData
	 * 
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @param sortColName
	 * 			列數名稱
	 * @param sortOrder
	 * 			排序
	 * @param convertDateStart
	 * 			收檔日期 起
	 * @param convertDateEnd
	 * 			收檔日期 迄
	 * @return List<VwRptIndexPDData>
	 */
	
	List<RptContentApprv> getBySqlCondition(List<String> infoGrpRptIds, String rptBranch, List<String> apprvStatus);
	
	/**
	 * 根據SQL的搜尋條件查詢RptContentApprv
	 * 
	 * @param search
	 * 			ISearch
	 * @param rptId
	 * 			報表代號
	 * @param infoGrpRptIds
	 * 			使用者所有群組的所有報表
	 * @param rptName
	 * 			報表名稱
	 * @param rptSeqno
	 * 			報表序號
	 * @param rptCycle
	 * 			報表週期
	 * @param mustPrint
	 * 			必印註記
	 * @param pd
	 * 			個資註記
	 * @param rptDateBegin
	 * 			記錄日期 起
	 * @param rptDateEnd
	 * 			記錄日期 迄
	 * @return List<VwRptIndexPDData>
	 */
	Page<VwRptContentApprvPDData> getBySqlCondition(ISearch search,
			String rptId, List<String> infoGrpRptIds, String rptName,
			int rptSeqno, String rptCycle, String mustPrint, String pd,
			String rptDateBegin, String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch, List<String> apprvStatus);
	
	/**
	 * 依查詢條件查詢報表簽核流程設定資料
	 * @param search
	 * @param rptId
	 * @param infoGrpRptIds
	 * @param rptName
	 * @param rptSeqno
	 * @param rptCycle
	 * @param mustPrint
	 * @param pd
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param convertTimeStart
	 * @param convertTimeEnd
	 * @param setUserId
	 * @param rptBranch
	 * @param oldBranchIds
	 * @param apprvStatus
	 * @return Page<VwRptContentApprvPDData>
	 */
	Page<VwRptContentApprvPDData> getBySqlConditionSetting(ISearch search,
			String rptId, List<String> infoGrpRptIds, String rptName,
			int rptSeqno, String rptCycle, String mustPrint, String pd,
			String rptDateBegin, String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch, List<String> oldBranchIds, List<String> apprvStatus);
	/**
	 * 目前沒用到
	 * @param search
	 * @param rptId
	 * @param infoGrpRptIds
	 * @param rptName
	 * @param rptSeqno
	 * @param rptCycle
	 * @param mustPrint
	 * @param pd
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param convertTimeStart
	 * @param convertTimeEnd
	 * @param setUserId
	 * @param rptBranch
	 * @param apprvStatus
	 * @param governingDepts
	 * @return Page<VwRptContentApprvPDData>
	 */
	Page<VwRptContentApprvPDData> getByGoverningDept(ISearch search,
			String rptId, List<String> infoGrpRptIds, String rptName,
			int rptSeqno, String rptCycle, String mustPrint, String pd,
			String rptDateBegin, String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch,List<String> apprvStatus,List<String> governingDepts);
	
	
	/**
	 * 報表改派查詢
	 * 根據SQL的搜尋條件查詢VwRptIndexPDData
	 * @param search
	 * @param rptId 報表代號
	 * @param infoGrpRptIds 使用者所有群組的所有報表
	 * @param rptName 報表名稱
	 * @param rptSeqno 報表序號
	 * @param rptCycle 報表週期
	 * @param mustPrint 必印註記
	 * @param pd 個資註記
	 * @param rptDateBegin 報表日期 起
	 * @param rptDateEnd 報表日期 迄
	 * @param convertTimeStart 收檔日期 起
	 * @param convertTimeEnd 收檔日期 迄
	 * @param setUserId
	 * @param rptBranch
	 * @param apprvStatus
	 * @return Page<VwRptContentApprvPDData>
	 */
	Page<VwRptContentApprvPDData> getBySqlCondition2(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String convertTimeStart,String convertTimeEnd,String setUserId,String rptBranch,List<String> apprvStatus);
	/**
	 * 儲存或更新RptContentApprvUser
	 * 
	 * @param o 報表簽核人員設定檔
	 * 			 
	 */
	void saveOrUpdate(RptContentApprv o);
	
	/**
	 * 依查詢條件查詢特定一筆 簽核人員設定資料
	 * @param rptId 報表代號
	 * @param rptSeqno 報表序號
	 * @param rptDate 報表日期
	 * @param rptVersion 報表版本
	 * @param branch 分行別
	 * @param apprvStep 欲查詢的簽核層級(1...End)
	 * @param apprvUser 簽核人員員編
	 * @return RptContentApprvUser
	 */
	RptContentApprv getOneBySqlCondition(String rptId,int rptSeqno,String rptDate,int rptVersion,String rptBranch,String convertTimeStart);
	
	/**
	 * 查詢作廢待簽核status=4的資料筆數
	 * @param unitNo
	 * @return 筆數
	 */
	int countInvalid(String unitNo);
	

	/**
	 * 依員工編號查詢作廢待簽核status=4的資料筆數
	 * @param unitNo 
	 * @return 筆數
	 */
	int countInvalidByUser(String empId);
	
	/**
	 * 跨單位簽核 - 找出設定的單位和跨單位的單位代號
	 * @param rptId
	 * @param rptSeqno
	 * @param rptDate
	 * @param rptVersion
	 * @param crossDept
	 * @return 設定的單位和跨單位的單位代號
	 */
	String getSetDivisionIdByCrossDept(String rptId,int rptSeqno,String rptDate,int rptVersion,String crossDept,String convertTimeStart);
	
	/**
	 * 依員工編號查詢待設定(報表簽核流程設定,含非跨單位及跨單位)件數
	 * @param empId 員工編號
	 * @return 依員工編號查詢待設定(報表簽核流程設定,含非跨單位及跨單位)件數
	 */
	int getToSettingCnt(String empId);
	
	/**
	 * 依員編查詢是否有任何簽核相關資料
	 * @param empId
	 * @return 依員編查詢是否有任何簽核相關資料件數
	 */
	int getExistApprvDataCnt(String empId);
	
	/**
	 * 查詢簽核單狀態
	 * @param search ISearch
	 * @param rptId
	 * @param rptBranch
	 * @param rptDateBegin
	 * @param rptDateEnd
	 * @param qryType
	 * @return Page<VwRptContentApprvPDData>
	 */
	Page<VwRptContentApprvPDData> getCaseListBySqlCondition(ISearch search, String rptId, String rptBranch, String rptDateBegin,
			String rptDateEnd, String qryType);
}
