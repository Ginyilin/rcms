/* 
 * RptContentApprvUserDaoImpl.java
 * 
 * Copyright (c) 2009-2013 International Integrated System, Inc. 
 * All Rights Reserved.
 * 
 * Licensed Materials - Property of International Integrated System, Inc.
 * 
 * This software is confidential and proprietary information of 
 * International Integrated System, Inc. (&quot;Confidential Information&quot;).
 */
package tw.com.hncb.rcms.dao.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

import com.iisigroup.cap.dao.utils.ISearch;
import com.iisigroup.cap.model.Page;

import tw.com.hncb.rcms.dao.RcmsJpaDao;
import tw.com.hncb.rcms.dao.RptContentApprvUserDao;
import tw.com.hncb.rcms.jdbc.RcmsNamedJdbcTemplate;
import tw.com.hncb.rcms.model.RptContentApprvUser;
import tw.com.hncb.rcms.model.RptContentMasterPK;
import tw.com.hncb.rcms.model.VwRptContentApprvUserPDData;

/**
 * <pre>
 * 報表簽核人員設定檔的DAO實作
 * </pre>
 * 
 * @since 2017-3-13
 * @author jeanlin
 * @version <ul>
 *          <li>2017-3-13,jeanlin,new
 *          </ul>
 */

@Repository
public class RptContentApprvUserDaoImpl extends RcmsJpaDao<RptContentApprvUser> implements
	RptContentApprvUserDao {

	private Log log = LogFactory.getLog(RptContentApprvUserDaoImpl.class);
	
	/**
	 * 取得結束日期
	 * 
	 * @param dateStr
	 * @return dateStr
	 */
	public String getDateEnd(String dateStr) {
		try {
			if (dateStr != null) {
				dateStr = String.valueOf(Integer.parseInt(dateStr) + 1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dateStr;
	}

	
	@Resource(name = "rcmsJdbcTemplate")
	private RcmsNamedJdbcTemplate jdbc;

	/**
	 * 儲存或更新RptContentApprvUser
	 * 
	 * @param o 報表簽核人員設定檔
	 * 			 
	 */
	@Override
	public void saveOrUpdate(RptContentApprvUser o) {
		if (log.isTraceEnabled()) {
			log.trace("RptContentApprvUser=" + o);
		}
		merge(o);
	}
	
	/**
	 * 儲存或更新RptContentApprvUser
	 * 
	 * @param o 報表簽核人員設定檔
	 * 			 
	 */
	@Override
	public void insert(RptContentApprvUser o) {
//		if (log.isTraceEnabled()) {
//			log.trace("RptContentApprvUser=" + o);
//		}
		merge(o);
		
	}

	/**
	 * 刪除RptContentApprvUser
	 * 
	 * @param o 報表簽核人員設定檔
	 */
	@Override
	public void delete(RptContentApprvUser o) {
		if (log.isTraceEnabled()) {
			log.trace("RptContentApprvUser=" + o);
		}
		javax.persistence.Query query = getEntityManager().createQuery(
				"delete from RptContentApprvUser where id=?");
		query.setParameter(1, o.getId());
		query.executeUpdate();
	}
	
	/**
	 * 依報表週期取得日期查詢參數值
	 * 
	 * @param dateStr
	 * @param rptCycle
	 * @return result
	 */
	public String getDateQueryParmsByRptCycle(String dateStr, String rptCycle) {
		if (dateStr == null) {
			return null;
		}
		String result = dateStr;
		if ("D".equals(rptCycle) || "T".equals(rptCycle)
				|| "W".equals(rptCycle) || "N".equals(rptCycle)) {
			// 日報D, 旬報T, 週報W
			result = dateStr;
		} else if ("S".equals(rptCycle) || "M".equals(rptCycle)
				|| "H".equals(rptCycle)) {
			// 季報S, 月報M, 半年報H
			logger.debug("季報S, 月報M, 半年報H : dateStr=" + dateStr);
			if (dateStr.length() >= 6) {
				result = dateStr.substring(0, 6);
			}
		} else if ("Y".equals(rptCycle)) {
			// 月報Y
			if (dateStr.length() >= 4) {
				result = dateStr.substring(0, 4);
			}

		}
		logger.debug("rptCycle=" + rptCycle + ", dateStr=" + dateStr
				+ " , getDateQueryParmsByRptCycle result dateStr=" + result);
		return result;
	}
	
	@Override
	public Page<VwRptContentApprvUserPDData> getBySqlCondition(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String apprvUserId,String isApprv,String rptBranch, List<String> oldBranchIds,String convertDateStart,String convertDateEnd) {
		
		if (search == null)  search  = createSearchTemplete();
		
		int firstResult = search.getFirstResult();
		int maxResult = search.getMaxResults();
		logger.debug("firstResult=" + firstResult);
		logger.debug("maxResult=" + maxResult);

		// 若報表週期未定義 則必須取得所有可能的日期參數
		String parmDdateS = getDateQueryParmsByRptCycle(rptDateBegin, "D");
		String parmMdateS = getDateQueryParmsByRptCycle(rptDateBegin, "M");
		String parmYdateS = getDateQueryParmsByRptCycle(rptDateBegin, "Y");
		String parmDdateE = getDateQueryParmsByRptCycle(rptDateEnd, "D");
		String parmMdateE = getDateQueryParmsByRptCycle(rptDateEnd, "M");
		String parmYdateE = getDateQueryParmsByRptCycle(rptDateEnd, "Y");
		Map<String, Object> args = new HashMap<String, Object>();

		logger.debug("infoGrpRptIds cnt=" + infoGrpRptIds.size());
		logger.debug("rptSeqno=" + rptSeqno);
		logger.debug("parmDdateS=" + parmDdateS);
		logger.debug("parmMdateS=" + parmMdateS);
		logger.debug("parmYdateS=" + parmYdateS);
		logger.debug("parmDdateE=" + parmDdateE);
		logger.debug("parmMdateE=" + parmMdateE);
		logger.debug("parmYdateE=" + parmYdateE);
		
		logger.debug("convertDateStart=" + convertDateStart);
		logger.debug("convertDateEnd=" + convertDateEnd);
		
		String convertDS = null;
		String convertDE = null;
		try { // 日期格式轉換
			SimpleDateFormat formatterCSI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterESI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterCSO = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat formatterESO = new SimpleDateFormat("yyyy-MM-dd");

			if (convertDateStart != null) {
				Date CS = formatterCSI.parse(convertDateStart);
				convertDS = formatterCSO.format(CS) + " 00:00:00";
			}

			if (convertDateEnd != null) {
				Date CE = formatterESI.parse(convertDateEnd);
				convertDE = formatterESO.format(CE) + " 23:59:59";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		// 無任何報表權限 join table至少加一筆row 使得SQL與法成立
		if (infoGrpRptIds.isEmpty()) {
			infoGrpRptIds.add("");
		}
		args.put("infoGrpRptIdsArr", infoGrpRptIds);
		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptIdLike", "%" + rptId + "%");
		args.put("rptName", rptName);
		args.put("rptNameLike", "%" + rptName + "%");
		args.put("rptSeqno", rptSeqno);
		args.put("mustPrint", mustPrint);
		args.put("pd", pd);
		args.put("rptCycle", rptCycle);
		args.put("parmdateS", rptDateBegin);
		args.put("parmdateE", getDateEnd(rptDateEnd));
		args.put("parmDdateS", parmDdateS);
		args.put("parmMdateS", parmMdateS);
		args.put("parmYdateS", parmYdateS);
		args.put("parmDdateE", getDateEnd(parmDdateE));
		args.put("parmMdateE", getDateEnd(parmMdateE));
		args.put("parmYdateE", getDateEnd(parmYdateE));
		//args.put("setUserId", setUserId);
		//args.put("setDivisionId", rptBranch);
		args.put("apprvUserDept", rptBranch);
		args.put("oldBranchIds", oldBranchIds);
		//args.put("setDivisionId", rptBranch);
		args.put("apprvUserId", apprvUserId);
		args.put("isApprv", isApprv);
		
		args.put("convertDateStart", convertDS);
		args.put("convertDateEnd", convertDE);
		
		
		
		

		/*
		Map<String, Boolean> orderMap = search.getOrderBy();
		Set<String> orderKeys = orderMap.keySet();
		for (String orderKey : orderKeys) {
			// logger.debug("key ="+orderKey+", order="+orderMap.get(orderKey));
			String[] orderKeySplitArr = orderKey.split("\\.");
			String sidx = orderKeySplitArr[orderKeySplitArr.length - 1];
			// logger.debug("sidx="+sidx);
			args.put("sidx", "vwrptindex." + sidx);
			if (orderMap.get(orderKey)) {
				args.put("sord", "DESC");
			} else {
				args.put("sord", "ASC");
			}

			// logger.debug("query ====== sord ="+args.get("sord"));

			break;

		} */

		long ts = System.currentTimeMillis();
		List<Map<String, Object>> rptList = jdbc.queryPagingByNativeSql("vwRptContentApprvUserPDData.findPDData", args, firstResult, 10);
		log.debug("rptList spent:"+(System.currentTimeMillis() - ts));
		
		List<VwRptContentApprvUserPDData> vwRptList = new ArrayList<VwRptContentApprvUserPDData>();
		for (Map<String, Object> row : rptList) {
			VwRptContentApprvUserPDData vwRpt = new VwRptContentApprvUserPDData();
			RptContentMasterPK vwPK = new RptContentMasterPK();
			
			vwRpt.setId(((Long) row.get("id")).longValue());
			vwPK.setRptId((String) row.get("rptId"));
			vwPK.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			vwPK.setIndexGrpId("1");
			vwPK.setRptDate((String) row.get("rptDate"));
			vwPK.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			vwRpt.setRptContentMasterPK(vwPK);
			vwRpt.setRptName((String) row.get("rptName"));
			vwRpt.setRptCycle((String) row.get("rptCycle"));
			vwRpt.setKeepYear((Integer) row.get("keepYear"));
			vwRpt.setMustPrint((String) row.get("mustPrint"));
			vwRpt.setPd((String) row.get("pd"));
			vwRpt.setCrossUnit((String) row.get("crossUnit"));	   		//是否跨單位簽核
			
			vwRpt.setCrossDept((String) row.get("crossDept"));
			vwRpt.setRptBranch((String) row.get("rptBranch"));
			
			vwRpt.setGoverningDept((String) row.get("governingDept"));	//業管科別
			vwRpt.setApprvDays((Integer) row.get("apprvDays"));			//簽核期限天數
			vwRpt.setConvertTimeStart((Date) row.get("convertTimeStart"));
			vwRpt.setSetUserId((String) row.get("setUserId"));
			vwRpt.setApprvStatus((String) row.get("apprvStatus"));
			vwRpt.setApprvStep((String) row.get("apprvStep"));
			vwRpt.setApprvUser((String) row.get("apprvUser"));
			vwRpt.setOverdueDays((Integer)row.get("overdueDays"));//逾期天數
			
			vwRpt.setPageMarginLeft((Integer)row.get("pageMarginLeft"));
			vwRpt.setPageMarginTop((Integer)row.get("pageMarginTop"));
			vwRpt.setPageSize((String)row.get("pageSize"));
			vwRpt.setFontSize((Integer)row.get("fontSize"));
			vwRpt.setPageOrientation((String)row.get("pageOrientation"));
			vwRpt.setApprvUserDept((String)row.get("apprvUserDept"));
			
			vwRpt.setMasterId((Long)row.get("masterId"));
			
			
			//log.debug("getBySqlCondition (vwRptContentApprvUserPDData.findPDData)==vwRpt========================"+vwRpt.toString());
			vwRptList.add(vwRpt);
		}

		ts = System.currentTimeMillis();
		Page<VwRptContentApprvUserPDData> pageData = new Page<VwRptContentApprvUserPDData>(vwRptList,
				jdbc.queryForIntByNativeSql("vwRptContentApprvUserPDData.countPDData", args),
				search.getMaxResults(), search.getFirstResult());
		log.debug("countPDData spent:"+(System.currentTimeMillis() - ts));
		
		/*Page<VwRptContentApprvUserPDData> pageData = new Page<VwRptContentApprvUserPDData>(vwRptList,
				jdbc.queryForInt("VwRptContentApprvUserPDData.countPDData", args),
				search.getMaxResults(), search.getFirstResult());*/
		
		
		
		/*Page<VwRptContentApprvUserPDData> pageData = new Page<VwRptContentApprvUserPDData>(vwRptList,
				vwRptList.size(),
				search.getMaxResults(), search.getFirstResult());*/
		
		
		logger.debug("rptList query cnt=" + rptList.size());
		return pageData;
	}
	
	@Override
	public int countBySqlCondition(String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String rptDateBegin,
			String rptDateEnd,String apprvUserId,String isApprv,String rptBranch, List<String> oldBranchIds,String convertDateStart,String convertDateEnd) {
		
		// 若報表週期未定義 則必須取得所有可能的日期參數
		String parmDdateS = getDateQueryParmsByRptCycle(rptDateBegin, "D");
		String parmMdateS = getDateQueryParmsByRptCycle(rptDateBegin, "M");
		String parmYdateS = getDateQueryParmsByRptCycle(rptDateBegin, "Y");
		String parmDdateE = getDateQueryParmsByRptCycle(rptDateEnd, "D");
		String parmMdateE = getDateQueryParmsByRptCycle(rptDateEnd, "M");
		String parmYdateE = getDateQueryParmsByRptCycle(rptDateEnd, "Y");
		Map<String, Object> args = new HashMap<String, Object>();

		logger.debug("infoGrpRptIds cnt=" + infoGrpRptIds.size());
		logger.debug("rptSeqno=" + rptSeqno);
		logger.debug("parmDdateS=" + parmDdateS);
		logger.debug("parmMdateS=" + parmMdateS);
		logger.debug("parmYdateS=" + parmYdateS);
		logger.debug("parmDdateE=" + parmDdateE);
		logger.debug("parmMdateE=" + parmMdateE);
		logger.debug("parmYdateE=" + parmYdateE);
		logger.debug("convertDateStart=" + convertDateStart);
		logger.debug("convertDateEnd=" + convertDateEnd);
		
		String convertDS = null;
		String convertDE = null;
		try { // 日期格式轉換
			SimpleDateFormat formatterCSI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterESI = new SimpleDateFormat("yyyyMMdd");
			SimpleDateFormat formatterCSO = new SimpleDateFormat("yyyy-MM-dd");
			SimpleDateFormat formatterESO = new SimpleDateFormat("yyyy-MM-dd");

			if (convertDateStart != null) {
				Date CS = formatterCSI.parse(convertDateStart);
				convertDS = formatterCSO.format(CS) + " 00:00:00";
			}

			if (convertDateEnd != null) {
				Date CE = formatterESI.parse(convertDateEnd);
				convertDE = formatterESO.format(CE) + " 23:59:59";
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		// 無任何報表權限 join table至少加一筆row 使得SQL與法成立
		if (infoGrpRptIds.isEmpty()) {
			infoGrpRptIds.add("");
		}
		args.put("infoGrpRptIdsArr", infoGrpRptIds);
		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptIdLike", "%" + rptId + "%");
		args.put("rptName", rptName);
		args.put("rptNameLike", "%" + rptName + "%");
		args.put("rptSeqno", rptSeqno);
		args.put("mustPrint", mustPrint);
		args.put("rptCycle", rptCycle);
		args.put("parmdateS", rptDateBegin);
		args.put("parmdateE", getDateEnd(rptDateEnd));
		args.put("parmDdateS", parmDdateS);
		args.put("parmMdateS", parmMdateS);
		args.put("parmYdateS", parmYdateS);
		args.put("parmDdateE", getDateEnd(parmDdateE));
		args.put("parmMdateE", getDateEnd(parmMdateE));
		args.put("parmYdateE", getDateEnd(parmYdateE));
		args.put("apprvUserDept", rptBranch);
		args.put("oldBranchIds", oldBranchIds);
		args.put("apprvUserId", apprvUserId);
		args.put("isApprv", isApprv);
		args.put("convertDateStart", convertDS);
		args.put("convertDateEnd", convertDE);
		return jdbc.queryForIntByNativeSql("vwRptContentApprvUserPDData.countPDData", args);
	}
	
	@Override
	public Page<VwRptContentApprvUserPDData> getBySqlConditionAllApprvUser(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String apprvUserId,String isApprv,String empId) {
		
		if (search == null) search = createSearchTemplete();
		int firstResult = search.getFirstResult();
		int maxResult = search.getMaxResults();
		logger.debug("firstResult=" + firstResult);
		logger.debug("maxResult=" + maxResult);

		// 若報表週期未定義 則必須取得所有可能的日期參數
		String parmDdateS = getDateQueryParmsByRptCycle(rptDateBegin, "D");
		String parmMdateS = getDateQueryParmsByRptCycle(rptDateBegin, "M");
		String parmYdateS = getDateQueryParmsByRptCycle(rptDateBegin, "Y");
		String parmDdateE = getDateQueryParmsByRptCycle(rptDateEnd, "D");
		String parmMdateE = getDateQueryParmsByRptCycle(rptDateEnd, "M");
		String parmYdateE = getDateQueryParmsByRptCycle(rptDateEnd, "Y");
		Map<String, Object> args = new HashMap<String, Object>();

		//logger.debug("infoGrpRptIds cnt=" + infoGrpRptIds.size());
		logger.debug("rptSeqno=" + rptSeqno);
		logger.debug("parmDdateS=" + parmDdateS);
		logger.debug("parmMdateS=" + parmMdateS);
		logger.debug("parmYdateS=" + parmYdateS);
		logger.debug("parmDdateE=" + parmDdateE);
		logger.debug("parmMdateE=" + parmMdateE);
		logger.debug("parmYdateE=" + parmYdateE);

		// 無任何報表權限 join table至少加一筆row 使得SQL與法成立
		if (infoGrpRptIds == null) infoGrpRptIds = new ArrayList();
		if (infoGrpRptIds.isEmpty()) {
			infoGrpRptIds.add("");
		}
		args.put("infoGrpRptIdsArr", infoGrpRptIds);
		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptIdLike", "%" + rptId + "%");
		args.put("rptName", rptName);
		args.put("rptNameLike", "%" + rptName + "%");
		args.put("rptSeqno", rptSeqno);
		args.put("mustPrint", mustPrint);
		args.put("pd", pd);
		args.put("rptCycle", rptCycle);
		args.put("parmdateS", rptDateBegin);
		args.put("parmdateE", getDateEnd(rptDateEnd));
		args.put("parmDdateS", parmDdateS);
		args.put("parmMdateS", parmMdateS);
		args.put("parmYdateS", parmYdateS);
		args.put("parmDdateE", getDateEnd(parmDdateE));
		args.put("parmMdateE", getDateEnd(parmMdateE));
		args.put("parmYdateE", getDateEnd(parmYdateE));
		//args.put("setUserId", setUserId);
		
		args.put("apprvUserId", apprvUserId);
		args.put("isApprv", isApprv);
		
		//20180315 加入查詢人員的員編用以判斷是否為總務R1031或預設經辦
		args.put("empId", isApprv);
		

		/*
		Map<String, Boolean> orderMap = search.getOrderBy();
		Set<String> orderKeys = orderMap.keySet();
		for (String orderKey : orderKeys) {
			// logger.debug("key ="+orderKey+", order="+orderMap.get(orderKey));
			String[] orderKeySplitArr = orderKey.split("\\.");
			String sidx = orderKeySplitArr[orderKeySplitArr.length - 1];
			// logger.debug("sidx="+sidx);
			args.put("sidx", "vwrptindex." + sidx);
			if (orderMap.get(orderKey)) {
				args.put("sord", "DESC");
			} else {
				args.put("sord", "ASC");
			}

			// logger.debug("query ====== sord ="+args.get("sord"));

			break;

		} */

		List<Map<String, Object>> rptList = jdbc.queryPaging("vwRptContentApprvUserPDData.findAllPDData", args, firstResult, 10);
		List<VwRptContentApprvUserPDData> vwRptList = new ArrayList<VwRptContentApprvUserPDData>();
		for (Map<String, Object> row : rptList) {
			VwRptContentApprvUserPDData vwRpt = new VwRptContentApprvUserPDData();
			RptContentMasterPK vwPK = new RptContentMasterPK();
			
			vwRpt.setId(((Long) row.get("id")).longValue());
			vwPK.setRptId((String) row.get("rptId"));
			vwPK.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			vwPK.setIndexGrpId("1");
			vwPK.setRptDate((String) row.get("rptDate"));
			vwPK.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			vwRpt.setRptContentMasterPK(vwPK);
			vwRpt.setRptName((String) row.get("rptName"));
			vwRpt.setRptCycle((String) row.get("rptCycle"));
			vwRpt.setKeepYear((Integer) row.get("keepYear"));
			vwRpt.setMustPrint((String) row.get("mustPrint"));
			vwRpt.setPd((String) row.get("pd"));
			vwRpt.setCrossUnit((String) row.get("crossUnit"));	   		//是否跨單位簽核
			vwRpt.setGoverningDept((String) row.get("governingDept"));	//業管科別
			vwRpt.setApprvDays((Integer) row.get("apprvDays"));			//簽核期限天數
			vwRpt.setConvertTimeStart((Date) row.get("convertTimeStart"));
			vwRpt.setSetUserId((String) row.get("setUserId"));
			vwRpt.setApprvStatus((String) row.get("apprvStatus"));
			vwRpt.setApprvStep((String) row.get("apprvStep"));
			vwRpt.setApprvUser((String) row.get("apprvUser"));
			vwRpt.setOverdueDays((Integer)row.get("overdueDays"));//逾期天數
			
			vwRpt.setPageMarginLeft((Integer)row.get("pageMarginLeft"));
			vwRpt.setPageMarginTop((Integer)row.get("pageMarginTop"));
			vwRpt.setPageSize((String)row.get("pageSize"));
			vwRpt.setFontSize((Integer)row.get("fontSize"));
			vwRpt.setPageOrientation((String)row.get("pageOrientation"));
			
			vwRpt.setApprvUser((String)row.get("apprvUser"));
			
			//vwRpt.setMasterId((Long)row.get("masterId"));
			
			log.debug("getBySqlConditionAllApprvUser(vwRptContentApprvUserPDData.findAllPDData) vwRpt========================"+vwRpt.toString());
			vwRptList.add(vwRpt);
		}

		Page<VwRptContentApprvUserPDData> pageData = new Page<VwRptContentApprvUserPDData>(vwRptList,
				jdbc.queryForInt("vwRptContentApprvUserPDData.countAllPDData", args),
				search.getMaxResults(), search.getFirstResult());
		
		/*Page<VwRptContentApprvUserPDData> pageData = new Page<VwRptContentApprvUserPDData>(vwRptList,
				vwRptList.size(),
				search.getMaxResults(), search.getFirstResult());*/
		
		
		logger.debug("rptList query cnt=" + rptList.size());
		return pageData;
	}
	
	@Override
	public Page<VwRptContentApprvUserPDData> getBySqlConditionAllApprvUserByUnitNo(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String apprvUserId,String isApprv, String unitNo) {
		
		if (search == null) search = createSearchTemplete();
		int firstResult = search.getFirstResult();
		int maxResult = search.getMaxResults();
		logger.debug("firstResult=" + firstResult);
		logger.debug("maxResult=" + maxResult);

		// 若報表週期未定義 則必須取得所有可能的日期參數
		String parmDdateS = getDateQueryParmsByRptCycle(rptDateBegin, "D");
		String parmMdateS = getDateQueryParmsByRptCycle(rptDateBegin, "M");
		String parmYdateS = getDateQueryParmsByRptCycle(rptDateBegin, "Y");
		String parmDdateE = getDateQueryParmsByRptCycle(rptDateEnd, "D");
		String parmMdateE = getDateQueryParmsByRptCycle(rptDateEnd, "M");
		String parmYdateE = getDateQueryParmsByRptCycle(rptDateEnd, "Y");
		Map<String, Object> args = new HashMap<String, Object>();

		//logger.debug("infoGrpRptIds cnt=" + infoGrpRptIds.size());
		logger.debug("rptSeqno=" + rptSeqno);
		logger.debug("parmDdateS=" + parmDdateS);
		logger.debug("parmMdateS=" + parmMdateS);
		logger.debug("parmYdateS=" + parmYdateS);
		logger.debug("parmDdateE=" + parmDdateE);
		logger.debug("parmMdateE=" + parmMdateE);
		logger.debug("parmYdateE=" + parmYdateE);

		// 無任何報表權限 join table至少加一筆row 使得SQL與法成立
		if (infoGrpRptIds == null) infoGrpRptIds = new ArrayList();
		if (infoGrpRptIds.isEmpty()) {
			infoGrpRptIds.add("");
		}
		args.put("infoGrpRptIdsArr", infoGrpRptIds);
		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptIdLike", "%" + rptId + "%");
		args.put("rptName", rptName);
		args.put("rptNameLike", "%" + rptName + "%");
		args.put("rptSeqno", rptSeqno);
		args.put("mustPrint", mustPrint);
		args.put("pd", pd);
		args.put("rptCycle", rptCycle);
		args.put("parmdateS", rptDateBegin);
		args.put("parmdateE", getDateEnd(rptDateEnd));
		args.put("parmDdateS", parmDdateS);
		args.put("parmMdateS", parmMdateS);
		args.put("parmYdateS", parmYdateS);
		args.put("parmDdateE", getDateEnd(parmDdateE));
		args.put("parmMdateE", getDateEnd(parmMdateE));
		args.put("parmYdateE", getDateEnd(parmYdateE));
		//args.put("setUserId", setUserId);
		
		args.put("apprvUserId", apprvUserId);
		args.put("isApprv", isApprv);
		args.put("unitNo", unitNo);
		

		/*
		Map<String, Boolean> orderMap = search.getOrderBy();
		Set<String> orderKeys = orderMap.keySet();
		for (String orderKey : orderKeys) {
			// logger.debug("key ="+orderKey+", order="+orderMap.get(orderKey));
			String[] orderKeySplitArr = orderKey.split("\\.");
			String sidx = orderKeySplitArr[orderKeySplitArr.length - 1];
			// logger.debug("sidx="+sidx);
			args.put("sidx", "vwrptindex." + sidx);
			if (orderMap.get(orderKey)) {
				args.put("sord", "DESC");
			} else {
				args.put("sord", "ASC");
			}

			// logger.debug("query ====== sord ="+args.get("sord"));

			break;

		} */

		List<Map<String, Object>> rptList = jdbc.queryPaging("vwRptContentApprvUserPDData.findAllPDDataByUnitNo", args, firstResult, 10);
		List<VwRptContentApprvUserPDData> vwRptList = new ArrayList<VwRptContentApprvUserPDData>();
		for (Map<String, Object> row : rptList) {
			VwRptContentApprvUserPDData vwRpt = new VwRptContentApprvUserPDData();
			RptContentMasterPK vwPK = new RptContentMasterPK();
			
			vwRpt.setId(((Long) row.get("id")).longValue());
			vwPK.setRptId((String) row.get("rptId"));
			vwPK.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			vwPK.setIndexGrpId("1");
			vwPK.setRptDate((String) row.get("rptDate"));
			vwPK.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			vwRpt.setRptContentMasterPK(vwPK);
			vwRpt.setRptName((String) row.get("rptName"));
			vwRpt.setRptCycle((String) row.get("rptCycle"));
			vwRpt.setKeepYear((Integer) row.get("keepYear"));
			vwRpt.setMustPrint((String) row.get("mustPrint"));
			vwRpt.setPd((String) row.get("pd"));
			vwRpt.setCrossUnit((String) row.get("crossUnit"));	   		//是否跨單位簽核
			vwRpt.setGoverningDept((String) row.get("governingDept"));	//業管科別
			vwRpt.setApprvDays((Integer) row.get("apprvDays"));			//簽核期限天數
			vwRpt.setConvertTimeStart((Date) row.get("convertTimeStart"));
			vwRpt.setSetUserId((String) row.get("setUserId"));
			vwRpt.setApprvStatus((String) row.get("apprvStatus"));
			vwRpt.setApprvStep((String) row.get("apprvStep"));
			vwRpt.setApprvUser((String) row.get("apprvUser"));
			vwRpt.setOverdueDays((Integer)row.get("overdueDays"));//逾期天數
			
			vwRpt.setPageMarginLeft((Integer)row.get("pageMarginLeft"));
			vwRpt.setPageMarginTop((Integer)row.get("pageMarginTop"));
			vwRpt.setPageSize((String)row.get("pageSize"));
			vwRpt.setFontSize((Integer)row.get("fontSize"));
			vwRpt.setPageOrientation((String)row.get("pageOrientation"));
			
			vwRpt.setApprvUser((String)row.get("apprvUser"));
			
			//vwRpt.setMasterId((Long)row.get("masterId"));
			
			log.debug("getBySqlConditionAllApprvUser(vwRptContentApprvUserPDData.findAllPDData) vwRpt========================"+vwRpt.toString());
			vwRptList.add(vwRpt);
		}

		Page<VwRptContentApprvUserPDData> pageData = new Page<VwRptContentApprvUserPDData>(vwRptList,
				jdbc.queryForInt("vwRptContentApprvUserPDData.countAllPDDataByUnitNo", args),
				search.getMaxResults(), search.getFirstResult());
		
		/*Page<VwRptContentApprvUserPDData> pageData = new Page<VwRptContentApprvUserPDData>(vwRptList,
				vwRptList.size(),
				search.getMaxResults(), search.getFirstResult());*/
		
		
		logger.debug("rptList query cnt=" + rptList.size());
		return pageData;
	}
	
	@Override
	public List<VwRptContentApprvUserPDData> getAllBySqlCondition(ISearch search, String rptId, List<String> infoGrpRptIds,
			String rptName, int rptSeqno, String rptCycle, String mustPrint, String pd, String rptDateBegin,
			String rptDateEnd,String apprvUserId) {
		
		int firstResult = search.getFirstResult();
		int maxResult = search.getMaxResults();
		logger.debug("firstResult=" + firstResult);
		logger.debug("maxResult=" + maxResult);

		// 若報表週期未定義 則必須取得所有可能的日期參數
		String parmDdateS = getDateQueryParmsByRptCycle(rptDateBegin, "D");
		String parmMdateS = getDateQueryParmsByRptCycle(rptDateBegin, "M");
		String parmYdateS = getDateQueryParmsByRptCycle(rptDateBegin, "Y");
		String parmDdateE = getDateQueryParmsByRptCycle(rptDateEnd, "D");
		String parmMdateE = getDateQueryParmsByRptCycle(rptDateEnd, "M");
		String parmYdateE = getDateQueryParmsByRptCycle(rptDateEnd, "Y");
		Map<String, Object> args = new HashMap<String, Object>();

		logger.debug("infoGrpRptIds cnt=" + infoGrpRptIds.size());
		logger.debug("rptSeqno=" + rptSeqno);
		logger.debug("parmDdateS=" + parmDdateS);
		logger.debug("parmMdateS=" + parmMdateS);
		logger.debug("parmYdateS=" + parmYdateS);
		logger.debug("parmDdateE=" + parmDdateE);
		logger.debug("parmMdateE=" + parmMdateE);
		logger.debug("parmYdateE=" + parmYdateE);

		// 無任何報表權限 join table至少加一筆row 使得SQL與法成立
		if (infoGrpRptIds.isEmpty()) {
			infoGrpRptIds.add("");
		}
		args.put("infoGrpRptIdsArr", infoGrpRptIds);
		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptIdLike", "%" + rptId + "%");
		args.put("rptName", rptName);
		args.put("rptNameLike", "%" + rptName + "%");
		args.put("rptSeqno", rptSeqno);
		args.put("mustPrint", mustPrint);
		args.put("pd", pd);
		args.put("rptCycle", rptCycle);
		args.put("parmdateS", rptDateBegin);
		args.put("parmdateE", getDateEnd(rptDateEnd));
		args.put("parmDdateS", parmDdateS);
		args.put("parmMdateS", parmMdateS);
		args.put("parmYdateS", parmYdateS);
		args.put("parmDdateE", getDateEnd(parmDdateE));
		args.put("parmMdateE", getDateEnd(parmMdateE));
		args.put("parmYdateE", getDateEnd(parmYdateE));
		//args.put("setUserId", setUserId);
		
		args.put("apprvUserId", apprvUserId);

		/*
		Map<String, Boolean> orderMap = search.getOrderBy();
		Set<String> orderKeys = orderMap.keySet();
		for (String orderKey : orderKeys) {
			// logger.debug("key ="+orderKey+", order="+orderMap.get(orderKey));
			String[] orderKeySplitArr = orderKey.split("\\.");
			String sidx = orderKeySplitArr[orderKeySplitArr.length - 1];
			// logger.debug("sidx="+sidx);
			args.put("sidx", "vwrptindex." + sidx);
			if (orderMap.get(orderKey)) {
				args.put("sord", "DESC");
			} else {
				args.put("sord", "ASC");
			}

			// logger.debug("query ====== sord ="+args.get("sord"));

			break;

		} */

		List<Map<String, Object>> rptList = jdbc.queryForList("vwRptContentApprvUserPDData.findPDData", args);
		List<VwRptContentApprvUserPDData> vwRptList = new ArrayList<VwRptContentApprvUserPDData>();
		for (Map<String, Object> row : rptList) {
			VwRptContentApprvUserPDData vwRpt = new VwRptContentApprvUserPDData();
			RptContentMasterPK vwPK = new RptContentMasterPK();
			vwRpt.setId(((Long) row.get("id")).longValue());
			vwPK.setRptId((String) row.get("rptId"));
			vwPK.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			vwPK.setIndexGrpId("1");
			vwPK.setRptDate((String) row.get("rptDate"));
			vwPK.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			vwRpt.setRptContentMasterPK(vwPK);
			vwRpt.setRptName((String) row.get("rptName"));
			vwRpt.setRptCycle((String) row.get("rptCycle"));
			vwRpt.setKeepYear((Integer) row.get("keepYear"));
			vwRpt.setMustPrint((String) row.get("mustPrint"));
			vwRpt.setPd((String) row.get("pd"));
			vwRpt.setCrossUnit((String) row.get("crossUnit"));	   		//是否跨單位簽核
			vwRpt.setGoverningDept((String) row.get("governingDept"));	//業管科別
			vwRpt.setApprvDays((Integer) row.get("apprvDays"));			//簽核期限天數
			vwRpt.setConvertTimeStart((Date) row.get("convertTimeStart"));
			vwRpt.setSetUserId((String) row.get("setUserId"));
			vwRpt.setApprvStatus((String) row.get("apprvStatus"));
			vwRpt.setApprvStep((String) row.get("apprvStep"));
			vwRpt.setApprvUser((String) row.get("apprvUser"));
			vwRpt.setOverdueDays((Integer)row.get("overdueDays"));//逾期天數
			
			
			log.debug("vwRpt========================"+vwRpt.toString());
			vwRptList.add(vwRpt);
		}

	/*	Page<VwRptContentApprvUserPDData> pageData = new Page<VwRptContentApprvUserPDData>(vwRptList,
				jdbc.queryForInt("VwRptContentApprvUserPDData.countPDData", args),
				search.getMaxResults(), search.getFirstResult());*/
	/*	
		Page<VwRptContentApprvUserPDData> pageData = new Page<VwRptContentApprvUserPDData>(vwRptList,vwRptList.size(),
				search.getMaxResults(), search.getFirstResult());*/
		
		
		logger.debug("rptList query cnt=" + rptList.size());
		return vwRptList;
	}

	@Override
	public List<RptContentApprvUser> getBySqlCondition(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch){
		Map<String, Object> args = new HashMap<String, Object>();

		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptVersion", rptVersion);
		args.put("rptBranch", rptBranch);
		logger.debug("rptContentApprvUser.findData args="+args);
		List<Map<String, Object>> rptList = jdbc.query("rptContentApprvUser.findData", args);
		List<RptContentApprvUser> list = new ArrayList<RptContentApprvUser>();
		for (Map<String, Object> row : rptList) {
			RptContentApprvUser o = new RptContentApprvUser();
			
			/*RptContentMasterPK vwPK = new RptContentMasterPK();			
			vwPK.setRptId((String) row.get("rptId"));
			vwPK.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			vwPK.setIndexGrpId("1");
			vwPK.setRptDate((String) row.get("rptDate"));
			vwPK.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			*/
			
			o.setId(((Long) row.get("id")).longValue());
			o.setRptId((String) row.get("rptId"));
			o.setMustPrint((String)row.get("mustPrint"));
			o.setKeepYear((Integer)row.get("keepYear"));
			o.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			o.setRptDate((String) row.get("rptDate"));
			o.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			
			o.setRptName((String) row.get("rptName"));
			o.setRptCycle((String) row.get("rptCycle"));
			o.setIndexGrpId("1");
			o.setApprvUserName((String)row.get("apprvUserName"));
			o.setConvertTimeStart((Date) row.get("convertTimeStart"));
			o.setConvertTimeEnd((Date) row.get("convertTimeEnd"));
			o.setSetUserId((String) row.get("setUserId"));
			o.setSetDivisionId((String)row.get("setDivisionId"));
			o.setApprvStatus((String)row.get("apprvStatus"));
			o.setApprvStep((String)row.get("apprvStep"));
			o.setApprvUserName((String) row.get("apprvUserName"));
			o.setApprvUser((String) row.get("apprvUser"));
			o.setApprvType((String) row.get("apprvType"));
			o.setIsApprv((String) row.get("isApprv"));//是否已簽過
			o.setRptBranch((String)row.get("rptBranch"));
			o.setApprvUserDept((String)row.get("apprvUserDept"));
			//setdivisionid
			o.setSetDivisionId((String)row.get("setdivisionid"));
			
			log.debug("getBySqlCondition========================o"+o.toString());
			list.add(o);
		}

		logger.debug("getBySqlCondition rptList query cnt=" + list.size());
		return list;
		
	}
	
	@Override
	public int countToApprvUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String currentApprvStep){
		Map<String, Object> args = new HashMap<String, Object>();

		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptVersion", rptVersion);
		args.put("rptBranch", rptBranch);
		args.put("apprvStep", currentApprvStep);
		
		

		int count = jdbc.queryForInt("rptContentApprvUser.countToApprvData", args);
		

		logger.debug("countToApprvUsers count=" + count);
		return count;
	}
	
	@Override
	public List<RptContentApprvUser> getToApprvUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String currentApprvStep){
		Map<String, Object> args = new HashMap<String, Object>();

		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptVersion", rptVersion);
		args.put("rptBranch", rptBranch);
		args.put("apprvStep", currentApprvStep);
		
		

		List<Map<String, Object>> rptList = jdbc.query("rptContentApprvUser.findToApprvData", args);
		List<RptContentApprvUser> list = new ArrayList<RptContentApprvUser>();
		for (Map<String, Object> row : rptList) {
			RptContentApprvUser vwRpt = new RptContentApprvUser();
			vwRpt.setId(((Long) row.get("id")).longValue());
			vwRpt.setRptName((String) row.get("rptName"));
			vwRpt.setApprvStatus((String) row.get("apprvStatus"));
			vwRpt.setApprvStep((String) row.get("apprvStep"));
			vwRpt.setApprvUser((String) row.get("apprvUser"));
			vwRpt.setApprvType((String) row.get("apprvType"));
			
			log.debug("vwRpt========================"+vwRpt.toString());
			list.add(vwRpt);
		}

		logger.debug("getToApprvUsers rptList query cnt=" + list.size());
		return list;
		
	}
	
	@Override
	public List<RptContentApprvUser> getToApprvUsersByUnit(String rptBranch,String empId){
		
		Map<String, Object> args = new HashMap<String, Object>();
		args.put("rptBranch", rptBranch);
		args.put("empId", empId);
		List<Map<String, Object>> rptList = jdbc.query("rptContentApprvUser.findToApprvDataByUnit", args);
		List<RptContentApprvUser> list = new ArrayList<RptContentApprvUser>();
		for (Map<String, Object> row : rptList) {
			RptContentApprvUser vwRpt = new RptContentApprvUser();
			vwRpt.setId(((Long) row.get("id")).longValue());
			vwRpt.setRptName((String) row.get("rptName"));
			vwRpt.setApprvStatus((String) row.get("apprvStatus"));
			vwRpt.setApprvStep((String) row.get("apprvStep"));
			vwRpt.setApprvUser((String) row.get("apprvUserId"));
			vwRpt.setApprvUserName((String) row.get("apprvUserName"));
			vwRpt.setApprvType((String) row.get("apprvType"));
			list.add(vwRpt);
		}

		logger.debug("getToApprvUsers rptList query cnt=" + list.size());
		return list;
		
	}
	
	
	@Override
	public int countToApprvByUnitChange(String empId) {
		int cnt = 0;
		try {
			Map<String, Object> args = new HashMap<String, Object>();
			args.put("empId", empId);
			// int cnt =
			// jdbc.queryForInt("rptContentApprvUser.countToApprvByUnitChange",
			// args);

			cnt = jdbc.queryForInt("RptApprvTodoCnt.qry3", args);

			//log.debug("待改派(依單位異動人員)件數 countToApprvByUnitChange=" + cnt);

			// rptContentApprvUser.countToApprvByUnitChange
			//return cnt;
		} catch (EmptyResultDataAccessException e) {
			//return cnt;
			cnt = 0;
		} catch (Exception e) {
			//return cnt;
			cnt = 0;
		}
		
		log.debug("countToApprvByUnitChange empId=" +empId+",cnt=" +  cnt);
		return cnt;
		
	}
	
	
	@Override
	public RptContentApprvUser getOneBySqlCondition(String rptId,int rptSeqno,  String rptDate ,int rptVersion,
			String rptBranch,String apprvStep,String apprvUser){
		Map<String, Object> args = new HashMap<String, Object>();

		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptVersion", rptVersion);
		args.put("rptBranch", rptBranch);
		args.put("apprvStep", apprvStep);
		args.put("apprvUser", apprvUser);

		List<Map<String, Object>> rptList = jdbc.query("rptContentApprvUser.findOneData", args);
		for (Map<String, Object> row : rptList) {
			RptContentApprvUser obj = new RptContentApprvUser();
			/*RptContentMasterPK vwPK = new RptContentMasterPK();
			
			vwPK.setRptId((String) row.get("rptId"));
			vwPK.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			vwPK.setIndexGrpId("1");
			vwPK.setRptDate((String) row.get("rptDate"));
			vwPK.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			*/
			
			obj.setId(((Long) row.get("id")).longValue());
			obj.setRptId((String) row.get("rptId"));
			obj.setRptSeqno((BigDecimal) row.get("rptSeqno"));
			obj.setRptDate((String) row.get("rptDate"));
			obj.setRptVersion(((BigDecimal) row.get("rptVersion")).intValue());
			obj.setIndexGrpId("1");
			
			obj.setRptName((String) row.get("rptName"));
			obj.setRptCycle((String) row.get("rptCycle"));
			obj.setKeepYear((Integer) row.get("keepYear"));
			obj.setMustPrint((String) row.get("mustPrint"));
			obj.setRptBranch((String) row.get("rptBranch"));
			
			obj.setConvertTimeStart((Date) row.get("convertTimeStart"));
			obj.setSetUserId((String) row.get("setUserId"));
			obj.setSetDivisionId((String) row.get("setDivisionId"));
			obj.setApprvStatus((String) row.get("apprvStatus"));
			obj.setApprvStep((String) row.get("apprvStep"));
			obj.setApprvUserName((String) row.get("apprvUserName"));
			obj.setApprvUser((String)row.get("apprvUser"));
			obj.setApprvType((String) row.get("apprvType"));
			obj.setIsApprv((String) row.get("isApprv"));
			obj.setConvertTimeStart((Date)row.get("convertTimeStart"));
			
			obj.setCreateTime((Date) row.get("createTime"));
			obj.setCreator((String)row.get("creator"));
			
			obj.setUpdateTime((Date) row.get("updateTime"));
			obj.setUpdater((String)row.get("updater"));
			
			log.debug("getOneBySqlCondition=================obj="+obj.toString());
			return obj;
		}
		return null;
	}
	
	@Override
	public int updateBySqlCondition(String rptId,int rptSeqno,  String rptDate ,int rptVersion,
			String rptBranch,String apprvStep,String apprvUser){
		Map<String, Object> args = new HashMap<String, Object>();

		if (rptId != null) {
			rptId = rptId.toUpperCase();
		}
		args.put("rptId", rptId);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptVersion", rptVersion);
		args.put("rptBranch", rptBranch);
		args.put("apprvStep", apprvStep);
		args.put("apprvUser", apprvUser);

		return  jdbc.update("rptContentApprvUser.updateData", args);
	}
	
	@Override
	public int updateById(Long id ,String apprvStatus,Date updateTime,String updater,String isApprv,String apprvStep){
		Map<String, Object> args = new HashMap<String, Object>();
		
		args.put("id", id);
		args.put("apprvStatus", apprvStatus);
		args.put("apprvStep", apprvStep);//APPRVTIME
		args.put("updateTime", updateTime);
		args.put("updater", updater);
		args.put("isApprv", isApprv);

		return  jdbc.update("rptContentApprvUser.updateById2", args);
		
	}
	
	@Override
	public int updateById(Long id ,String apprvStatus,Date updateTime,String updater,String isApprv){
		Map<String, Object> args = new HashMap<String, Object>();
		
		args.put("id", id);
		args.put("apprvStatus", apprvStatus);
		args.put("updateTime", updateTime);
		args.put("updater", updater);
		args.put("isApprv", isApprv);

		return  jdbc.update("rptContentApprvUser.updateById", args);
		
	}
	
	@Override
	public List<RptContentApprvUser> getLastRptContentApprvUser(String rptId, 
			String rptBranch, String userBranch){
		Map<String, Object> args = new HashMap<String, Object>();
		
		args.put("rptId", rptId);		
		args.put("rptBranch", rptBranch);
		args.put("userBranch", userBranch);
		
		List<Map<String, Object>> rptList = jdbc.query("rptContentApprvUser.findLatestData", args);
		List<RptContentApprvUser> list = new ArrayList<RptContentApprvUser>();
		for (Map<String, Object> row : rptList) {
			RptContentApprvUser o = new RptContentApprvUser();
			o.setId(((Long) row.get("id")).longValue());
			o.setRptDate((String)row.get("rptDate"));
			o.setRptSeqno((BigDecimal)row.get("rptSeqno"));
			o.setRptVersion(((BigDecimal)row.get("rptVersion")).intValue());
			o.setRptName((String) row.get("rptName"));
			o.setApprvStatus((String) row.get("apprvStatus"));
			o.setApprvStep((String) row.get("apprvStep"));
			o.setApprvUser((String) row.get("apprvUser"));//員編
			o.setApprvType((String) row.get("apprvType"));
			o.setConvertTimeStart((Date) row.get("convertTimeStart"));
			
			log.debug("getLastRptContentApprvUser o========================"+o.toString());
			list.add(o);
		}

		logger.debug("getLastRptContentApprvUser list cnt=" + list.size());
		return list;
	
	}
	
	
	@Override
	public List<RptContentApprvUser> getLastestByConvertTimeStart(String rptId, String rptVersion, int rptSeqno, String rptDate, 
			String rptBranch,String convertTimeStart){
		Map<String, Object> args = new HashMap<String, Object>();
		
		args.put("rptId", rptId);
		args.put("rptVersion", rptVersion);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptBranch", rptBranch);
		args.put("convertTimeStart", convertTimeStart);
		
		List<Map<String, Object>> rptList = jdbc.query("rptContentApprvUser.findLatestDataByConvertTimeStart", args);
		List<RptContentApprvUser> list = new ArrayList<RptContentApprvUser>();
		for (Map<String, Object> row : rptList) {
			RptContentApprvUser o = new RptContentApprvUser();
			o.setId(((Long) row.get("id")).longValue());
			o.setRptName((String) row.get("rptName"));
			o.setApprvStatus((String) row.get("apprvStatus"));
			o.setApprvStep((String) row.get("apprvStep"));
			o.setApprvUser((String) row.get("apprvUser"));//員編
			o.setApprvType((String) row.get("apprvType"));
			o.setIsApprv((String)row.get("isApprv"));
			
			log.debug("getLastRptContentApprvUser o========================"+o.toString());
			list.add(o);
		}

		logger.debug("getLastRptContentApprvUser list cnt=" + list.size());
		return list;
	
	}
	
	@Override
	public List<RptContentApprvUser> getRptContentApprvUserCrossUnit(String rptId, String rptVersion, int rptSeqno, String rptDate, 
			String rptBranch, List<String> rptBranches,String convertTimeStart){
		Map<String, Object> args = new HashMap<String, Object>();
		
		args.put("rptId", rptId);
		args.put("rptVersion", rptVersion);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptBranch", rptBranch);
		args.put("setDivisionIds", rptBranches);
		args.put("convertTimeStart", convertTimeStart);
		
		List<Map<String, Object>> rptList = jdbc.query("rptContentApprvUser.getRptContentApprvUserCrossUnit", args);
		List<RptContentApprvUser> list = new ArrayList<RptContentApprvUser>();
		for (Map<String, Object> row : rptList) {
			RptContentApprvUser o = new RptContentApprvUser();
			o.setId(((Long) row.get("id")).longValue());
			o.setRptName((String) row.get("rptName"));
			o.setApprvStatus((String) row.get("apprvStatus"));
			o.setApprvStep((String) row.get("apprvStep"));
			o.setApprvUser((String) row.get("apprvUser"));//員編
			o.setApprvType((String) row.get("apprvType"));
			o.setIsApprv((String)row.get("isApprv"));
			o.setApprvUserDept((String)row.get("apprvUserDept"));
			
			log.debug("getRptContentApprvUserCrossUnit o========================"+o.toString());
			list.add(o);
		}

		logger.debug("getRptContentApprvUserCrossUnit list cnt=" + list.size());
		return list;
	
	}
	
	
	
	
	@Override
	public int deleteUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String convertTimeStart,List<String> apprvUserIds){
		Map<String, Object> args = new HashMap<String, Object>();
		
		args.put("rptId", rptId);
		args.put("rptVersion", rptVersion);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptBranch", rptBranch);
		args.put("convertTimeStart", convertTimeStart);
		args.put("apprvUserIds", apprvUserIds);
		
		int deleteCnt = jdbc.update("rptContentApprvUser.deleteUsers", args);
		
		log.debug("deleteUsers deleteCnt="+deleteCnt);
		return deleteCnt;
		
	}
	
	@Override
	public int deleteUsers(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String convertTimeStart){
		Map<String, Object> args = new HashMap<String, Object>();
		
		args.put("rptId", rptId);
		args.put("rptVersion", rptVersion);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptBranch", rptBranch);
		args.put("convertTimeStart", convertTimeStart);
		
		int deleteCnt = jdbc.update("rptContentApprvUser.deleteApprvUsers", args);
		
		log.debug("deleteUsers deleteCnt="+deleteCnt);
		return deleteCnt;
		
	}
	
	@Override
	public String getMinApprvStep(String rptId,int rptSeqno,  String rptDate, int rptVersion,String rptBranch,String convertTimeStart){
		
		Map<String, Object> args = new HashMap<String, Object>();
		
		args.put("rptId", rptId);
		args.put("rptVersion", rptVersion);
		args.put("rptSeqno", rptSeqno);
		args.put("rptDate", rptDate);
		args.put("rptBranch", rptBranch);
		args.put("convertTimeStart", convertTimeStart);
		
		List<Map<String, Object>> rptList = jdbc.query("rptContentApprvUser.getMinApprvStep", args);
		for (Map<String, Object> row : rptList) {
			return (String) row.get("apprvStep");
		}
		
		return "";
		
	}
	
	/**
	 * 依員編查詢待簽核筆數(含簽核中及退回)
	 * @param apprvUser
	 * @return 待簽核筆數(含簽核中及退回)
	 */
	@Override
	public int countToApprv(String apprvUser){
		int cnt = 0;
		try {
			Map<String, Object> args = new HashMap<String, Object>();
			args.put("apprvUser", apprvUser);
			cnt = jdbc.queryForInt("RptContentApprvUser.countToApprv", args);			
			//log.debug("countToApprv apprvUser:"+apprvUser+",cnt="+cnt);
			
		} catch (EmptyResultDataAccessException e1) {
			logger.debug("countToApprv EmptyResultDataAccessException apprvUser:" +apprvUser + e1.getMessage());
			cnt = 0;
		} catch (Exception e) {
			log.debug("countToApprv Exception:" + e.getMessage());
			cnt = 0;
		}
		
		log.debug("countToApprv apprvUser:"+apprvUser+",cnt="+cnt);
		
		return cnt;
	}
	
	/**
	 * 依員編查詢待簽核筆數(含簽核中及退回)
	 * @param apprvUser RptContentApprvUser.countToApprvDeputy
	 * @return 待簽核筆數(含簽核中及退回)
	 */
	@Override
	public int countToApprvDeputy(String deputyUserId){
		int cnt = 0;
		try {
			Map<String, Object> args = new HashMap<String, Object>();
			args.put("deputyUserId", deputyUserId);
			cnt = jdbc.queryForInt("RptContentApprvUser.countToApprvDeputy", args);
		} catch (EmptyResultDataAccessException e1) {
			logger.debug("countToApprvDeputy EmptyResultDataAccessException e1:" + e1.getMessage());
			cnt = 0;
		} catch (Exception e) {
			log.debug("countToApprvDeputy Exception:" + e.getMessage());
			cnt = 0;
		}
		log.debug("countToApprvDeputy deputyUserId:"+deputyUserId+",cnt="+cnt);
		return cnt;
	}

	/**
	 * 依附合主鍵(rptId,rptVersion,rptDate,rptSeqNo,rptBranch) 
	 * 更新主檔下之簽核人員檔的欄位 masterId, masterApprvStatus, crossDept, crossDeptSetUserId masterApprvStep
	 * 
	 * @param rptId
	 * @param rptVersion
	 * @param rptDate
	 * @param rptSeqno
	 * @param rptBranch
	 * @param masterId
	 * @param masterApprvStatus
	 * @param croddDept
	 * @param crossDeptSetUserId
	 * @param masterApprvStep
	 */
	@Override
	public void updateMasterColumnsByKey(String rptId, int rptVersion, String rptDate, int rptSeqno, String rptBranch,
			long masterId, String masterApprvStatus, String croddDept, String crossDeptSetUserId, String masterApprvStep) {
		Map<String ,Object> param = new HashMap<String, Object>();
		param.put("rptId", rptId);
		param.put("rptVersion", rptVersion);
		param.put("rptDate", rptDate);
		param.put("rptSeqno", rptSeqno);
		param.put("rptBranch", rptBranch);
		param.put("masterId", masterId);
		param.put("masterApprvStatus", masterApprvStatus);
		param.put("crossDept", croddDept);
		param.put("crossDeptSetUserId", crossDeptSetUserId);
		param.put("masterApprvStep", masterApprvStep);
		jdbc.update("RptContentApprvUser.updateMasterColumnsByKey", param);
		
	}
	

}
